import axios from "axios";
import Swal from "sweetalert2";
const userisIn = "production"; //local or production
// const API_BASE_URL =
//   userisIn == "local"
//     ? "http://ec2-15-207-239-145.ap-south-1.compute.amazonaws.com:8080/oxynew/v1/user/"
//     : "https://fintech.oxyloans.com/oxyloans/v1/user/";
import { MARKETPLACE_URL, API_USER_URL, AI_CHAT_URL } from "../../config";
const API_BASE_URL = API_USER_URL;

// axios.interceptors.response.use(
//   (response) => response,
//   (error) => {
//     if (error?.response?.status === 401) {
//       const hasToken = sessionStorage.getItem("accessToken") || localStorage.getItem("accessToken");
//       const path = window.location.pathname;
//       const onAuthPage = path.includes("login") || path.includes("register") || path === "/";

//       if (hasToken && !onAuthPage) {
//         if (!window.isSessionAlertOpen) {
//           window.isSessionAlertOpen = true;
//           Swal.fire({
//             title: "Session Expired",
//             text: "Your session has expired. Do you want to regenerate token to continue or exit to home?",
//             icon: "warning",
//             showCancelButton: true,
//             confirmButtonColor: "#3085d6",
//             cancelButtonColor: "#d33",
//             confirmButtonText: "Continue",
//             cancelButtonText: "Exit",
//             allowOutsideClick: false,
//             allowEscapeKey: false,
//           }).then(async (result) => {
//             window.isSessionAlertOpen = false;
//             if (result.isConfirmed) {
//               try {
//                 Swal.fire({
//                   title: "Renewing Session...",
//                   text: "Please wait while we regenerate your session.",
//                   allowOutsideClick: false,
//                   didOpen: () => {
//                     Swal.showLoading();
//                   }
//                 });
//                 await getNewSessionTime();
//                 Swal.fire({
//                   title: "Success",
//                   text: "Session regenerated successfully. Reloading...",
//                   icon: "success",
//                   showConfirmButton: false,
//                   // timer: 5000
//                 });
//               } catch (err) {
//                 console.error("Failed to regenerate session token", err);
//                 sessionStorage.removeItem("accessToken");
//                 sessionStorage.removeItem("userId");
//                 localStorage.removeItem("accessToken");
//                 localStorage.removeItem("userId");
//                 Swal.fire({
//                   title: "Error",
//                   text: "Failed to renew session. Redirecting to login...",
//                   icon: "error",
//                   timer: 5000,
//                   showConfirmButton: false
//                 }).then(() => {
//                   window.location.href = "/";
//                 });
//               }
//             } else {
//               sessionStorage.removeItem("accessToken");
//               sessionStorage.removeItem("userId");
//               localStorage.removeItem("accessToken");
//               localStorage.removeItem("userId");
//               window.location.href = "/";
//             }
//           });
//         }
//       }
//     }
//     return Promise.reject(error);
//   }
// );

// Prevents concurrent silent refresh calls
let isRefreshing = false;

// Silently refresh token when user is active but token is getting old (80% of 30-min TTL = 24 min)
const SILENT_REFRESH_AFTER_MS = 1440000;

axios.interceptors.response.use(
  async (response) => {
    try {
      const tokenTime = sessionStorage.getItem("tokenTime");
      const token = sessionStorage.getItem("accessToken") || localStorage.getItem("accessToken");
      const userId = sessionStorage.getItem("userId") || localStorage.getItem("userId");
      const path = window.location.pathname;
      const onAuthPage = path.includes("login") || path.includes("register") || path === "/";
      if (tokenTime && token && userId && !isRefreshing && !onAuthPage) {
        const age = Date.now() - parseInt(tokenTime, 10);
        if (age > SILENT_REFRESH_AFTER_MS) {
          isRefreshing = true;
          axios.get(`${API_BASE_URL}${userId}/USER/accessTokenGeneration`, {
            headers: { accessToken: token }
          }).then(res => {
            const newToken = res.headers["accesstoken"] || res.headers["accessToken"];
            if (newToken) {
              sessionStorage.setItem("accessToken", newToken);
              localStorage.setItem("accessToken", newToken);
            }
            if (res.data?.tokenGeneratedTime) {
              sessionStorage.setItem("tokenTime", res.data.tokenGeneratedTime);
            }
          }).catch(err => {
            console.error("Silent token refresh failed", err);
          }).finally(() => {
            isRefreshing = false;
          });
        }
      }
    } catch (e) {
      // never break the response chain
    }
    return response;
  },
  (error) => {
    if (error?.response?.status === 401) {
      const hasToken = sessionStorage.getItem("accessToken") || localStorage.getItem("accessToken");
      const path = window.location.pathname;
      const onAuthPage = path.includes("login") || path.includes("register") || path === "/";

      if (hasToken && !onAuthPage) {
        if (!window.isSessionAlertOpen) {
          window.isSessionAlertOpen = true;
          Swal.fire({
            title: "Session Expired",
            text: "Your session has expired. Do you want to regenerate token to continue or exit to home?",
            icon: "warning",
            showCancelButton: true,
            confirmButtonColor: "#3085d6",
            cancelButtonColor: "#d33",
            confirmButtonText: "Continue",
            cancelButtonText: "Exit",
            allowOutsideClick: false,
            allowEscapeKey: false,
          }).then(async (result) => {
            window.isSessionAlertOpen = false;
            if (result.isConfirmed) {
              try {
                Swal.fire({
                  title: "Renewing Session...",
                  text: "Please wait while we regenerate your session.",
                  allowOutsideClick: false,
                  didOpen: () => {
                    Swal.showLoading();
                  }
                });
                await getNewSessionTime();
                Swal.fire({
                  title: "Success",
                  text: "Session regenerated successfully. Reloading...",
                  icon: "success",
                  showConfirmButton: false,
                  timer: 2000
                });
              } catch (err) {
                console.error("Failed to regenerate session token", err);
                sessionStorage.removeItem("accessToken");
                sessionStorage.removeItem("userId");
                localStorage.removeItem("accessToken");
                localStorage.removeItem("userId");
                Swal.fire({
                  title: "Error",
                  text: "Failed to renew session. Redirecting to login...",
                  icon: "error",
                  timer: 2000,
                  showConfirmButton: false
                }).then(() => {
                  window.location.href = "/";
                });
              }
            } else {
              sessionStorage.removeItem("accessToken");
              sessionStorage.removeItem("userId");
              localStorage.removeItem("accessToken");
              localStorage.removeItem("userId");
              window.location.href = "/";
            }
          });
        }
      }
    }
    return Promise.reject(error);
  }
);
export const getToken = () => {
  return sessionStorage.getItem("accessToken") || localStorage.getItem("accessToken");
};
export const base_url=API_BASE_URL;

export const getUserId = () => {
  return sessionStorage.getItem("userId") || localStorage.getItem("userId");
};

export const getUserSessionTime = () => {
  return sessionStorage.getItem("tokenTime");
};

export const loadVirtualAccount = () => {
  const userId = getUserId();
  return {
    userId,
  };
};

const getuserLoginId = getUserId();
const getUserLoginToken = getToken();

const handleApiRequestAfterLoginService = async (
  baseurl,
  endpoint,
  method,
  accessToken = null,
  data = null,
  headers = {}
) => {
  try {
    const response = await axios({
      method,
      url: `${baseurl}${endpoint}`,
      data,
      headers: {
        "Content-Type": "application/json",
        accessToken,
        ...headers,
      },
    });

    if (response && response.data) {
      const resData = response.data;
      if (
        resData.errorCode === "100" ||
        resData.errorCode === 100 ||
        (resData.errorMessage &&
          resData.errorMessage.toLowerCase().includes("session has expired"))
      ) {
        localStorage.clear();
        sessionStorage.clear();
        window.location.href = "/";
        return response;
      }
    }

    // Add your common logic here
    if (response.status == 200) {
      return response;
    }
  } catch (error) {
    if (error && error.response && error.response.data) {
      const errData = error.response.data;
      if (
        errData.errorCode === "100" ||
        errData.errorCode === 100 ||
        (errData.errorMessage &&
          errData.errorMessage.toLowerCase().includes("session has expired"))
      ) {
        localStorage.clear();
        sessionStorage.clear();
        window.location.href = "/";
      }
    }
    return error;
  }
};

export const handledetail = async (dealId) => {
  const token = getToken();
  const userId = getUserId();
  const response = await handleApiRequestAfterLoginService(
    API_BASE_URL,
    `${userId}/${dealId}/singleDeal`,
    "GET",
    token
  );
  return response;
};
export const sendWhatsappOtpapi = async (whatappdata, value) => {
  const value1 = value.slice(1);
  const token = getToken();
  const userId = getUserId();
  const data = {
    whatsappNumber: value1,
    id: userId,
  };
  const response = await handleApiRequestAfterLoginService(
    API_BASE_URL,
    `sendWhatsappOtp`,
    "POST",
    token,
    data
  );
  return response;
};

export const verifyWhatsappOtpapi = async (whatappdata) => {
  const token = getToken();
  const userId = getUserId();
  const data = {
    id: userId,
    whatsappOtp: whatappdata.otp,
  };
  const response = await handleApiRequestAfterLoginService(
    API_BASE_URL,
    `verifyWhatsappOtp`,
    "POST",
    token,
    data
  );
  return response;
};
export const sendInvait = async (email, mailContent, mailSubject) => {
  const token = getToken();
  const userId = getUserId();
  const data = {
    email: email,
    referrerId: userId,
    mailContent: mailContent,
    mailSubject: mailSubject,
    inviteType: "BulkInvite",
    userInvite: "NO",
  };
  const response = await handleApiRequestAfterLoginService(
    API_BASE_URL,
    `lenderReferring`,
    "POST",
    token,
    data
  );
  return response;
};

export const handleprincipalreturnaccounttypeapi = async (
  dealId,
  accountType1
) => {
  const token = getToken();
  const userId = getUserId();

  const data = {
    userId: userId,
    dealId: dealId,
    accountType: accountType1,
  };

  const response = await handleApiRequestAfterLoginService(
    API_BASE_URL,
    `principal_return_account_type`,
    "PATCH",
    token,
    data
  );
  return response;
};

export const handletocancelticketapi1 = async (id) => {
  const token = getToken();
  const userId = getUserId();

  const data = {
    id: id,
    userId: userId,
    status: "CANCELLED",
  };

  const response = await handleApiRequestAfterLoginService(
    API_BASE_URL,
    `to-cancel-ticket`,
    "PATCH",
    token,
    data
  );
  return response;
};
export const handlePaymembershipapi = async (member, no, feeAmountWithGst) => {
  const token = getToken();
  const userId = getUserId();
  // const membershipfiled = {
  //   MONTHLY: 1000,
  //   QUARTERLY: 2900,
  //   HALFYEARLY: 5600,
  //   PERYEAR: 9800,
  //   LIFETIME: 100000,
  //   FIVEYEARS: 50000,
  //   TENYEARS: 90000,
  // };
  // const calculatedfee = (membershipfiled[member] * 118) / 100;
  const data = {
    userId,
    type: "Wallet",
    feeAmount: Math.round(Number(feeAmountWithGst) || 0),
    lenderFeePayments: member,
    paidFrom: "WEB",
  };
  const response = await handleApiRequestAfterLoginService(
    API_BASE_URL,
    `deducting_lender_fee_from_wallet`,
    "POST",
    token,
    data
  );
  return response;
};

export const lenderfeeamountdetailsapi = async () => {
  const token = getToken();
  const userId = getUserId();
  const response = await handleApiRequestAfterLoginService(
    API_BASE_URL,
    `lender_fee_amount_details`,
    "GET",
    token
  );
  return response;
};
export const cashfreemembershipamount = async (member) => {
  const membershipfiled = {
    MONTHLY: 1000,
    QUARTERLY: 2900,
    HALFYEARLY: 5600,
    PERYEAR: 9800,
    LIFETIME: 100000,
    FIVEYEARS: 50000,
    TENYEARS: 90000,
  };

  //   const membershipfiled = {
  //   MONTHLY: 500,
  //   QUARTERLY: 1500,
  //   HALFYEARLY: 3000,
  //   PERYEAR: 5000,
  //   LIFETIME: 26000,
  //   FIVEYEARS: 15000,
  //   TENYEARS: 25000,
  // };
  const calculatedfee = (membershipfiled[member] * 118) / 100;
  return calculatedfee;
};

export const getuserMembershipValidity = async () => {
  const token = getToken();
  const userId = getUserId();
  const response = await handleApiRequestAfterLoginService(
    API_BASE_URL,
    `${userId}/dealsStatistics`,
    "GET",
    token
  );

  return response;
};

export const getMembershipDetails = async () => {
  const token = getToken();
  const userId = getUserId();
  const response = await handleApiRequestAfterLoginService(
    API_BASE_URL,
    `getMembership-details/${userId}`,
    "GET",
    token
  );

  return response;
};

export const bulkinvitegmailLink = async () => {
  const token = getToken();
  const userId = getUserId();
  let userType;
  if (userId.trim().toUpperCase().startsWith("LR")) {
    userType = "LENDER";
  } else {
    userType = "BORROWER";
  }
  const response = await handleApiRequestAfterLoginService(
    API_BASE_URL,
    `getGmailAuthorization/gmailcontacts/${userType}/REACT`,
    "GET",
    token
  );
  return response;
};

export const getUserDetails = async () => {
  const token = getToken();
  const userId = getUserId();
  const response = await handleApiRequestAfterLoginService(
    API_BASE_URL,
    `personal/${userId}`,
    "GET",
    token
  );
  return response;
};

export const getUserDetails1 = async () => {
  const token = getToken();
  const userId = getUserId();
  const response = await handleApiRequestAfterLoginService(
    API_BASE_URL,
    `lender/personal/${userId}`,
    "GET",
    token
  );
  return response;
};

export const loadlendernomineeDetails = async () => {
  const token = getToken();
  const userId = getUserId();
  const response = await handleApiRequestAfterLoginService(
    API_BASE_URL,
    `nominee/${userId}`,
    "GET",
    token
  );
  return response;
};
export const LoadwalletThroughQrScan = async (amount) => {
  const token = getToken();
  const userId = getUserId();
  var data = {
    userId: userId,
    amount: amount,
  };

  const response = await handleApiRequestAfterLoginService(
    API_BASE_URL,
    `QRTransactionInitiation`,
    "POST",
    token,
    data
  );

  return response;
};

export const handlecashapi = async (groupId, amount) => {
  const token = getToken();
  const userId = getUserId();

  const data = {
    amount: amount,
    dealId: groupId,
  };

  const response = await handleApiRequestAfterLoginService(
    API_BASE_URL,
    `${userId}/cashfree`,
    "POST",
    token,
    data
  );
  return response;
};
export const viewdealamountemi = async (dealId) => {
  const token = getToken();
  const userId = getUserId();

  const response = await handleApiRequestAfterLoginService(
    API_BASE_URL,
    `${userId}/${dealId}/dealLevelLoanEmiCard`,
    "GET",
    token
  );
  return response;
};

export const principal_return_account_type = async (dealId, transfermethod) => {
  const token = getToken();
  const userId = getUserId();

  var data = {
    userId: userId,
    dealId: dealId,
    accountType: transfermethod,
  };

  const response = await handleApiRequestAfterLoginService(
    API_BASE_URL,
    `principal_return_account_type`,
    "PATCH",
    token,
    data
  );
  return response;
};
export const myrunnig = async (props) => {
  const token = getToken();
  const userId = getUserId();

  const data = {
    pageNo: props.pageNo,
    pageSize: 10,
  };

  const response = await handleApiRequestAfterLoginService(
    API_BASE_URL,
    `${userId}/runningDealsInfoBasedOnPagination`,
    "POST",
    token,
    data
  );
  return response;
};
export const sendMoblieOtp = async (bankaccountprofile) => {
  const token = getToken();
  const userId = getUserId();
  const data = {
    mobileNumber: bankaccountprofile.moblieNumber,
  };

  const response = await handleApiRequestAfterLoginService(
    API_BASE_URL,
    `sendMobileOtp `,
    "POST",
    token,
    data
  );
  return response;
};
export const profileupadate = async (userProfile, formData, category) => {
  const token = getToken();
  const userId = getUserId();

  // Format date
  let formattedDate = userProfile.dob;
  if (userProfile.dob.includes("-")) {
    const dateComponents = userProfile.dob.split("-");
    formattedDate = `${dateComponents[2]}/${dateComponents[1]}/${dateComponents[0]}`;
    if (formattedDate.includes("undefined/undefined/")) {
      const startIndex =
        formattedDate.indexOf("undefined/undefined/") +
        "undefined/undefined/".length;
      formattedDate = formattedDate.substring(startIndex);
    }
  }

  console.log("Primary Type :", localStorage.getItem("primaryType"));
  if(localStorage.getItem("primaryType")=="BORROWER"){
 // Prepare personal API payload
   var personalData = JSON.stringify({
    firstName: userProfile.firstName,
    lastName: userProfile.lastName,
    middleName: userProfile.middleName,
    fatherName: userProfile.fatherName,
    maritalStatus: userProfile.maritalStatus || "Single",
    spouseName: (userProfile.maritalStatus || "Single") === "Married" ? (userProfile.spouseName || "") : "",
    spouseDob: (userProfile.maritalStatus || "Single") === "Married" && userProfile.spouseDob && userProfile.spouseDob.toString().trim()
      ? userProfile.spouseDob.toString().trim()
      : null,
    dob: formattedDate,
    panNumber: userProfile.panNumber,
    address: userProfile.residenceAddress,
    permanentAddress: userProfile.permanentAddress,
    pinCode: userProfile.pinCode,
    city: userProfile.city,
    state: userProfile.state,
    locality: userProfile.locality,
    facebookUrl: userProfile.facebookUrl,
    linkedinUrl: userProfile.linkedinUrl,
    twitterUrl: userProfile.twitterUrl,
    whatsAppNumber: userProfile.whatsAppNumber,
    aadharNumber: userProfile.aadharNumber,
    designation: userProfile.designation || formData.designation,
    officeAddress: userProfile.officeAddress || formData.officeAddress,
    officeMailId: userProfile.officeMailId || formData.officeMailId,
    officeLandLine: userProfile.officeLandLine || formData.officeLandLine,
    employment: category === "SELFEMPLOYED" ? "SELFEMPLOYED" : "SALARIED",
    ...(category !== "STUDENT" && {
      workExperience: formData.totalExperience,
      salary: formData.salary,
      companyName: formData.company,
      designation: formData.designation || userProfile.designation,
      officeAddress: formData.officeAddress || userProfile.officeAddress,
      officeMailId: formData.officeMailId || userProfile.officeMailId,
      officeLandLine: formData.officeLandLine || userProfile.officeLandLine,
    }),
    studentOrNot: category === "STUDENT",
  });
  }
  else{
      var personalData = JSON.stringify ({
    firstName: userProfile.firstName,
    lastName: userProfile.lastName,
    middleName: userProfile.middleName,
    fatherName: userProfile.fatherName,
    maritalStatus: userProfile.maritalStatus || "Single",
    spouseName: (userProfile.maritalStatus || "Single") === "Married" ? (userProfile.spouseName || "") : "",
    spouseDob: (userProfile.maritalStatus || "Single") === "Married" && userProfile.spouseDob && userProfile.spouseDob.toString().trim()
      ? userProfile.spouseDob.toString().trim()
      : null,
    dob: formattedDate,
    panNumber: userProfile.panNumber,
    address: userProfile.residenceAddress,
    permanentAddress: userProfile.permanentAddress,
    pinCode: userProfile.pinCode,
    city: userProfile.city,
    state: userProfile.state,
    locality: userProfile.locality,
    facebookUrl: userProfile.facebookUrl,
    linkedinUrl: userProfile.linkedinUrl,
    twitterUrl: userProfile.twitterUrl,
    whatsAppNumber: userProfile.whatsAppNumber,
    aadharNumber: userProfile.aadharNumber,
    designation: userProfile.designation,
    officeAddress: userProfile.officeAddress,
    officeMailId: userProfile.officeMailId,
    officeLandLine: userProfile.officeLandLine,
  });
  }
 
  // Always call personal API first
  const personalResponse = await handleApiRequestAfterLoginService(
    API_BASE_URL,
    `personal/${userId}`,
    "PATCH",
    token,
    personalData
  );

  // Conditionally call student_info API (no need to return its response)
  if (category === "STUDENT") {
    const studentBody = JSON.stringify({
      userId: userId,
      country: formData.country,
      universityName: formData.universityName,
      location: formData.universityLocation,
    });

    handleApiRequestAfterLoginService(
      API_BASE_URL,
      `student_info`,
      "PATCH",
      token,
      studentBody
    ).catch((err) => {
      console.error("Student info update failed:", err);
    });
  }

  // Return only personal API response
  return personalResponse;
};

export const getLendersInterestsDateWiseapi = async (date) => {
  const token = getToken();
  const userId = getUserId();

  function getMonthNameFromDate(dateObj) {
    const date = new Date(dateObj.date1); // Convert date string to Date object
    const monthNumber = date.getMonth() + 1; // getMonth() returns 0-11, so add 1

    switch (monthNumber) {
      case 1:
        return "January";
      case 2:
        return "February";
      case 3:
        return "March";
      case 4:
        return "April";
      case 5:
        return "May";
      case 6:
        return "June";
      case 7:
        return "July";
      case 8:
        return "August";
      case 9:
        return "September";
      case 10:
        return "October";
      case 11:
        return "November";
      case 12:
        return "December";
      default:
        return "Invalid month number";
    }
  }

  // Extract month name and year from the date
  const monthName = getMonthNameFromDate(date);
  const year = new Date(date.date1).getFullYear();

  // Prepare the data object with dynamic month name and year
  const data = {
    userId: userId,
    monthName: monthName,
    year: year.toString(),
  };

  const response = await handleApiRequestAfterLoginService(
    API_BASE_URL,
    `getLendersInterestsDateWise`,
    "POST",
    token,
    data
  );

  return response;
};

// Example usage:
const dateObj = { date1: "2024-10-02" };
// getLendersInterestsDateWiseapi(dateObj);
// .then((response) => console.log(response))
// .catch((error) => console.error(error));

export const checkqrcodetransaction = async (qrid) => {
  const token = getToken();
  const userId = getUserId();
  const response = await handleApiRequestAfterLoginService(
    API_BASE_URL,
    `${qrid}/qrStatusCheck`,
    "PATCH",
    token
  );

  return response;
};

export const paticipationChanges1 = async (dealId) => {
  const token = getToken();
  const userId = getUserId();
  const response = await handleApiRequestAfterLoginService(
    API_BASE_URL,
    `${userId}/${dealId}/paticipationChanges`,
    "GET",
    token
  );

  return response;
};

export const handelapi = async (dealId) => {
  const token = getToken();
  const userId = getUserId();
  const response = await handleApiRequestAfterLoginService(
    API_BASE_URL,
    `${userId}/${dealId}/closedDealsInterest`,
    "GET",
    token
  );
  return response;
};

export const getNotAchievedDealsapi = async (prama) => {
  const token = getToken();
  const userId = getUserId();
  const data = {
    dealType: prama,
  };
  const response = await handleApiRequestAfterLoginService(
    API_BASE_URL,
    `getNotAchievedDeals`,
    "POST",
    token,
    data
  );
  return response;
};
export const regular_Api = async (dealType, urldealname, pageNo = 1) => {
  const token = getToken();
  const userId = getUserId();

  if (urldealname == "ESCROW" || urldealname == "ESCROW/") {
    var url = "listOfDealsInformationForEquityDeals";
    var data = {
      pageNo: pageNo,
      pageSize: 10,
      dealName: "ESCROW",
      dealType: dealType,
    };
  } else if (urldealname == "PERSONAL" || urldealname == "PERSONAL/") {
    var url = "listOfDealsInformationForEquityDeals";
    var data = {
      pageNo: pageNo,
      pageSize: 10,
      dealName: "PERSONAL",
      dealType: dealType,
    };
  } else if (
    urldealname == "regularRunningDeal" ||
    urldealname == "regularRunningDeal/"
  ) {
    var url = "listOfDealsInformationToLender";
    var data = {
      pageNo: pageNo,
      pageSize: 10,
      dealType: dealType,
    };
  } else if (
    urldealname == "viewCurrentDayDeals" ||
    urldealname == "viewCurrentDayDeals/"
  ) {
    var url = "listOfDealsInformationToLender";
    var data = {
      pageNo: pageNo,
      pageSize: 10,
      dealType: "CURRENT",
    };
  } else if (urldealname == "Todaydeal" || urldealname == "Todaydeal/") {
    var url = "listOfDealsInformationToLender";
    var data = {
      pageNo: pageNo,
      pageSize: 10,
      dealType: "CURRENT",
    };
  } else if (urldealname == "testDeal" || "TestDeal") {
    var url = "listOfDealsInformationForEquityDeals";
    var data = {
      dealName: "TEST",
      pageNo: pageNo,
      pageSize: 10,
      dealType: "HAPPENING",
    };
  }

  const response = await handleApiRequestAfterLoginService(
    API_BASE_URL,
    `${userId}/${url}`,
    "POST",
    token,
    data
  );
  return response;
};
export const verifyBankAccountAndIfsc = async (bankaccountprofile) => {
  const token = getToken();
  const userId = getUserId();

  const data = {
    bankAccount: bankaccountprofile.accountNumber,
    ifscCode: bankaccountprofile.ifscCode.toUpperCase(),
  };
  
  const response = await handleApiRequestAfterLoginService(
    API_BASE_URL,
    "verifyBankAccountAndIfsc",
    "POST",
    token,
    data
  );
  return response;
};

export const feeApicall = async (calculatedfee, choosenmembership) => {
  const token = getToken();
  const userId = getUserId();
  const choose = choosenmembership; // Replace someValue with your actual variable or value
  const uppercaseMembership = choose.toUpperCase();

  const data = {
    userId,
    type: "Wallet",
    feeAmount: calculatedfee,
    lenderFeePayments: uppercaseMembership,
    paidFrom: "WEB",
  };

  const response = await handleApiRequestAfterLoginService(
    API_BASE_URL,
    `deducting_lender_fee_from_wallet`,
    "POST",
    token,
    data
  );
  return response;
};

export const feeapicallforonedeal = async (calculatedfee, dealId) => {
  const token = getToken();
  const userId = getUserId();
  const data = {
    userId,
    type: "Wallet",
    feeAmount: calculatedfee,
    dealId: dealId,
    lenderFeePayments: "PERDEAL",
    paidFrom: "WEB",
  };

  const response = await handleApiRequestAfterLoginService(
    API_BASE_URL,
    `deducting_lender_fee_from_wallet`,
    "POST",
    token,
    data
  );
  return response;
};

export const Earning = async (status) => {
  const token = getToken();
  const userId = getUserId();
  const data = JSON.stringify({
    userId: userId,
    paymentStatus: "",
  });

  const response = await handleApiRequestAfterLoginService(
    API_BASE_URL,
    `downLoadLinkForBonusAmount`,
    "POST",
    token,
    data
  );
  return response;
};

export const handeldisplayMonthlyReferrersAmountapi = async (data) => {
  const token = getToken();
  const userId = getUserId();
  const data2 = {
    pageNo: data.pageNo,
    pageSize: data.pageSize,
    userId: userId,
    month: data.month,
    year: data.year,
  };

  const response = await handleApiRequestAfterLoginService(
    API_BASE_URL,
    `displayMonthlyReferrersAmount`,
    "POST",
    token,
    data2
  );
  return response;
};

export const fetchFinancialEarnings = async (body) => {
  const token = getToken();
  const userId = getUserId();
  const response = await handleApiRequestAfterLoginService(
    API_BASE_URL,
    `${userId}/fyFeePaidPdfs`,
    "POST",
    token,
    body
  );
  return response;
};

export const summaryFinancialEarnings = async (body) => {
  const token = getToken();
  const userId = getUserId();
  const response = await handleApiRequestAfterLoginService(
    API_BASE_URL,
    `${userId}/fyPdfForLenders`,
    "POST",
    token,
    body
  );
  return response;
};

export const uploadkyc = async (event, password) => {
  const token = getToken();
  const userId = getUserId();
  var fd = new FormData();
  var files = event.target ? event.target.files[0] : event;
  var fieldName = event.target ? event.target.name : "CREDITREPORT";
  fd.append(fieldName, files);
  const queryParam = password ? `?password=${encodeURIComponent(password)}` : "";
  const response = await handleApiRequestAfterLoginService(
    API_BASE_URL,
    `${userId}/upload/kyc${queryParam}`,
    "POST",
    token,
    fd,
    {
      "Content-Type": "multipart/form-data",
    }
  );
  return response;
};

export const uploadqueryImage = async (file) => {
  const token = getToken();
  const userId = getUserId();
  var fd = new FormData();
  // var files = event.target.files[0];
  fd.append("USERQUERYSCREENSHOT", file);
  const response = await handleApiRequestAfterLoginService(
    API_BASE_URL,
    `${userId}/userQueryScreenshot`,
    "POST",
    token,
    fd,
    {
      "Content-Type": "multipart/form-data",
    }
  );
  return response;
};
export const updatebankDetails = async (bankaccountprofile) => {
  const token = getToken();
  const userId = getUserId();
  const mobileOtpSession = localStorage.getItem("OtpSeesion");
  const data = {
    accountNumber: bankaccountprofile.accountNumber,
    bankAddress: bankaccountprofile.bankCity,
    bankName: bankaccountprofile.bankName,
    branchName: bankaccountprofile.branchName,
    confirmAccountNumber: bankaccountprofile.confirmAccountNumber,
    ifscCode: bankaccountprofile.ifscCode.toUpperCase(),
    mobileOtp: bankaccountprofile.mobileOtp,
    mobileOtpSession: bankaccountprofile.mobileOtpSession,
    userName: bankaccountprofile.nameAtBank,
    updateBankDetails: true,
  };

  const response = await handleApiRequestAfterLoginService(
    API_BASE_URL,
    `personal/${userId}`,
    "PATCH",
    token,
    data
  );

  return response;
};
export const Myreferal = async (pageNo = 1, pageSize = 10) => {
  const token = getToken();
  const userId = getUserId();
  const postdata = JSON.stringify({
    pageNo,
    pageSize,
  });
  const response = await handleApiRequestAfterLoginService(
    API_BASE_URL,
    `${userId}/displayingReferrerInfo`,
    "POST",
    token,
    postdata
  );
  return response;
};

export const downloadreferal = async () => {
  const token = getToken();
  const userId = getUserId();

  const response = await handleApiRequestAfterLoginService(
    API_BASE_URL,
    `${userId}/referralBonusAmountLink`,
    "GET",
    token
  );

  return response;
};
export const getcontactdeatils = async () => {
  const token = getToken();
  const userId = getUserId();

  const response = await handleApiRequestAfterLoginService(
    API_BASE_URL,
    // user/getLenderStoredEmailContacts/${suserId}
    `getLenderStoredEmailContacts/${userId}`,
    "GET",
    token
  );
  return response;
};

export const fetchGamilCode = async (gmailcode) => {
  const token = getToken();
  const userId = getUserId();

  const postdata = {
    gmailCode: gmailcode,
    userType: "LENDER",
    projectType: "REACT",
  };
  const response = await handleApiRequestAfterLoginService(
    API_BASE_URL,
    `getContactsFromGmailAccount/${userId}`,
    "POST",
    token,
    postdata
  );
  return response;
};
export const fetchGamilCode1 = async (gmailcode) => {
  const token = getToken();
  const userId = getUserId();

  const postdata = {
    gmailCode: gmailcode,
    userType: "LENDER",
    projectType: "REACT",
  };
  const response = await handleApiRequestAfterLoginService(
    API_BASE_URL,
    `getAllContactsFromGmailAccount/${userId}`,
    "POST",
    token,
    postdata
  );
  return response;
};

export const handleapicall = async (
  dealId,
  roi,
  participatedamount,
  requestedamount,
  withdrawalamount
) => {
  const token = getToken();
  const userId = getUserId();

  const data1 = {
    userId: userId,
    dealId: dealId,
    currentAmount: participatedamount,
    requestedAmount: requestedamount,
    withDrawalFunds: withdrawalamount,
  };
  const response = await handleApiRequestAfterLoginService(
    API_BASE_URL,
    // user/getLenderStoredEmailContacts/${suserId}
    `withdrawalFundsFromDeals`,
    "POST",
    token,
    data1
  );
  return response;
};
export const writequery = async (userdata) => {
  const token = getToken();
  const userId = getUserId();

  console.log("userdata", userdata);

  if (userdata.id == null) {
    var postwritequerydata = {
      query: userdata.query + userdata.urlquery,
      documentId: userdata.documentId,
      email: userdata.profiledata.email,
      mobileNumber: userdata.profiledata.mobileNumber,
    };
  } else {
    if(userdata.status !== null ){
      var postwritequerydata = {
        query: userdata.query + userdata.urlquery,
        documentId: userdata.documentId,
        email: userdata.profiledata.email,
        mobileNumber: userdata.profiledata.mobileNumber,
        id: userdata.id,
        respondedBy: "USER",
        reOpenStatus: "REOPEN"
      };
    }else{
    var postwritequerydata = {
      query: userdata.query + userdata.urlquery,
      documentId: userdata.documentId,
      email: userdata.profiledata.email,
      mobileNumber: userdata.profiledata.mobileNumber,
      id: userdata.id,
      respondedBy: "USER",
    };
   }
  }

  const response = await handleApiRequestAfterLoginService(
    API_BASE_URL,
    `${userId}/readingQueriesFromUsers`,
    "POST",
    token,
    postwritequerydata
  );

  return response;
};
export const fileuploads = async (files) => {
  const token = getToken();
  const userId = getUserId();
  const formData = new FormData();
  formData.append("USERQUERYSCREENSHOT", files);
  const response = await handleApiRequestAfterLoginService(
    API_BASE_URL,
    `${userId}/userQueryScreenshot`,
    "POST",
    token,
    formData
  );

  return response;
};

export const getuploadCredit = async () => {
  const token = getToken();
  const userId = getUserId();

  const response = await handleApiRequestAfterLoginService(
    API_BASE_URL,
    `${userId}/getData`,
    "GET",
    token
  );

  return response;
};
export const submitWithdrawalRequestFromWallet = async (postdate, status) => {
  const token = getToken();
  const userId = getUserId();

  const withdrawAmount = postdate.withdrawAmount;
  const withdrawRating = postdate.withdrawRating;

  const postdata =
    status == "first"
      ? {
          userId,
          userType: "LENDER",
          amount: parseInt(withdrawAmount),
          amountRequiredDate: postdate.setGivendate,
          withdrawalReason: postdate.withdraReason,
          rating: JSON.stringify(withdrawRating),
          feedBack: postdate.withdrawFeedback,
          adminComments: "",
          status: "INITIATED",
        }
      : {
          userId,
          userType: "LENDER",
          amount: parseInt(withdrawAmount),
          amountRequiredDate: postdate.setGivendate,
          withdrawalReason: postdate.withdraReason,
          rating: JSON.stringify(withdrawRating),
          feedBack: postdate.withdrawFeedback,
          adminComments: "",
          status: "INITIATED",
          type: status,
        };

  const postdatastring = JSON.stringify(postdata);

  const response = await handleApiRequestAfterLoginService(
    API_BASE_URL,
    `savewithdrawalfundsinfo`,
    "POST",
    token,
    postdatastring
  );

  return response;
};

export const submitWalletToWallet = async (postdata) => {
  const token = getToken();

  const postdatastring = JSON.stringify({
    senderId: postdata.senderId,
    receiverId: postdata.receiverId.substring(2),
    amount: postdata.amount,
  });
  const response = await handleApiRequestAfterLoginService(
    API_BASE_URL,
    `wallet_amount_transfer`,
    "POST",
    token,
    postdatastring
  );

  return response;
};

export const profilesubmit = async (profile) => {
  const token = getToken();
  const userId = getUserId();

  let referrercountryCode = "91";
  var data = {
    email: profile.email,
    mobileNumber: referrercountryCode + profile.mobileNumber,
    name: profile.name,
    mailContent: profile.mailContent,
    mailSubject: profile.mailSubject,
    referrerId: userId,
    primaryType: profile.primaryType,
    citizenType: profile.citizenType,
    seekerRequestedId: "0",
    inviteType: "SingleInvite",
    userType: null,
    userInvite: profile.userinviteType,
  };

  const response = await handleApiRequestAfterLoginService(
    API_BASE_URL,
    `lenderReferring`,
    "POST",
    token,
    data
  );

  return response;
};
export const handelnomeeclickapi = async (nomineeDetails) => {
  const token = getToken();
  const userId = getUserId();

  var data = {
    userId: userId,
    relation: nomineeDetails.relation,
    name: nomineeDetails.nomineeName,
    mobileNumber: nomineeDetails,
    email: nomineeDetails.nomineeEmail,
    accountNumber: nomineeDetails.accountNo,
    ifscCode: nomineeDetails.nomineeIfsc,
    bankName: nomineeDetails.bank,
    branchName: nomineeDetails.branch,
    city: nomineeDetails.nomineecity,
  };

  const response = await handleApiRequestAfterLoginService(
    API_BASE_URL,
    `nominee`,
    "POST",
    token,
    data
  );

  return response;
};
export const TicketHistoryapi = async (pageNo = 1, pageSize = 10, status = "") => {
  const token = getToken();
  const userId = getUserId();
  const data = {
    pageNo,
    pageSize,
    status,
    userId: userId,
  };

  const response = await handleApiRequestAfterLoginService(
    API_BASE_URL,
    `queryDetailsBasedOnUserId`,
    "POST",
    token,
    data
  );

  return response;
};

export const uploadapicall = async (event, emailcontentdata) => {
  const token = getToken();
  const userId = getUserId();
  var fd = new FormData();

  var files = event.target.files[0];
  fd.append("BULKINVITE", files);
  fd.append("content", emailcontentdata);
  fd.append("userInvite", "NO");

  const response = await handleApiRequestAfterLoginService(
    API_BASE_URL,
    `sendBulkInviteThroughExcel/${userId}`,
    "POST",
    token,
    fd,
    {
      "Content-Type": "multipart/form-data",
    }
  );

  return response;
};

export const handelListOfQueriesHisoryapi = async (id) => {
  const token = getToken();
  const userId = getUserId();

  const data = {
    id: id,
    userId: userId,
  };
  const response = handleApiRequestAfterLoginService(
    API_BASE_URL,
    `listOfQueriesHisory`,
    "POST",
    token,
    data
  );

  return response;
};

export const getemailcontent = async () => {
  const token = getToken();
  const userId = getUserId();
  const response = await handleApiRequestAfterLoginService(
    API_BASE_URL,
    `mailContentShowingToLender`,
    "GET",
    token
  );
  return response;
};

export const highvalueDeals = async (pageNo = 1, pageSize = 10) => {
  const token = getToken();
  const postdatastring = JSON.stringify({
    pageNo,
    pageSize,
  });
  const response = await handleApiRequestAfterLoginService(
    API_BASE_URL,
    `assert_based_closed_deals`,
    "POST",
    token,
    postdatastring
  );
  return response;
};

export const getMyWalletTowalletHistory = async (pageNo = 1) => {
  const token = getToken();
  const userId = getUserId();
  const response = await handleApiRequestAfterLoginService(
    API_BASE_URL,
    `${userId}/wallet-to-wallet-debit-history`,
    "GET",
    token
  );
  return response;
};

export const getMyWalletTowalletTransactionHistory = async () => {
  const token = getToken();
  const userId = getUserId();
  const response = await handleApiRequestAfterLoginService(
    API_BASE_URL,
    `${userId}/wallet_to_wallet_request_list`,
    "GET",
    token
  );
  return response;
};

export const getMembershiphistory = async (pageNo = 1, pageSize = 10) => {
  const token = getToken();
  const userId = getUserId();
  const postdatastring = JSON.stringify({
    pageNo,
    pageSize,
  });
  const response = await handleApiRequestAfterLoginService(
    API_BASE_URL,
    `${userId}/lender_fee_paid_type`,
    "POST",
    token,
    postdatastring
  );
  return response;
};
export const getMyfinancialEarnings = async () => {
  const token = getToken();
  const userId = getUserId();
  const response = await handleApiRequestAfterLoginService(
    API_BASE_URL,
    `${userId}/financial_year_data`,
    "GET",
    token
  );
  return response;
};

export const getMyToatlInterestEarnings = async () => {
  const token = getToken();
  const userId = getUserId();

  const postdatastring = JSON.stringify({
    userId,
  });

  const response = await handleApiRequestAfterLoginService(
    API_BASE_URL,
    `monthly_interest_earnings`,
    "POST",
    token,
    postdatastring
  );
  return response;
};

export const getMyWithdrawalHistory = async (pageNo = 1, pageSize = 10) => {
  const token = getToken();
  const userId = getUserId();
  const postdatastring = JSON.stringify({
    page: {
      pageNo,
      pageSize,
    },
    firstName: "",
    lastName: "",
    userId: userId,
  });

  const response = await handleApiRequestAfterLoginService(
    API_BASE_URL,
    `lenderwithdrawalfundssearch`,
    "POST",
    token,
    postdatastring
  );
  return response;
};

export const chatapi = async () => {
  const token = getToken();
  const userId = getUserId();
  const response = handleApiRequestAfterLoginService(
    API_BASE_URL,
    `${userId}/lendertotalInvestmentData`,
    "GET",
    token
  );
  return response;
};

export const lenderTotalInvestmentsAndReturns = async () => {
  const token = getToken();
  const userId = getUserId();

  const response = await handleApiRequestAfterLoginService(
    API_BASE_URL,
    `${userId}/lenderTotalInvestmentsAndReturns`,
    "GET",
    token
  );

  return response;
};
export const nofreeParticipationapi = async (
  apidata,
  groupId,
  dealId,
  accountType,
  lenderReturnType,
  deal
) => {
  const token = getToken();
  const userId = getUserId();

  if (deal.monthlyInterest !== 0) {
    var lenderReturnType = "MONTHLY";
  } else if (deal.quarterlyDisplay !== 0) {
    var lenderReturnType = "QUARTELY";
  } else if (deal.yearlyInterest !== 0) {
    var lenderReturnType = "YEARLY";
  }
  const data = {
    userId: userId,
    groupId: groupId,
    dealId: dealId,
    participatedAmount: deal.participatedAmount,
    lenderReturnType: lenderReturnType,
    processingFee: 0,
    lenderFeeId: "0",
    accountType: accountType,
    feeStatus: "COMPLETED",
  };
  let userconfirmed = "NO";

  // if(participationStatus === true){
  // 	      userconfirmed = "YES";
  // 		var participationStatus = "UPDATE";
  // }else{
  //   var participationStatus = status;
  // }

  var lenderRemainingWalletAmount = localStorage.getItem(
    "lenderRemainingWalletAmount"
  );
  const data1 = {
    userId: userId,
    groupId: groupId,
    dealId: dealId,
    participatedAmount: deal.participatedAmount,
    lenderReturnType: lenderReturnType,
    // rateofInterest: choosenRateofInterest,
    processingFee: 0,
    paticipationStatus:
      deal.lenderParticipationTotal !== null || 0 ? "ADD" : "UPDATE",
    accountType: accountType,
    lenderRemainingWalletAmount: lenderRemainingWalletAmount,
    ExtensionConsents: "NOTINTERESTED",
    feeStatus: "COMPLETED",
    // lenderTotalPanLimit:userPanLimit,
    // totalParticipatedAmount:userTotalParticipation
    lenderTotalPanLimit: deal.apidata.lenderRemainingPanLimit,
    lenderParticipationFrom: "WEB",
    totalParticipatedAmount: deal.apidata.lenderTotalParticipationAmount,
  };
  const response = await handleApiRequestAfterLoginService(
    API_BASE_URL,
    "updatingLenderDeal",
    "PATCH",
    token,
    data1
  );
  return response;
};

/** Maps UI payout labels to backend LenderReturnsType enum values. */
const normalizeLenderReturnType = (payout) => {
  if (!payout) return "MONTHLY";
  const value = String(payout).toUpperCase();
  if (value === "QUARTERLY") return "QUARTELY";
  if (value === "HALFYEARLY" || value === "HALF_YEARLY") return "HALFLY";
  return value;
};

export const dealparticipationValidityUser = async (deal) => {
  const token = getToken();
  const userId = getUserId();

  const data1 = {
    userId: userId,
    groupId: deal.apidata.groupId,
    dealId: deal.urldealId,
    participatedAmount: deal.participatedAmount,
    lenderReturnType: normalizeLenderReturnType(deal.apidata.payout),
    processingFee: 0,
    paticipationStatus:
      deal.apidata.lenderParticipationTotal !== null || 0 ? "ADD" : "UPDATE",
    accountType: deal.bank,
    feeStatus: "COMPLETED",
    lenderTotalPanLimit: deal.apidata.lenderRemainingPanLimit,
    totalParticipatedAmount: deal.apidata.lenderTotalParticipationAmount,
    lenderRemainingWalletAmount: deal.apidata.lenderRemainingWalletAmount,
    lenderParticipationFrom: "WEB",
    ExtensionConsents: "NOTINTERESTED",
  };
  const response = await handleApiRequestAfterLoginService(
    API_BASE_URL,
    "updatingLenderDeal",
    "PATCH",
    token,
    data1
  );
  return response;
};

export const newlenderdealparticipation = async (deal) => {
  const token = getToken();
  const userId = getUserId();

  var newLenderFeePercentage = (parseInt(deal.participatedAmount) * 1) / 100;
  var newLenderGstAndFeeCalculation = (newLenderFeePercentage * 118) / 100;

  const data = {
    userId: userId,
    groupId: deal.apidata.groupId,
    dealId: deal.urldealId,
    participatedAmount: deal.participatedAmount,
    lenderReturnType: normalizeLenderReturnType(deal.apidata.payout),
    processingFee: newLenderGstAndFeeCalculation,
    paticipationStatus:
      deal.apidata.lenderParticipationTotal !== null || 0 ? "ADD" : "UPDATE",
    accountType: deal.bank,
    feeStatus: "PENDING",
    lenderTotalPanLimit: deal.apidata.lenderRemainingPanLimit,
    totalParticipatedAmount: deal.apidata.lenderTotalParticipationAmount,
    lenderRemainingWalletAmount: deal.apidata.lenderRemainingWalletAmount,
    lenderParticipationFrom: "WEB",
    ExtensionConsents: "NOTINTERESTED",
  };
  const response = await handleApiRequestAfterLoginService(
    API_BASE_URL,
    "updatingLenderDeal",
    "PATCH",
    token,
    data
  );
  return response;
};

export const allQueriesCount1 = async () => {
  const token = getToken();
  const userId = getUserId();

  const response = await handleApiRequestAfterLoginService(
    API_BASE_URL,
    `${userId}/allQueriesCount`,
    "GET",
    token
  );

  return response;
};
export const getMyTransactions = async (pageNo = 1, pageSize = 10) => {
  const token = getToken();
  const userId = getUserId();

  const response = await handleApiRequestAfterLoginService(
    API_BASE_URL,
    `${userId}/lenderHistory`,
    "GET",
    token
  );
  return response;
};

export const getWithdrawaFromDeal = async (
  pageNo = 1,
  pageSize = 10,
  dealtype
) => {
  const token = getToken();
  const userId = getUserId();

  const postdatastring = JSON.stringify({
    pageNo,
    pageSize,
    dealType: dealtype,
  });

  const response = await handleApiRequestAfterLoginService(
    API_BASE_URL,
    `${userId}/lenderPaticipatedDealBasedOnDealType`,
    "POST",
    token,
    postdatastring
  );
  return response;
};

export const getDashboardInvestment = async (pageNo = 1, pageSize = 10) => {
  const token = getToken();
  const userId = getUserId();

  const postdatastring = JSON.stringify({
    userId,
    requestType: "WALLETCREDITED",
    pageSize,
    pageNo,
    searchType: "DESC",
  });

  const response = await handleApiRequestAfterLoginService(
    API_BASE_URL,
    `newLenderDashboard`,
    "POST",
    token,
    postdatastring
  );
  return response;
};

export const withdrawriaseapipay = async (status) => {
  const token = getToken();
  const userId = getUserId();

  const postdata = {
    status: status,
    userId: userId,
  };

  const response = await handleApiRequestAfterLoginService(
    API_BASE_URL,
    `withdrawriase`,
    "PATCH",
    token,
    postdata
  );
  return response;
};
export const getDashboardPrincipalReturned = async (
  pageNo = 1,
  pageSize = 10
) => {
  const token = getToken();
  const userId = getUserId();

  const postdatastring = JSON.stringify({
    userId,
    requestType: "LENDERPRICIPAL",
    pageSize,
    pageNo,
    searchType: "DESC",
  });

  const response = await handleApiRequestAfterLoginService(
    API_BASE_URL,
    `newLenderDashboard`,
    "POST",
    token,
    postdatastring
  );
  return response;
};

export const getDashboardInterestEarnings = async (
  pageNo = 1,
  pageSize = 10
) => {
  const token = getToken();
  const userId = getUserId();

  const postdatastring = JSON.stringify({
    userId,
    requestType: "LENDERINTEREST",
    pageSize,
    pageNo,
    searchType: "DESC",
  });

  const response = await handleApiRequestAfterLoginService(
    API_BASE_URL,
    `newLenderDashboard`,
    "POST",
    token,
    postdatastring
  );
  return response;
};

export const getDashboardReferralEarnings = async (
  pageNo = 1,
  pageSize = 10
) => {
  const token = getToken();
  const userId = getUserId();

  const postdatastring = JSON.stringify({
    userId,
    requestType: "REFERRALBONUS",
    pageSize,
    pageNo,
    searchType: "DESC",
  });

  const response = await handleApiRequestAfterLoginService(
    API_BASE_URL,
    `newLenderDashboard`,
    "POST",
    token,
    postdatastring
  );
  return response;
};

export const getdashboardDealsVsEarnings = async (
  pageNo = 1,
  pageSize = 10
) => {
  const token = getToken();
  const userId = getUserId();

  const postdatastring = JSON.stringify({
    userId,
    requestType: "LENDERPATICIPATION",
    pageSize,
    pageNo,
    searchType: "DESC",
  });

  const response = await handleApiRequestAfterLoginService(
    API_BASE_URL,
    `newLenderDashboard`,
    "POST",
    token,
    postdatastring
  );
  return response;
};

export const referralEarningsInfo = async (pageNo = 1, pageSize = 10) => {
  const token = getToken();
  const userId = getUserId();
  const postdatastring = JSON.stringify({
    pageNo,
    pageSize,
    paymentStatus: "",
    userId,
  });
  const response = await handleApiRequestAfterLoginService(
    API_BASE_URL,
    `referralBonusAmountBasedOnStatus`,
    "POST",
    token,
    postdatastring
  );
  return response;
};

export const handelsubmitdatafilter = async (inputserach) => {
  const token = getToken();
  const userId = getUserId();
  const isValidInput =
    typeof inputserach === "string" && inputserach.length > 0;

  const postdatastring = {
    dealId: isValidInput && inputserach.length <= 3 ? parseInt(inputserach) : null,
    userId: parseInt(userId),
    dealName: isValidInput && inputserach.length > 3 ? inputserach : null,
  };
  const response = await handleApiRequestAfterLoginService(
    API_BASE_URL,
    `search_based_on_deal_name`,
    "POST",
    token,
    postdatastring
  );
  return response;
};

export const handelsubmitcanceldatafilter = async (inputserach) => {
  const token = getToken();
  const userId = getUserId();
  const isValidInput =
    typeof inputserach === "string" && inputserach.length > 0;

  const postdatastring = {
    // dealId:
    //   isValidInput && inputserach.length <= 3 ? parseInt(inputserach) : null,
    userId: parseInt(userId),
    dealName: isValidInput && inputserach.length > 3 ? inputserach : null,
  };
  const response = await handleApiRequestAfterLoginService(
    API_BASE_URL,
    `search_based_closed_deals`,
    "POST",
    token,
    postdatastring
  );
  return response;
};


export const referralEarningsInfoparam = async (
  pageNo = 1,
  pageSize = 10,
  param
) => {
  const token = getToken();
  const userId = getUserId();
  const postdatastring = JSON.stringify({
    pageNo,
    pageSize,
    paymentStatus: param,
    userId,
  });
  const response = await handleApiRequestAfterLoginService(
    API_BASE_URL,
    `referralBonusAmountBasedOnStatus`,
    "POST",
    token,
    postdatastring
  );
  return response;
};
export const handlepincodeapicall = async (code) => {
  const token = getToken();
  const userId = getUserId();

  const response = await handleApiRequestAfterLoginService(
    API_BASE_URL,
    `${code}/pincode`,
    "GET",
    token
  );
  return response;
};

export const getholdamountInfo = async () => {
  const token = getToken();
  const userId = getUserId();
  const response = await handleApiRequestAfterLoginService(
    API_BASE_URL,
    `${userId}/hold-amount-details`,
    "GET",
    token
  );
  return response;
};

export const myclosedDealsInfo = async (pageNo = 1, pageSize = 10) => {
  const token = getToken();
  const userId = getUserId();
  const postdatastring = JSON.stringify({
    pageNo,
    pageSize,
    userId,
  });
  const response = await handleApiRequestAfterLoginService(
    API_BASE_URL,
    `closedDealsForUserBasedOnPagination`,
    "POST",
    token,
    postdatastring
  );
  return response;
};

export const getEmiTableInformation = async (params) => {
  const token = getToken();
  const userId = getUserId();

  const postdatastring = JSON.stringify({
    loanAmount: params.loanAmount,
    rateOfInterest: params.inputroi,
    tenure: params.inputTenure,
    calculationType: params.emiType,
  });

  const response = await handleApiRequestAfterLoginService(
    API_BASE_URL,
    `borrowerEmiDetails`,
    "POST",
    token,
    postdatastring
  );
  return response;
};

/** Must match accessTokenTtl in oxyloans-rest application.properties (milliseconds). */
export const SESSION_TTL_MS = 1800000; // 1800 seconds = 30 minutes
export const SESSION_WARN_BEFORE_SEC = 300; // show warning in last 5 minutes

export const getSessionRemainingSeconds = () => {
  const tokenTimeStamp = getUserSessionTime();
  if (!tokenTimeStamp) return null;
  const expiresAt = parseInt(tokenTimeStamp, 10) + SESSION_TTL_MS;
  return Math.max(0, Math.floor((expiresAt - Date.now()) / 1000));
};

export const getSessionExpireTime = () => {
  const remainingSec = getSessionRemainingSeconds();
  if (remainingSec === null) return false;
  return remainingSec <= SESSION_WARN_BEFORE_SEC;
};

export const getNewSessionTime = async () => {
  const token = getToken();
  const userId = getUserId();
  const response = await handleApiRequestAfterLoginService(
    API_BASE_URL,
    `${userId}/USER/accessTokenGeneration`,
    "GET",
    token
  );
  sessionStorage.removeItem("accessToken");
  sessionStorage.removeItem("tokenTime");
  const accessTokenFromHeader = response.headers["accesstoken"] || response.headers["accessToken"];
  if (accessTokenFromHeader) {
    sessionStorage.setItem("accessToken", accessTokenFromHeader);
    localStorage.setItem("accessToken", accessTokenFromHeader);
  }
  sessionStorage.setItem("tokenTime", response.data.tokenGeneratedTime);
  setTimeout(() => {
    window.location.reload();
  }, 2500);
  return response;
};

export const cancelWithdrawalRequest = async (fromrequest, requestId) => {
  const token = getToken();
  const userId = getUserId();
  var postdata = JSON.stringify({
    id: requestId,
    userId: userId,
    requestFrom: fromrequest,
  });

  const response = await handleApiRequestAfterLoginService(
    API_BASE_URL,
    `to-cancel-withdrawal-request`,
    "PATCH",
    token,
    postdata
  );
  return response;
};

export const handelexcelsForNewLenderDashboard = async (requestType) => {
  const token = getToken();
  const userId = getUserId();
  var postdata = {
    userId: userId,
    requestType: requestType,
  };
  const response = await handleApiRequestAfterLoginService(
    API_BASE_URL,
    `excelsForNewLenderDashboard`,
    "POST",
    token,
    postdata
  );
  return response;
};

export const confirmthependingamount = async (dealId, amount) => {
  const token = getToken();
  const userId = getUserId();
  var postdata = JSON.stringify({
    userId,
    type: "Wallet",
    feeAmount: amount,
    dealId,
    lenderFeePayments: "PERDEAL",
    paidFrom: "WEB",
  });

  const response = await handleApiRequestAfterLoginService(
    API_BASE_URL,
    `deducting_lender_fee_from_wallet`,
    "POST",
    token,
    postdata
  );
  return response;
};

export const cancelMyWithdrawWalletRequest = async (requestId) => {
  const token = getToken();
  const userId = getUserId();
  var postdata = JSON.stringify({
    id: requestId,
    status: "REJECTED",
  });
  const response = await handleApiRequestAfterLoginService(
    API_BASE_URL,
    `wallet_to_wallet_request`,
    "PATCH",
    token,
    postdata
  );
  return response;
};

export const getFinancialReportDownload = async (
  startDate,
  endDate,
  requestTypefromBtn,
  status
) => {
  const token = getToken();
  const userId = getUserId();
  var postdata = JSON.stringify({
    startDate,
    endDate,
    inputType: requestTypefromBtn,
    status: status,
  });

  const response = await handleApiRequestAfterLoginService(
    API_BASE_URL,
    `${userId}/lender-income`,
    "POST",
    token,
    postdata
  );
  return response;
};

export const downloadClosedLoanStatement = async (typeoffile = "RUNNING") => {
  const token = getToken();
  const userId = getUserId();
  const response = await handleApiRequestAfterLoginService(
    API_BASE_URL,
    `${userId}/closedDealsDownloadForUser`,
    "GET",
    token
  );

  return response;
};

export const downloadTranactionStatement = async () => {
  const token = getToken();
  const userId = getUserId();
  const response = await handleApiRequestAfterLoginService(
    API_BASE_URL,
    `${userId}/lenderHistoryPdf`,
    "GET",
    token
  );

  return response;
};

export const getMyinterestEarningSearch = async (data) => {
  const token = getToken();
  const userId = getUserId();
  var postdata = JSON.stringify({
    userId: userId,
    startDate: data.searchStartdate,
    endDate: data.searchEndDate,
    sortBasedOn: data.sortbased,
    sortingType: "Asc",
  });

  const response = await handleApiRequestAfterLoginService(
    API_BASE_URL,
    `monthly_interest_earnings`,
    "POST",
    token,
    postdata
  );
  return response;
};

export const savenomineeDeatailsApi = async (nominee) => {
  const token = getToken();
  const userId = getUserId();

  const data = {
    userId: userId,
    relation: nominee.relation,
    name: nominee.nomineeName,
    mobileNumber: nominee.nomineeMobile,
    email: nominee.nomineeEmail,
    accountNumber: nominee.accountNo,
    ifscCode: nominee.nomineeIfsc,
    bankName: nominee.bank,
    branchName: nominee.branch,
    city: nominee.nomineecity,
  };

  const response = await handleApiRequestAfterLoginService(
    API_BASE_URL,
    "nominee",
    "POST",
    token,
    data
  );
  return response;
};

export const getPanDoc = async () => {
  const token = getToken();
  const userId = getUserId();
  const res = await handleApiRequestAfterLoginService(
    API_BASE_URL,
    `${userId}/download/PAN`,
    "GET",
    token
  );
  return res;
};

export const getdataPassport = async () => {
  const token = getToken();
  const userId = getUserId();
  const res = await handleApiRequestAfterLoginService(
    API_BASE_URL,
    `${userId}/download/PASSPORT`,
    "GET",
    token
  );
  return res;
};

export const getdataAadhar = async () => {
  const token = getToken();
  const userId = getUserId();
  const res = await handleApiRequestAfterLoginService(
    API_BASE_URL,
    `${userId}/download/AADHAR`,
    "GET",
    token
  );
  return res;
};

export const getdataVoterId = async () => {
  const token = getToken();
  const userId = getUserId();
  const res = await handleApiRequestAfterLoginService(
    API_BASE_URL,
    `${userId}/download/VOTERID`,
    "GET",
    token
  );
  return res;
};

export const getdataDrivingLicence = async () => {
  const token = getToken();
  const userId = getUserId();
  const res = await handleApiRequestAfterLoginService(
    API_BASE_URL,
    `${userId}/download/DRIVINGLICENCE`,
    "GET",
    token
  );
  return res;
};

export const getdatachequeLeaf = async () => {
  const token = getToken();
  const userId = getUserId();
  const res = await handleApiRequestAfterLoginService(
    API_BASE_URL,
    `${userId}/download/CHEQUELEAF`,
    "GET",
    token
  );
  return res;
};

export const getdataBankStatement = async () => {
  const token = getToken();
  const userId = getUserId();
  const res = await handleApiRequestAfterLoginService(
    API_BASE_URL,
    `${userId}/download/BANKSTATEMENT`,
    "GET",
    token
  );
  return res;
};

export const getdatatenth = async () => {
  const token = getToken();
  const userId = getUserId();
  const res = await handleApiRequestAfterLoginService(
    API_BASE_URL,
    `${userId}/download/TENTH`,
    "GET",
    token
  );
  return res;
};

export const getdataintermediate = async () => {
  const token = getToken();
  const userId = getUserId();
  const res = await handleApiRequestAfterLoginService(
    API_BASE_URL,
    `${userId}/download/INTER`,
    "GET",
    token
  );
  return res;
};

export const getdatagraduation = async () => {
  const token = getToken();
  const userId = getUserId();
  const res = await handleApiRequestAfterLoginService(
    API_BASE_URL,
    `${userId}/download/GRADUATION`,
    "GET",
    token
  );
  return res;
};


export const getdataofferletter = async () => {
  const token = getToken();
  const userId = getUserId();
  const res = await handleApiRequestAfterLoginService(
    API_BASE_URL,
    `${userId}/download/UNIVERSITYOFFERLETTER`,
    "GET",
    token
  );
  return res;
};

export const getdatafeereceipt = async () => {
  const token = getToken();
  const userId = getUserId();
  const res = await handleApiRequestAfterLoginService(
    API_BASE_URL,
    `${userId}/download/FEE`,
    "GET",
    token
  );
  return res;
};


export const getdatapayslips = async () => {
  const token = getToken();
  const userId = getUserId();
  const res = await handleApiRequestAfterLoginService(
    API_BASE_URL,
    `${userId}/download/PAYSLIPS`,
    "GET",
    token
  );
  return res;
};

export const getactivityApisData = () => {
  const token = getToken();
  const userId = getUserId();
  const res = handleApiRequestAfterLoginService(
    API_BASE_URL,
    `${userId}/dealsStatistics`,
    "GET",
    token
  );
  return res;
};

export const getInterestEarnings = () => {
  const token = getToken();
  const userId = getUserId();
  const res = handleApiRequestAfterLoginService(
    API_BASE_URL,
    `${userId}/lenderEarnngAndReturn`,
    "GET",
    token
  );
  return res;
};

export const getNoDealsParticipated = () => {
  const token = getToken();
  const userId = getUserId();
  const res = handleApiRequestAfterLoginService(
    API_BASE_URL,
    `${userId}/dealAndParticipationCount`,
    "POST",
    token
  );
  return res;
};

//////////borrower apis/////////

export const getBorrowerRunningloans = async (pageNo = 1, pageSize = 10) => {
  const token = getToken();
  const userId = getUserId();

  const postdatastring = JSON.stringify({
    page: {
      pageNo,
      pageSize,
    },
  });
  const response = await handleApiRequestAfterLoginService(
    API_BASE_URL,
    `${userId}/application/loansbyapplication`,
    "POST",
    token,
    postdatastring
  );
  return response;
};

export const fetchcashfree = async (
  membership,
  no,
  feeAmountWithGst,
  url,
  dealId = 0
) => {
  const token = getToken();
  const userId = getUserId();

  let membershipamount = await cashfreemembershipamount(membership);

  const postdatastring = JSON.stringify({
    orderAmount: feeAmountWithGst,
    userId: userId,
    dealId: dealId,
    return_url: url,
    lenderFeePayments: membership,
    paidFrom: "WEB",
  });
  const response = await handleApiRequestAfterLoginService(
    API_BASE_URL,
    `cashfreeOrderForReact`,
    "POST",
    token,
    postdatastring
  );
  return response;
};

export const borrowerIdMappedToDealIdapi = (dealId) => {
  const token = getToken();
  const userId = getUserId();

  const data = {
    dealId: dealId,
  };
  const res = handleApiRequestAfterLoginService(
    API_BASE_URL,
    `borrowerIdMappedToDealId`,
    "POST",
    token,
    data
  );
  return res;
};
export const knowisalredyrequested = () => {
  const token = getToken();
  const userId = getUserId();
  const res = handleApiRequestAfterLoginService(
    API_BASE_URL,
    `${userId}/lenderWithdrawFundsInfo`,
    "GET",
    token
  );
  return res;
};

// export const handelupdatedcible = (data , file) => {
//   const token = getToken();
//   const userId = getUserId();
//   const res = handleApiRequestAfterLoginService(
//     API_BASE_URL,
//     `${data.userId}/${data.oxyScore}/${data.commentId}/${data.passwordLogin}/uploadCreditReport`,
//     "POST",
//     token
//   );
//   return res;
// };
export const getpaymentorder = (myorder) => {
  const token = getToken();
  const userId = getUserId();
  const res = handleApiRequestAfterLoginService(
    API_BASE_URL,
    `${myorder}/getOrderbyIdForReact`,
    "GET",
    token
  );
  return res;
};

export const handellenderFeePaymentsapi = (data) => {
  const token = getToken();
  const userId = getUserId();
  console.log(data);

  console.log(data.data.customer_details.customer_id);
  console.log(data.data.order_status);
  const postData = {
    comments: "LENDER FEE",
    payuTransactionNumber: data.data.customer_details.customer_id,
    payuStatus: data.data.order_status === "PAID" ? "success" : "",
  };
  const res = handleApiRequestAfterLoginService(
    API_BASE_URL,
    `${data.data.customer_details.customer_id}/lenderFeePayments`,
    "PATCH",
    token,
    postData
  );
  return res;
};

export const getBorrowerApplication = async (pageNo = 1, pageSize = 10) => {
  const token = getToken();
  const userId = getUserId();

  const postdatastring = JSON.stringify({
    leftOperand: {
      fieldName: "userId",
      fieldValue: userId,
      operator: "EQUALS",
    },
    logicalOperator: "AND",
    rightOperand: {
      fieldName: "parentRequestId",
      operator: "NULL",
    },
  });
  const response = await handleApiRequestAfterLoginService(
    API_BASE_URL,
    `${userId}/loan/ADMIN/request/search`,
    "POST",
    token,
    postdatastring
  );
  return response;
};

export const getExtensionHistoryapicall = async (dealId) => {
  const token = getToken();

  const data = {
    dealId,
  };
  const response = await handleApiRequestAfterLoginService(
    API_BASE_URL,
    `getExtensionHistory`,
    "POST",
    token,
    data
  );
  return response;
};

export const myagreedloanapplication = async (pageNo = 1, pageSize = 10) => {
  const token = getToken();
  const userId = getUserId();

  let fName = "borrowerUserId";

  // if (sprimaryType == "BORROWER") {
  //   fName = "borrowerUserId";
  // }

  const postdatastring = JSON.stringify({
    leftOperand: {
      fieldName: fName,
      fieldValue: userId,
      operator: "EQUALS",
    },

    logicalOperator: "AND",

    rightOperand: {
      fieldName: "loanStatus",
      fieldValues: ["Agreed", "Active", "Closed", "Hold"],
      operator: "IN",
    },
    page: {
      pageNo,
      pageSize,
    },
    sortBy: "loanAcceptedDate",
    sortOrder: "DESC",
  });
  const response = await handleApiRequestAfterLoginService(
    API_BASE_URL,
    `${userId}/loan/BORROWER/search`,
    "POST",
    token,
    postdatastring
  );
  return response;
};

export const enachmandate = async (pageNo = 1, pageSize = 10) => {
  const token = getToken();
  const userId = getUserId();

  const postdatastring = JSON.stringify({});
  const response = await handleApiRequestAfterLoginService(
    API_BASE_URL,
    `${userId}/loan/BORROWER/searchEnachMandateApplicationLevel`,
    "POST",
    token,
    postdatastring
  );
  return response;
};

export const borrowerloaslistings = async (pageNo = 1, pageSize = 10) => {
  const token = getToken();
  const userId = getUserId();

  var fieldValueUser = "LENDER";
  var userUtm = "WEB";
  const postdatastring = JSON.stringify({
    leftOperand: {
      leftOperand: {
        fieldName: "userPrimaryType",
        fieldValue: fieldValueUser,
        operator: "EQUALS",
      },
      logicalOperator: "AND",
      rightOperand: {
        fieldName: "user.urchinTrackingModule",
        fieldValue: userUtm,
        operator: "EQUALS",
      },
    },
    logicalOperator: "AND",
    rightOperand: {
      fieldName: "parentRequestId",
      operator: "NULL",
    },
    page: {
      pageNo,
      pageSize,
    },
    sortBy: "userId",
    sortOrder: "DESC",
  });
  const response = await handleApiRequestAfterLoginService(
    API_BASE_URL,
    `${userId}/loan/BORROWER/request/search`,
    "POST",
    token,
    postdatastring
  );
  return response;
};

// export const getDisbursementAmount = async () => {
//   const token = getToken();
//   const userId = getUserId();
//   const response = await handleApiRequestAfterLoginService(
//     API_BASE_URL,
//     `getDisbursementAmount/${userId}`,
//     "GET",
//     token
//   );
//   return response;
// };

// export const generateBorrowerAgreement1 = async (payload) => {
//   const token = getToken();

//   const response = await handleApiRequestAfterLoginService(
//     API_BASE_URL,
//     "aggrementGenerationforBorrowerSide",
//     "POST",
//     token,
//     JSON.stringify(payload),
//   );

//   return response;
// };

// export const showingInterestAmountToBorrower = async (payload) => {
//   const token = getToken();
//   const response = await handleApiRequestAfterLoginService(
//     API_BASE_URL,
//     `showingInterestAmountToBorrower`,
//     "POST",
//     token,
//     payload
//   );
//   return response;
// };

// export const getCibilBasedRoi = async () => {
//   const token = getToken();
//   const userId = getUserId();
//   const response = await handleApiRequestAfterLoginService(
//     API_BASE_URL,
//     `${userId}/getCibilBasedRoi`,
//     "GET",
//     token
//   );
//   return response;
// };

// export const getBorrowerEligibleAmount = async () => {
//   const token = getToken();
//   const userId = getUserId();
//   const response = await handleApiRequestAfterLoginService(
//     API_BASE_URL,
//     `borrowerElgibleAmount/${userId}`,
//     "GET",
//     token
//   );
//   return response;
// };

// export const getBorrowerRequestAmount = async () => {
//   const token = getToken();
//   const userId = getUserId();
//   const requestedBorrowerId = userId;

//   const response = await handleApiRequestAfterLoginService(
//     API_BASE_URL,
//     `borrowerRequestAmount/${requestedBorrowerId}`,
//     "GET",
//     token
//   );
//   return response;
// };

// export const submitBorrowerLoanRequest = async (payload) => {
//   const token = getToken();
//   const response = await handleApiRequestAfterLoginService(
//     API_BASE_URL,
//     `borrowerLoanRequest`,
//     "PATCH",
//     token,
//     JSON.stringify(payload)
//   );
//   return response;
// };

// export const getListOfBorrowerLoansInitiated = async () => {
//   const token = getToken();
//   const userId = getUserId();
//   const requestedBorrowerId =   userId;

//   const response = await handleApiRequestAfterLoginService(
//     API_BASE_URL,
//     `listOfBorrowerLoansInitiated/${requestedBorrowerId}`,
//     "GET",
//     token
//   );
//   return response;
// };

// export const borrowerLoanAcceptOrReject = async (payload) => {
//   const token = getToken();
//   const response = await handleApiRequestAfterLoginService(
//     API_BASE_URL,
//     `borrowerLoanAccepteOrReject`,
//     "PATCH",
//     token,
//     JSON.stringify(payload)
//   );
//   return response;
// };

// export const borrowerLoanExcute = async (payload) => {
//   const token = getToken();
//   const response = await handleApiRequestAfterLoginService(
//     API_BASE_URL,
//     `borrowerLoanExcute`,
//     "POST",
//     token,
//     JSON.stringify(payload)
//   );
//   return response;
// };

// export const getLenderListNearByRedius1 = async (pageNo = 1, pageSize = 20) => {
//   const token = getToken();
//   const userId = getUserId();
//   const payload = {
//     pageNo,
//     pageSize,
//     userId: String(userId),
//   };
//   const response = await handleApiRequestAfterLoginService(
//     API_BASE_URL,
//     `getLenderListNearByRedius1`,
//     "POST",
//     token,
//     payload
//   );
//   return response;
// };

export const submitloanRequest = async (postdata) => {
  const token = getToken();
  const userId = getUserId();

  const postdatastring = JSON.stringify({
    duration: postdata.duration,
    durationType: postdata.durationType,
    expectedDate: postdata.expectedDate,
    loanPurpose: postdata.loanpurpose,
    loanRequestAmount: postdata.loanamount,
    rateOfInterest: postdata.roi,
    repaymentMethod: postdata.repayment,
  });
  const response = await handleApiRequestAfterLoginService(
    API_BASE_URL,
    `${userId}/loan/BORROWER/newrequest`,
    "POST",
    token,
    postdatastring
  );

  return response;
};

export const editloanNewRequestHold = async (status) => {
  const token = getToken();
  const userId = getUserId();
  const postdatastring = JSON.stringify({
    status: status,
  });
  const response = await handleApiRequestAfterLoginService(
    API_BASE_URL,
    `${userId}/loan/BORROWER/updateLoanRequest`,
    "PATCH",
    token,
    postdatastring
  );

  return response;
};

// export const getPCreditReportDoc = async () => {
//   const token = getToken();
//   const userId = getUserId();
//   const res = await handleApiRequestAfterLoginService(
//     API_BASE_URL,
//     `${userId}/download/CREDITREPORT`,
//     "GET",
//     token,
//   );
//   return res;
// };

export const getBorrowerRequestAmount = async () => {
  const token = getToken();
  const userId = getUserId();
  const requestedBorrowerId = userId;

  const response = await handleApiRequestAfterLoginService(
    API_BASE_URL,
    `borrowerRequestAmount/${requestedBorrowerId}`,
    "GET",
    token
  );
  return response;
};

export const getListOfBorrowerLoansInitiated = async () => {
  const token = getToken();
  const userId = getUserId();
  const requestedBorrowerId =   userId;

  const response = await handleApiRequestAfterLoginService(
    API_BASE_URL,
    `listOfBorrowerLoansInitiated/${requestedBorrowerId}`,
    "GET",
    token
  );
  return response;
};

export const borrowerLoanAcceptOrReject = async (payload) => {
  const token = getToken();
  const response = await handleApiRequestAfterLoginService(
    API_BASE_URL,
    `borrowerLoanAccepteOrReject`,
    "PATCH",
    token,
    JSON.stringify(payload)
  );
  return response;
};

export const borrowerLoanExcute = async (payload) => {
  const token = getToken();
  const response = await handleApiRequestAfterLoginService(
    API_BASE_URL,
    `borrowerLoanExcute`,
    "POST",
    token,
    JSON.stringify(payload)
  );
  return response;
};

// export const borrowerSecureInfo = async (payload) => {
//   const token = getToken();
//   const response = await handleApiRequestAfterLoginService(
//     API_BASE_URL,
//     `borrowerSecureInfo`,
//     "PATCH",
//     token,
//     JSON.stringify(payload)
//   );
//   return response;
// };

// export const getBorrowerSecureInfo = async () => {
//   const token = getToken();
//   const userId = getUserId();
//   const response = await handleApiRequestAfterLoginService(
//     API_BASE_URL,
//     `${userId}/borrower`,
//     "GET",
//     token
//   );
//   return response;
// };

export const submitBorrowerLoanRequest = async (payload) => {
  const token = getToken();
  const response = await handleApiRequestAfterLoginService(
    API_BASE_URL,
    `borrowerLoanRequest`,
    "PATCH",
    token,
    JSON.stringify(payload)
  );
  return response;
};

export const getCibilBasedRoi = async () => {
  const token = getToken();
  const userId = getUserId();
  const response = await handleApiRequestAfterLoginService(
    API_BASE_URL,
    `${userId}/getCibilBasedRoi`,
    "GET",
    token
  );
  return response;
};

export const getBorrowerEligibleAmount = async () => {
  const token = getToken();
  const userId = getUserId();
  const response = await handleApiRequestAfterLoginService(
    API_BASE_URL,
    `borrowerElgibleAmount/${userId}`,
    "GET",
    token
  );
  return response;
};

export const getDisbursementAmount = async () => {
  const token = getToken();
  const userId = getUserId();
  const response = await handleApiRequestAfterLoginService(
    API_BASE_URL,
    `getDisbursementAmount/${userId}`,
    "GET",
    token
  );
  return response;
};

export const showingInterestAmountToBorrower = async (payload) => {
  const token = getToken();
  const response = await handleApiRequestAfterLoginService(
    API_BASE_URL,
    `showingInterestAmountToBorrower`,
    "POST",
    token,
    payload
  );
  return response;
};

export const getLenderListNearByRedius1 = async (pageNo = 1, pageSize = 20) => {
  const token = getToken();
  const userId = getUserId();
  const payload = {
    pageNo,
    pageSize,
    userId: String(userId),
  };
  const response = await handleApiRequestAfterLoginService(
    API_BASE_URL,
    `getLenderListNearByRedius1`,
    "POST",
    token,
    payload
  );
  return response;
};


export const generateBorrowerAgreement1 = async (payload) => {
  const token = getToken();

  const response = await handleApiRequestAfterLoginService(
    API_BASE_URL,
    "aggrementGenerationforBorrowerSide",
    "POST",
    token,
    JSON.stringify(payload),
  );

  return response;
};


/////////// Lender ///////////

export const chatbotapicall = async (messages) => {
  const token = getToken();
  const userId = getUserId();
  try {
    const response = await axios({
      url: AI_CHAT_URL,
      method: "POST",
      timeout: 30000,
      headers: {
        "Content-Type": "application/json",
        accessToken: token,
        userId: userId,
      },
      data: { message: messages, primaryType: localStorage.getItem("primaryType") || "LENDER" },
    });
    return response;
  } catch (error) {
    if (!error.response) {
      error.response = {
        data: { answer: "Unable to reach the AI service. Please try again.", responseData: null },
      };
    }
    throw error;
  }
};

export const setLatLong = async () => {
  const token = getToken();
  const userId = getUserId();
  const postdata = {
    userId: userId,
  }
  const response = await handleApiRequestAfterLoginService(
    API_BASE_URL,
    `savingGoogleDistance`,
    "POST",
    token,
    postdata
  );
  return response;
}

export const getBorrowerDocuments = async (borrowerId) => {
  const token = getToken();
  const response = await handleApiRequestAfterLoginService(
    API_BASE_URL,
    `${borrowerId}/documents`,
    "GET",
    token
  );
  return response;
};

export const lenderInterestedBorrowers = async ({ 
  borrowerId, 
  lenderInterestedAmount, 
  roi, 
  duration, 
  lenderComments,
  durationType,
  repaymentMethodForLender 
}) => {
  const token = getToken();
  const lenderId = Number(getUserId());
  const data = {
    borrowerId: Number(borrowerId),
    lenderId,
    lenderInterestedAmount: Number(lenderInterestedAmount),
    roi: Number(roi),
    duration: Number(duration),
    durationType: durationType || "Days",
    repaymentMethodForLender: repaymentMethodForLender || "PI",
    lenderComments: lenderComments || "",
  };
  const response = await handleApiRequestAfterLoginService(
    API_BASE_URL,
    `lenderInterestedBorrowers`,
    "POST",
    token,
    data
  );
  return response;
};

export const getBorrowerListNearByRedius = async (pageNo, pageSize) => {
  const token = getToken();
  const userId = getUserId();
  let postdatastring = JSON.stringify({
    "pageNo": pageNo,
    "pageSize": pageSize,
    "userId": userId
  });

  const response = await handleApiRequestAfterLoginService(
    API_BASE_URL,
    `getBorrowerListNearByRedius1`,
    "POST",
    token,
    postdatastring
  );
   return response;
};

export const brLoanStatusApprovalByLr = async (id, status, loanRequestId) => {
  const token = getToken();
  const userId = getUserId();
  const data = {
    "loanRequestId":loanRequestId,
    "LenderId":userId,
    "lenderStatus":status,
    "id":id
}
  const response = await handleApiRequestAfterLoginService(
    API_BASE_URL,
    `brLoanStatusApprovalByLr`,
    "PATCH",
    token,
    data
  );
  return response;
};

export const loanAmountApproval = async (loanRequestId,id) => {
  const token = getToken();
  const userId = getUserId();
  const response = await handleApiRequestAfterLoginService(
    API_BASE_URL,
    `loanAmountApproval`,
    "POST",
    token,
    { loanId : loanRequestId, id, lenderId: userId }
  );
  return response;
}

export const getLoanAmountDeducted = async () => {
const token = getToken();
  const userId = getUserId();
  const response = await handleApiRequestAfterLoginService(
    API_BASE_URL,
    `getLoanAmountDeducted`,
    "POST",
    token,
    { lenderId: userId }
  );
  return response;
};

export const getOfferGivenList = async (pageNo = 1, pageSize = 10) => {
  const token = getToken();
  const userId = getUserId();
  const response = await handleApiRequestAfterLoginService(
    API_BASE_URL,
    `lenderLoansInitiated/${userId}`,
    "GET",
    token
  );
  return response;
};

export const getUserDetailsForBorrower = async (BorrowerId) => {
  const token = getToken();
  const userId = getUserId();
    const postdata = {
      userId: BorrowerId,
  };
  const response = await handleApiRequestAfterLoginService(
    API_BASE_URL,
    `getBorrowersInfo`,
    "POST",
    token,
    postdata
  );
  return response;
};

export const getBorrowerLoanDetails = async (borrowerId, loanId) => {
  const token = getToken();
  const userId = getUserId();
  const response = await handleApiRequestAfterLoginService(
    API_BASE_URL,
    `borrowerRequestAmount/${borrowerId}`,
    "GET",
    token
  );
  return response;
};

export const showingInterestAmountToLender = async (borrowerId,loanId) => {
   const token = getToken();
  const userId = getUserId();
  const data = {
    "borrowerId":borrowerId,
    "lenderId":userId,
    "loanId":loanId
  }
  const response = await handleApiRequestAfterLoginService(
    API_BASE_URL,
    `showingInterestAmountToLender`,
    "POST",
    token,
    data
  );
  return response

}

export const aggrementGenerationforLenderSide = async (payload) => {
  const token = getToken();

  const response = await handleApiRequestAfterLoginService(
    API_BASE_URL,
    "aggrementGenerationforLenderSide",
    "POST",
    token,
    payload,
  );

  return response;
};

// ── AI Layer API ──────────────────────────────────────────────────────────────
const AI_BASE_URL =
  `${MARKETPLACE_URL}/v1/ai/`;

export const getLenderAIPortfolio = async (lenderId) => {
  const token = getToken();
  const response = await axios.get(`${AI_BASE_URL}lender/${lenderId}/portfolio`, { headers: { accessToken: token } });
  return response;
};

/** Approved reactivation offers for the logged-in lender (GET /v1/ai/reactivation/offers/lender/{lenderId}). */
export const getUserReactivationOffers = async () => {
  const token = getToken();
  const lenderId = getUserId();
  if (!lenderId) {
    throw new Error("Not logged in. Please log in again.");
  }
  const response = await axios.get(
    `${MARKETPLACE_URL}/v1/ai/reactivation/offers/lender/${lenderId}`,
    {
      headers: { accessToken: token, "Content-Type": "application/json" },
      timeout: 60000,
    }
  );
  const body = response.data;
  if (body && typeof body.success === "boolean" && !body.success) {
    throw new Error(body.message || "Failed to load offers");
  }
  const list = Array.isArray(body?.data) ? body.data : [];
  // Map API offer → UI card shape (claimStatus / redeemed from user_offer_mapping after claim)
  return list.map((o) => {
    const redeemed =
      o.redeemed === true ||
      o.redeemed === "true" ||
      o.claimStatus === "CLAIMED" ||
      o.status === "CLAIMED";
    return {
      offerId: o.id ?? o.offerId,
      title: o.title,
      description: o.message || o.description,
      benefitSummary: o.benefitSummary,
      offerType: o.offerType,
      status: redeemed ? "CLAIMED" : "ACTIVE",
      claimStatus: redeemed ? "CLAIMED" : o.claimStatus || "ACTIVE",
      ctaUrl: o.ctaUrl,
      redeemed,
      assignedAt: o.approvedAt || o.assignedAt || o.generatedAt,
      claimedAt: o.claimedAt || null,
      expiresAt: o.expiresAt || null,
      minimumInvestment: o.minimumInvestment,
      participationFeeSaved: o.participationFeeSaved,
      validityDays: o.validityDays,
      freeSubscriptionMonths: o.freeSubscriptionMonths,
      grantsFreeSubscription: o.grantsFreeSubscription,
      subscriptionValidityDate: o.subscriptionValidityDate || null,
      subscriptionDiscountPercent: o.subscriptionDiscountPercent,
      subscriptionOriginalPrice: o.subscriptionOriginalPrice,
      subscriptionDiscountedPrice: o.subscriptionDiscountedPrice,
    };
  });
};

export const getLenderAIEarnings = async (lenderId, fy, from, to) => {
  let url = `${AI_BASE_URL}lender/${lenderId}/earnings`;
  const params = [];
  if (fy)   params.push(`fy=${fy}`);
  if (from) params.push(`from=${from}`);
  if (to)   params.push(`to=${to}`);
  if (params.length) url += "?" + params.join("&");
  const token = getToken();
  const response = await axios.get(url, { headers: { accessToken: token } });
  return response;
};

export const getLenderFyReport = async (lenderId, fromDate, toDate) => {
  const token = getToken();
  const response = await axios.get(
    `${AI_BASE_URL}lender/${lenderId}/fy-report?from=${fromDate}&to=${toDate}`,
    { headers: { accessToken: token } }
  );
  return response;
};

export const getLenderFyReportPdf = async (lenderId, fromDate, toDate) => {
  const token = getToken();
  const response = await axios.get(
    `${AI_BASE_URL}lender/${lenderId}/fy-report/pdf?from=${fromDate}&to=${toDate}`,
    { headers: { accessToken: token } }
  );
  return response;
};

export const getAdminAIPlatformStats = async (fy) => {
  let url = `${AI_BASE_URL}admin/platform-stats`;
  if (fy) url += `?fy=${fy}`;
  const token = getToken();
  const response = await axios.get(url, { headers: { accessToken: token } });
  return response;
};

export const getAdminAIReconciliationSummary = async () => {
  const token = getToken();
  const response = await axios.get(`${AI_BASE_URL}admin/reconciliation-summary`, { headers: { accessToken: token } });
  return response;
};

export const getAdminAIDashboardLive = async (fy, includeLenderRisk = false) => {
  const token = getToken();
  const headers = { accessToken: token };
  const params = [];
  if (fy) params.push(`fy=${fy}`);
  if (includeLenderRisk) params.push("includeLenderRisk=true");
  const query = params.length ? `?${params.join("&")}` : "";

  try {
    return await axios.get(`${AI_BASE_URL}admin/dashboard-live${query}`, { headers });
  } catch (primaryErr) {
    const [platformRes, reconRes] = await Promise.all([
      axios.get(`${AI_BASE_URL}admin/platform-stats${fy ? `?fy=${fy}` : ""}`, { headers }),
      axios.get(`${AI_BASE_URL}admin/reconciliation-summary`, { headers }),
    ]);
    const body = {
      apiVersion: "fallback-combined-v1",
      resource: "/v1/ai/admin/platform-stats + /v1/ai/admin/reconciliation-summary",
      generatedAt: new Date().toISOString(),
      platform: platformRes.data,
      reconciliation: reconRes.data,
    };
    if (includeLenderRisk) {
      try {
        const riskRes = await axios.get(`${AI_BASE_URL}admin/lenders/intelligence-summary`, { headers });
        body.lenderRisk = riskRes.data;
      } catch (riskErr) {
        body.lenderRiskError = riskErr?.response?.data?.error || riskErr.message;
      }
    }
    return { data: body, status: 200, request: primaryErr?.request };
  }
};

// ── Loan-module AI Admin APIs (one endpoint per dashboard section) ───────────
const adminAiLoanHeaders = () => {
  const token = getToken();
  if (!token) {
    const err = new Error("Not logged in. Go to /loginotp and login with admin mobile + OTP 1234.");
    err.code = "NO_TOKEN";
    throw err;
  }
  return { accessToken: token };
};

const parseApiError = (err) => {
  const status = err?.response?.status;
  const msg =
    err?.response?.data?.errorMessage ||
    err?.response?.data?.error ||
    err?.response?.data?.detail ||
    err.message;
  if (status === 401 || (msg && msg.toLowerCase().includes("session has expired"))) {
    return "Session expired. Please login again at /loginotp (OTP: 1234 on local backend).";
  }
  if (status === 404) {
    return "API not found (404). Restart backend: mvn spring-boot:run -Dspring-boot.run.profiles=test";
  }
  return msg || "Request failed";
};

export const getAdminAIDbHealth = async () => {
  const health = await axios.get(`${MARKETPLACE_URL}/healthCheck`);
  if (health.status !== 200) {
    throw new Error(`Backend health check failed (${health.status})`);
  }
  try {
    const db = await axios.get(`${API_USER_URL}verifyEndPoint-admin-ai-db-health`);
    return db;
  } catch {
    return {
      data: {
        status: "backend-online",
        database: "oxyloansprodtest",
        message: "Backend reachable via proxy. Login for live DB stats.",
      },
    };
  }
};

const adminAiLoanGet = async (path, fy) => {
  const q = fy != null ? `?fy=${fy}` : "";
  const url = `${API_USER_URL}admin/ai/${path}${q}`;
  try {
    return await axios.get(url, { headers: adminAiLoanHeaders() });
  } catch (loanErr) {
    if (loanErr?.code === "NO_TOKEN") throw loanErr;
    if (loanErr?.response?.status === 401) {
      const e = new Error(parseApiError(loanErr));
      e.code = "AUTH";
      throw e;
    }
    if (loanErr?.response?.status !== 404) throw loanErr;
    return null;
  }
};

const aiFallbackGet = async (path, fy) => {
  const headers = adminAiLoanHeaders();
  const q = fy != null ? `?fy=${fy}` : "";
  return axios.get(`${AI_BASE_URL}admin/${path}${q}`, { headers });
};

export const getAdminAIPlatformKpis = async (fy) => {
  const res = await adminAiLoanGet("platform-kpis", fy);
  if (res) return res;
  const fallback = await aiFallbackGet("platform-stats", fy);
  return {
    data: {
      displayName: "Platform KPIs",
      resource: "/v1/ai/admin/platform-stats",
      data: { kpis: fallback.data?.kpis || fallback.data },
    },
  };
};

export const getAdminAIUserGrowth = async (fy) => {
  const res = await adminAiLoanGet("user-growth", fy);
  if (res) return res;
  const fallback = await aiFallbackGet("platform-stats", fy);
  return {
    data: {
      displayName: "User Growth",
      resource: "/v1/ai/admin/platform-stats",
      data: { users: fallback.data?.users },
    },
  };
};

export const getAdminAITopLenders = async (fy) => {
  const res = await adminAiLoanGet("top-lenders", fy);
  if (res) return res;
  const fallback = await aiFallbackGet("platform-stats", fy);
  return {
    data: {
      displayName: "Top Lenders",
      resource: "/v1/ai/admin/platform-stats",
      data: {
        topLenders: fallback.data?.topLenders,
        fyLeaderboard: fallback.data?.fyLeaderboard,
      },
    },
  };
};

export const getAdminAITopDeals = async (fy) => {
  const res = await adminAiLoanGet("top-deals", fy);
  if (res) return res;
  const fallback = await aiFallbackGet("platform-stats", fy);
  return {
    data: {
      displayName: "Top Deals",
      resource: "/v1/ai/admin/platform-stats",
      data: { topDeals: fallback.data?.topDeals },
    },
  };
};

export const getAdminAIMonthlyPayoutTrend = async (fy) => {
  const res = await adminAiLoanGet("monthly-payout-trend", fy);
  if (res) return res;
  const fallback = await aiFallbackGet("platform-stats", fy);
  return {
    data: {
      displayName: "Monthly Payout Trend",
      resource: "/v1/ai/admin/platform-stats",
      data: {
        monthlyTrend: fallback.data?.monthlyTrend,
        fyHistory: fallback.data?.fyHistory,
      },
    },
  };
};

export const getAdminAICmsReconciliationDaily = async () => {
  const res = await adminAiLoanGet("cms-reconciliation-daily");
  if (res) return res;
  const fallback = await getAdminAIReconciliationSummary();
  return {
    data: {
      displayName: "CMS Daily Reconciliation",
      resource: "/v1/ai/admin/reconciliation-summary",
      data: { reconciliation: fallback.data },
    },
  };
};

export const getAdminAILenderRiskPortfolio = async () => {
  const res = await adminAiLoanGet("lender-risk-portfolio");
  if (res) return res;
  const fallback = await axios.get(`${AI_BASE_URL}admin/lenders/intelligence-summary`, {
    headers: adminAiLoanHeaders(),
  });
  return {
    data: {
      displayName: "Lender Risk Portfolio",
      resource: "/v1/ai/admin/lenders/intelligence-summary",
      data: { lenderRisk: fallback.data },
    },
  };
};

export const loadAdminAIDashboardSections = async (fy, includeRisk = false) => {
  const token = getToken();
  if (!token) {
    const err = new Error("Not logged in. Login at /loginotp with mobile + OTP 1234.");
    err.code = "NO_TOKEN";
    throw err;
  }

  const res = await getAdminAIDashboardLive(fy, includeRisk);
  const data = res.data || {};
  const platform = data.platform || data.platformKpis || {};
  const reconciliation = data.reconciliation || {};
  const resource = data.resource || "/v1/ai/admin/dashboard-live";
  const generatedAt = data.generatedAt;

  const wrap = (displayName, payload) => ({
    displayName,
    resource,
    generatedAt,
    apiVersion: data.apiVersion,
    data: payload,
  });

  const sections = {
    platformKpis: wrap("Platform KPIs", { kpis: platform.kpis || {} }),
    userGrowth: wrap("User Growth", { users: platform.users || {} }),
    topLenders: wrap("Top Lenders", {
      topLenders: platform.topLenders || [],
      fyLeaderboard: platform.fyLeaderboard || [],
    }),
    topDeals: wrap("Top Deals", { topDeals: platform.topDeals || [] }),
    monthlyTrend: wrap("Monthly Payout Trend", {
      monthlyTrend: platform.monthlyTrend || [],
      fyHistory: platform.fyHistory || [],
    }),
    reconciliation: wrap("CMS Daily Reconciliation", { reconciliation }),
  };

  if (includeRisk && data.lenderRisk) {
    sections.lenderRisk = wrap("Lender Risk Portfolio", { lenderRisk: data.lenderRisk });
  }

  const errors = [];
  if (data.platformError) errors.push({ key: "platform", message: data.platformError });
  if (data.reconciliationError) errors.push({ key: "reconciliation", message: data.reconciliationError });
  if (data.lenderRiskError) errors.push({ key: "lenderRisk", message: data.lenderRiskError });

  return { sections, errors, loadedAt: generatedAt || new Date().toISOString() };
};



// ============================================================
// MARKETPLACE APIs
// ============================================================

const MARKETPLACE_BASE_URL = MARKETPLACE_URL;

const marketplaceHeaders = () => {
  const token = getToken();
  const userId = getUserId();
  console.log("📦 MARKETPLACE HEADERS:", {
    token: token ? "✓ Present" : "✗ NULL/UNDEFINED",
    userId: userId ? "✓ Present" : "✗ NULL/UNDEFINED",
    tokenValue: token?.substring(0, 20) + "...",
  });
  return {
    "Content-Type": "application/json",
    accessToken: token,
    userId: userId,
  };
};

export const getMarketplaceLoans = async (lat, lng, radiusKm = 50, page = 0, size = 20) => {
  const params = new URLSearchParams({ page, size });
  if (lat != null) params.append("lat", lat);
  if (lng != null) params.append("lng", lng);
  if (radiusKm != null) params.append("radiusKm", radiusKm);
  return axios.get(`${MARKETPLACE_URL}/v1/marketplace/loans?${params.toString()}`, {
    headers: marketplaceHeaders(),
  });
};

export const postMarketplaceLoanRequest = async (data) => {
  return axios.post(`${MARKETPLACE_URL}/v1/marketplace/loans`, data, {
    headers: marketplaceHeaders(),
  });
};

export const getMyMarketplaceLoans = async () => {
  return axios.get(`${MARKETPLACE_URL}/v1/marketplace/loans/my`, {
    headers: marketplaceHeaders(),
  });
};

export const withdrawMarketplaceLoan = async (loanRequestId) => {
  return axios.delete(`${MARKETPLACE_URL}/v1/marketplace/loans/${loanRequestId}`, {
    headers: marketplaceHeaders(),
  });
};

export const getMarketplaceLoanDetail = async (loanRequestId) => {
  return axios.get(`${MARKETPLACE_URL}/v1/marketplace/loans/${loanRequestId}`, {
    headers: marketplaceHeaders(),
  });
};

// ============================================================
// NEGOTIATION APIs
// ============================================================

export const makeNegotiationOffer = async (data) => {
  return axios.post(`${MARKETPLACE_URL}/v1/negotiation/offer`, data, {
    headers: marketplaceHeaders(),
  });
};

export const counterNegotiationOffer = async (offerId, counterRate) => {
  return axios.put(`${MARKETPLACE_URL}/v1/negotiation/${offerId}/counter`, { counterRate }, {
    headers: marketplaceHeaders(),
  });
};

export const acceptNegotiationOffer = async (offerId) => {
  return axios.put(`${MARKETPLACE_URL}/v1/negotiation/${offerId}/accept`, {}, {
    headers: marketplaceHeaders(),
  });
};

export const rejectNegotiationOffer = async (offerId) => {
  return axios.put(`${MARKETPLACE_URL}/v1/negotiation/${offerId}/reject`, {}, {
    headers: marketplaceHeaders(),
  });
};

export const getNegotiationOffers = async (loanRequestId) => {
  return axios.get(`${MARKETPLACE_URL}/v1/negotiation/loan/${loanRequestId}`, {
    headers: marketplaceHeaders(),
  });
};

// ============================================================
// CONSENT APIs
// ============================================================

export const submitBorrowerConsent = async (loanRequestId, checkedBoxes) => {
  return axios.post(`${MARKETPLACE_URL}/v1/consent/borrower`, { loanRequestId, checkedBoxes }, {
    headers: marketplaceHeaders(),
  });
};

export const submitLenderConsent = async (loanRequestId, checkedBoxes) => {
  return axios.post(`${MARKETPLACE_URL}/v1/consent/lender`, { loanRequestId, checkedBoxes }, {
    headers: marketplaceHeaders(),
  });
};

export const getConsentStatus = async (loanRequestId, lenderUserId) => {
  const params = lenderUserId ? `?lenderUserId=${lenderUserId}` : "";
  return axios.get(`${MARKETPLACE_URL}/v1/consent/${loanRequestId}/status${params}`, {
    headers: marketplaceHeaders(),
  });
};

// ============================================================
// FEE APIs
// ============================================================

export const calculateFees = async (loanAmount, loanType = "MARKETPLACE") => {
  return axios.get(`${MARKETPLACE_URL}/v1/fees/calculate?loanAmount=${loanAmount}&loanType=${loanType}`, {
    headers: marketplaceHeaders(),
  });
};

export const getMyLenderOffers = async () => {
  return axios.get(`${MARKETPLACE_URL}/v1/negotiation/my-offers`, {
    headers: marketplaceHeaders(),
  });
};

// ============================================================
// PROXIMITY APIs
// ============================================================

export const getNearbyBorrowers = async (lat, lng, radiusKm = 50, page = 0, size = 100) => {
  return axios.get(`${MARKETPLACE_URL}/v1/marketplace/nearby-borrowers?lat=${lat}&lng=${lng}&radiusKm=${radiusKm}&page=${page}&size=${size}`, {
    headers: marketplaceHeaders(),
  });
};

export const getNearbyLenders = async (lat, lng, radiusKm = 50) => {
  return axios.get(`${MARKETPLACE_URL}/v1/marketplace/nearby-lenders?lat=${lat}&lng=${lng}&radiusKm=${radiusKm}`, {
    headers: marketplaceHeaders(),
  });
};

export const filterMarketplaceLoans = async (filters = {}) => {
  const params = new URLSearchParams();
  const allowed = [
    "lat", "lng", "radiusKm",
    "company", "pincode", "city", "college", "industry",
    "minOxyScore", "minAmount", "maxAmount",
    "minDuration", "maxDuration", "borrowerType", "sortBy",
  ];
  allowed.forEach((key) => {
    if (filters[key] != null && filters[key] !== "") {
      params.append(key, filters[key]);
    }
  });
  return axios.get(`${MARKETPLACE_URL}/v1/marketplace/loan-filter?${params.toString()}`, {
    headers: marketplaceHeaders(),
  });
};

// ============================================================
// ESCALATION APIs
// ============================================================

export const getMyEscalationLoans = async () => {
  return axios.get(`${MARKETPLACE_URL}/v1/escalation/my-loans`, {
    headers: marketplaceHeaders(),
  });
};

export const getLoanEscalationStatus = async (loanId) => {
  return axios.get(`${MARKETPLACE_URL}/v1/escalation/loan/${loanId}`, {
    headers: marketplaceHeaders(),
  });
};

// ============================================================
// EMI DASHBOARD APIs  (Phase 5)
// ============================================================

export const getLenderEmiDashboard = async () => {
  return axios.get(`${MARKETPLACE_URL}/v1/marketplace/emi/lender`, {
    headers: marketplaceHeaders(),
  });
};

export const getBorrowerEmiSchedule = async () => {
  return axios.get(`${MARKETPLACE_URL}/v1/marketplace/emi/borrower`, {
    headers: marketplaceHeaders(),
  });
};

// ============================================================
// MARKETPLACE ADMIN STATS APIs  (Phase 6)
// ============================================================

export const getMarketplaceAdminStats = async () => {
  return axios.get(`${MARKETPLACE_URL}/v1/marketplace/admin/stats`, {
    headers: marketplaceHeaders(),
  });
};

export const getMarketplaceAdminLoans = async (status = "", page = 0, size = 20) => {
  const params = new URLSearchParams({ page, size });
  if (status) params.append("status", status);
  return axios.get(`${MARKETPLACE_URL}/v1/marketplace/admin/loans?${params.toString()}`, {
    headers: marketplaceHeaders(),
  });
};

export const getMarketplacePendingApproval = async () => {
  return axios.get(`${MARKETPLACE_URL}/v1/marketplace/admin/pending-approval`, {
    headers: marketplaceHeaders(),
  });
};

export const approveMarketplaceLoan = async (loanRequestId, remarks = "") => {
  return axios.put(
    `${MARKETPLACE_URL}/v1/marketplace/admin/${loanRequestId}/approve?remarks=${encodeURIComponent(remarks)}`,
    {},
    { headers: marketplaceHeaders() }
  );
};

export const rejectMarketplaceLoan = async (loanRequestId, remarks = "") => {
  return axios.put(
    `${MARKETPLACE_URL}/v1/marketplace/admin/${loanRequestId}/reject?remarks=${encodeURIComponent(remarks)}`,
    {},
    { headers: marketplaceHeaders() }
  );
};

// ============================================================
// CIBIL / OxyScore APIs  (Phase 4)
// ============================================================

export const uploadCibilPdf = async (formData) => {
  // Do NOT set Content-Type here — let the browser auto-set multipart/form-data with boundary
  return axios.post(`${MARKETPLACE_URL}/v1/cibil/upload`, formData, {
    headers: {
      accessToken: getToken(),
      userId: getUserId(),
    },
  });
};

export const getMyOxyScore = async () => {
  return axios.get(`${MARKETPLACE_URL}/v1/cibil/my-score`, {
    headers: marketplaceHeaders(),
  });
};

export const registerMarketplaceEnach = async (data) => {
  return axios.post(`${MARKETPLACE_URL}/v1/marketplace/enach/register`, data, {
    headers: marketplaceHeaders(),
  });
};

// ============================================================
// AI SMART LOAN MATCHING  (Phase 7)
// ============================================================

export const getSmartLoanMatches = async (preferences = {}) => {
  return axios.post(`${MARKETPLACE_URL}/v1/ai/smart-match`, preferences, {
    headers: marketplaceHeaders(),
  });
};

// ============================================================
// NOTIFICATIONS APIs  (Phase 7)
// ============================================================

export const getMyNotifications = async () => {
  return axios.get(`${MARKETPLACE_URL}/v1/notifications/my`, {
    headers: marketplaceHeaders(),
  });
};

// export const getNotificationCount = async () => {
//   return axios.get(`${MARKETPLACE_URL}/v1/notifications/count`, {
//     headers: marketplaceHeaders(),
//   });
// };

export const markNotificationRead = async (id) => {
  return axios.put(
    `${MARKETPLACE_URL}/v1/notifications/${id}/read`,
    {},
    { headers: marketplaceHeaders() }
  );
};

export const markAllNotificationsRead = async () => {
  return axios.put(
    `${MARKETPLACE_URL}/v1/notifications/read-all`,
    {},
    { headers: marketplaceHeaders() }
  );
};

// ============================================================
// EMI PAYMENT API
// ============================================================

export const payMarketplaceEmi = async (loanRequestId, emiNo) => {
  return axios.post(
    `${MARKETPLACE_URL}/v1/marketplace/emi/pay`,
    { loanRequestId, emiNo },
    { headers: marketplaceHeaders() }
  );
};

// ============================================================
// ADMIN DISBURSAL CONTROL APIs  (Task 3)
// ============================================================

export const getAdminPendingDisbursalLoans = async () =>
  axios.get(`${MARKETPLACE_URL}/v1/admin/disbursal/pending-disbursal`, {
    headers: marketplaceHeaders(),
  });

export const setDisbursalDate = async (loanId, disbursalDate, remarks = "") =>
  axios.put(
    `${MARKETPLACE_URL}/v1/admin/disbursal/${loanId}/disbursal-date`,
    { disbursalDate, remarks },
    { headers: marketplaceHeaders() }
  );

export const setRepaymentDate = async (loanId, data) =>
  axios.put(
    `${MARKETPLACE_URL}/v1/admin/disbursal/${loanId}/repayment-date`,
    data,
    { headers: marketplaceHeaders() }
  );

export const triggerDisbursal = async (loanId, remarks = "") =>
  axios.post(
    `${MARKETPLACE_URL}/v1/admin/disbursal/${loanId}/trigger-disbursal`,
    { remarks },
    { headers: marketplaceHeaders() }
  );

export const bulkUpdateDisbursalDates = async (loanIds, disbursalDate, firstRepaymentDate) =>
  axios.put(
    `${MARKETPLACE_URL}/v1/admin/disbursal/bulk-update-dates`,
    { loanIds, disbursalDate, firstRepaymentDate },
    { headers: marketplaceHeaders() }
  );

export const getDisbursalAuditLog = async (loanId) =>
  axios.get(`${MARKETPLACE_URL}/v1/admin/disbursal/${loanId}/audit-log`, {
    headers: marketplaceHeaders(),
  });

// ============================================================
// BORROWER MY-LOANS APIs  (Task 6)
// ============================================================

export const getBorrowerActiveLoans = async () => {
  const userId = getUserId();
  return axios.get(`${MARKETPLACE_URL}/v1/marketplace/emi/borrower/${userId}/active-loans`, {
    headers: marketplaceHeaders(),
  });
};

export const getBorrowerEmiScheduleForLoan = async (loanId) =>
  axios.get(`${MARKETPLACE_URL}/v1/marketplace/emi/${loanId}/schedule`, {
    headers: marketplaceHeaders(),
  });

export const completeEsign = async (loanRequestId, assignmentId) => {
  const params = {};
  if (assignmentId) params.assignmentId = assignmentId;
  const body = {};
  if (assignmentId) body.assignmentId = assignmentId;

  return axios.post(`${MARKETPLACE_URL}/v1/marketplace/agreement/${loanRequestId}/esign-complete`, body, {
    params,
    headers: marketplaceHeaders(),
  });
};

// ============================================================
// LENDER PORTFOLIO APIs  (Task 7)
// ============================================================

export const getLenderPortfolio = async () => {
  const userId = getUserId();
  return axios.get(`${MARKETPLACE_URL}/v1/marketplace/emi/lender/${userId}/portfolio`, {
    headers: marketplaceHeaders(),
  });
};

// ============================================================
// ADMIN SETTINGS APIs  (Feature 2)
// ============================================================

export const getAdminSettings = () =>
  axios.get(`${MARKETPLACE_URL}/v1/admin/settings`, { headers: marketplaceHeaders() });

export const getAdminSettingsChangelog = () =>
  axios.get(`${MARKETPLACE_URL}/v1/admin/settings/changelog`, { headers: marketplaceHeaders() });

export const updateAdminSetting = (key, value, remarks = "") =>
  axios.put(
    `${MARKETPLACE_URL}/v1/admin/settings/${key}`,
    { value, adminName: localStorage.getItem("userName") || "Admin", remarks },
    { headers: marketplaceHeaders() }
  );

export const updateAdminSettingsBulk = (settings, remarks = "Bulk update") =>
  axios.put(
    `${MARKETPLACE_URL}/v1/admin/settings`,
    { settings, adminName: localStorage.getItem("userName") || "Admin", remarks },
    { headers: marketplaceHeaders() }
  );

// ============================================================
// FEE DISCLOSURE APIs  (Feature 5)
// ============================================================

export const getFeeDisclosure = (loanRequestId) =>
  axios.get(`${MARKETPLACE_URL}/v1/fees/disclosure/${loanRequestId}`, {
    headers: marketplaceHeaders(),
  });

export const acceptFeeDisclosure = (loanRequestId) =>
  axios.post(
    `${MARKETPLACE_URL}/v1/fees/disclosure/${loanRequestId}/accept`,
    {},
    { headers: marketplaceHeaders() }
  );

// ============================================================
// LOAN FUNDING APIs  (Feature 4)
// ============================================================

export const getLoanFundingStatus = (loanRequestId) =>
  axios.get(`${MARKETPLACE_URL}/v1/marketplace/funding/${loanRequestId}`, {
    headers: marketplaceHeaders(),
  });

export const commitLoanFunding = (loanRequestId, amount) =>
  axios.post(
    `${MARKETPLACE_URL}/v1/marketplace/funding/${loanRequestId}/commit`,
    { amount },
    { headers: marketplaceHeaders() }
  );

export const acceptPartialFunding = (loanRequestId) =>
  axios.post(
    `${MARKETPLACE_URL}/v1/marketplace/funding/${loanRequestId}/accept-partial`,
    {},
    { headers: marketplaceHeaders() }
  );

// ============================================================
// MARKETPLACE REPAYMENT APIs  (Feature 9)
// ============================================================

export const getRepaymentByLoan = (loanRequestId) =>
  axios.get(`${MARKETPLACE_URL}/v1/marketplace/repayment/loan/${loanRequestId}`, {
    headers: marketplaceHeaders(),
  });

export const payRepayment = (repaymentId) =>
  axios.post(
    `${MARKETPLACE_URL}/v1/marketplace/repayment/${repaymentId}/pay`,
    {},
    { headers: marketplaceHeaders() }
  );

export const bounceRepayment = (repaymentId, reason = "") =>
  axios.post(
    `${MARKETPLACE_URL}/v1/marketplace/repayment/${repaymentId}/bounce`,
    { reason },
    { headers: marketplaceHeaders() }
  );

export const getPendingRepayments = () =>
  axios.get(`${MARKETPLACE_URL}/v1/marketplace/repayment/pending`, {
    headers: marketplaceHeaders(),
  });

// ============================================================
// ADMIN DISBURSAL CHECKLIST APIs  (Feature 7)
// ============================================================

export const getDisbursalChecklist = (loanId) =>
  axios.get(`${MARKETPLACE_URL}/v1/admin/disbursal/${loanId}/checklist`, {
    headers: marketplaceHeaders(),
  });

export const approveAndDisburse = (loanId) =>
  axios.post(
    `${MARKETPLACE_URL}/v1/admin/disbursal/${loanId}/approve-and-disburse`,
    {},
    { headers: marketplaceHeaders() }
  );

// ============================================================
// OXYSCORE MARKETPLACE APIs  (Feature 6)
// ============================================================

export const getMarketplaceOxyScore = (borrowerUserId) =>
  axios.get(`${MARKETPLACE_URL}/v1/cibil/marketplace-score/${borrowerUserId}`, {
    headers: marketplaceHeaders(),
  });

// ============================================================
// COLLECTIONS APIs
// ============================================================

export const getCollectionStats = () =>
  axios.get(`${MARKETPLACE_URL}/v1/collections/stats`, { headers: marketplaceHeaders() });

export const getCollectionCases = (status = "") =>
  axios.get(`${MARKETPLACE_URL}/v1/collections/cases?status=${status}`, { headers: marketplaceHeaders() });

export const getCollectionCase = (caseId) =>
  axios.get(`${MARKETPLACE_URL}/v1/collections/cases/${caseId}`, { headers: marketplaceHeaders() });

export const assignCollectionAgent = (caseId, agentId, agentName) =>
  axios.post(`${MARKETPLACE_URL}/v1/collections/cases/${caseId}/assign`,
    { agentId, agentName }, { headers: marketplaceHeaders() });

export const logCollectionAction = (caseId, actionType, note, outcome) =>
  axios.post(`${MARKETPLACE_URL}/v1/collections/cases/${caseId}/action`,
    { actionType, note, outcome }, { headers: marketplaceHeaders() });

export const updateCollectionStatus = (caseId, status, note = "") =>
  axios.put(`${MARKETPLACE_URL}/v1/collections/cases/${caseId}/status`,
    { status, note }, { headers: marketplaceHeaders() });

export const getMyCollectionCases = () =>
  axios.get(`${MARKETPLACE_URL}/v1/collections/my-cases`, { headers: marketplaceHeaders() });

export const syncCollections = () =>
  axios.post(`${MARKETPLACE_URL}/v1/collections/sync`, {}, { headers: marketplaceHeaders() });

export const getPCreditReportDoc = async (password) => {
  const token = getToken();
  const userId = getUserId();
  const queryParam = password ? `?password=${encodeURIComponent(password)}` : "";
  const res = await handleApiRequestAfterLoginService(
    API_BASE_URL,
    `${userId}/download/CREDITREPORT${queryParam}`,
    "GET",
    token
  );
  return res;
};

export const borrowerSecureInfo = (payload) =>
  axios.patch(`${API_BASE_URL}borrowerSecureInfo`, payload, {
    headers: { accessToken: getToken(), "Content-Type": "application/json" },
  });

export const getBorrowerSecureInfo = () => {
  const userId = sessionStorage.getItem("userId") || localStorage.getItem("userId") || getUserId();
  return axios.get(`${API_BASE_URL}${userId}/borrower`, {
    headers: { accessToken: getToken(), accesstoken: getToken() },
  });
};
export const getRadiusBasedFee = async () => {
  const token = getToken();
  const response = await handleApiRequestAfterLoginService(
    API_BASE_URL,
    `getRadiusBasedfee`,
    "GET",
    token
  );
  return response;
};

export const getBorrowerCibilScore = async () => {
  const token = getToken();
  const response = await handleApiRequestAfterLoginService(
    API_BASE_URL,
    `getBorrowerCibilScore`,
    "GET",
    token
  );
  return response;
};

export const saveBorrowerReferenceDetails = (payload) =>
  axios.patch(`${API_BASE_URL}borrowerReferenceDetails`, payload, {
    headers: { accessToken: getToken(), "Content-Type": "application/json" },
  });

export const getBorrowerReferenceDetails = (userId) => {
  const uId = userId || getUserId();
  return axios.get(`${API_BASE_URL}${uId}/borrowerReferenceDetails`, {
    headers: { accessToken: getToken() },
  });
};

export const lenderBorrowerEsign = async (loanId, aadharNumber, assignmentId, redirectUrl) => {
  const token = getToken();
  const userId = getUserId();

  let targetUrl = redirectUrl;
  if (!targetUrl) {
    targetUrl = assignmentId
      ? `${window.location.origin}/lender_esign/${loanId}/${assignmentId}`
      : `${window.location.origin}/lender_esign/${loanId}`;
  }

  const queryParams = [];
  if (aadharNumber) queryParams.push(`aadharNumber=${encodeURIComponent(aadharNumber)}`);
  if (assignmentId) queryParams.push(`assignmentId=${encodeURIComponent(assignmentId)}`);
  queryParams.push(`url=${encodeURIComponent(targetUrl)}`);

  const queryString = `?${queryParams.join("&")}`;

  const body = {
    url: targetUrl,
  };
  if (assignmentId) body.assignmentId = assignmentId;
  if (aadharNumber) body.aadharNumber = aadharNumber;

  const response = await handleApiRequestAfterLoginService(
    API_BASE_URL,
    `${userId}/loan/${loanId}/lenderBorrowerEsign${queryString}`,
    "POST",
    token,
    body
  );
  return response;
};

// Cashfree eSign + eNACH Frontend APIs
export const startCashfreeEsign = async (loanRequestId, aadharNumber, assignmentId, redirectUrl) => {
  const token = getToken();
  const userId = getUserId();

  let targetUrl = redirectUrl;
  if (!targetUrl) {
    targetUrl = assignmentId
      ? `${window.location.origin}/esign/${loanRequestId}?assignmentId=${assignmentId}`
      : `${window.location.origin}/esign/${loanRequestId}`;
  }

  const params = {};
  if (aadharNumber) params.aadharNumber = aadharNumber;
  if (assignmentId) params.assignmentId = assignmentId;
  params.url = targetUrl;

  const body = {
    url: targetUrl,
  };
  if (assignmentId) body.assignmentId = assignmentId;
  if (aadharNumber) body.aadharNumber = aadharNumber;

  return axios.post(
    `${API_BASE_URL}${userId}/loan/${loanRequestId}/lenderBorrowerEsign`,
    body,
    {
      params,
      headers: {
        "Content-Type": "application/json",
        accesstoken: token,
        accessToken: token,
      },
    }
  );
};

export const completeCashfreeEsign = async (loanRequestId, assignmentId) => {
  const token = getToken();
  const userId = getUserId();
  const params = {};
  if (assignmentId) params.assignmentId = assignmentId;

  const body = {};
  if (assignmentId) body.assignmentId = assignmentId;

  return axios.post(
    `${API_BASE_URL}${userId}/loan/${loanRequestId}/uploadAgreementForLRAndBr`,
    body,
    {
      params,
      headers: {
        "Content-Type": "application/json",
        accessToken: token,
        accesstoken: token,
      },
    }
  );
};

export const listBorrowerLoanEnachMandates = async (loanRequestId, assignmentId = null) => {
  const token = getToken();
  const userId = getUserId();
  const queryParam = assignmentId ? `?assignmentId=${assignmentId}` : "";
  return axios.get(
    `${API_BASE_URL}${userId}/loan/${loanRequestId}/borrowerLoanEnachMandates${queryParam}`,
    {
      headers: {
        accesstoken: token,
        accessToken: token,
      },
    }
  );
};

export const startCashfreeEnachAuthorization = async (mandateId) => {
  const token = getToken();
  const userId = getUserId();
  return axios.post(
    `${API_BASE_URL}${userId}/loan/borrowerLoanCashfreeEnach/${mandateId}/start`,
    null,
    {
      headers: {
        accesstoken: token,
        accessToken: token,
      },
    }
  );
};

export const getCashfreeEnachStatus = async (mandateId) => {
  const token = getToken();
  const userId = getUserId();
  return axios.get(
    `${API_BASE_URL}${userId}/loan/borrowerLoanCashfreeEnach/${mandateId}/status`,
    {
      headers: {
        accesstoken: token,
        accessToken: token,
      },
    }
  );
};

export const raiseCashfreeEnachCharge = async (emiCardId) => {
  const token = getToken();
  const userId = getUserId();
  return axios.post(
    `${API_BASE_URL}${userId}/loan/borrowerLoanCashfreeEnach/emi/${emiCardId}/raiseCharge`,
    null,
    {
      headers: {
        accesstoken: token,
        accessToken: token,
      },
    }
  );
};

export const cancelCashfreeEnach = async (mandateId) => {
  const token = getToken();
  const userId = getUserId();
  return axios.post(
    `${API_BASE_URL}${userId}/loan/borrowerLoanCashfreeEnach/${mandateId}/cancel`,
    null,
    {
      headers: {
        accesstoken: token,
        accessToken: token,
      },
    }
  );
};

export const getenachStatus = async (loanRequestId) => {
  const token = getToken();
  const userId = getUserId();
  return axios.get(
    `${API_BASE_URL}${userId}/loan/${loanRequestId}/borrowerLoanEnachStatus`,
    {
      headers: {
        accesstoken: token,
        accessToken: token,
      },
    }
  );
};

export const adminReverseFalsePaidEmi = async (emiCardId, reason = "false paid without debit", force = "false") => {
  const token = getToken();
  const userId = getUserId();
  return axios.post(
    `${API_BASE_URL}${userId}/loan/borrowerLoanCashfreeEnach/emi/${emiCardId}/reverseFalsePaid`,
    null,
    {
      params: { reason, force },
      headers: {
        accesstoken: token,
      },
    }
  );
};

export const adminReconcilePaidEmis = async () => {
  const token = getToken();
  const userId = getUserId();
  return axios.post(
    `${API_BASE_URL}${userId}/loan/borrowerLoanCashfreeEnach/reconcilePaidEmis`,
    null,
    {
      headers: {
        accesstoken: token,
      },
    }
  );
};

// Borrower Loan EMI Cards API
export const getBorrowerLoanEmiCards = async (loanRequestId) => {
  const token = getToken();
  const userId = getUserId();

  return handleApiRequestAfterLoginService(
    API_BASE_URL,
    `${userId}/loan/${loanRequestId}/loanEmiCards`,
    "GET",
    token
  );
};

export const getLoanEmiCards = getBorrowerLoanEmiCards;
export const borrowerLoanEmiCards = getBorrowerLoanEmiCards;

// Admin Proximity Loan Overview API
export const getAdminProximityLoanOverview = async (params = {}) => {
  const token = getToken();
  const userId = getUserId();

  const queryParams = new URLSearchParams();
  if (params.page !== undefined) queryParams.append("page", params.page);
  if (params.size !== undefined) queryParams.append("size", params.size);
  if (params.radiusKm !== undefined) queryParams.append("radiusKm", params.radiusKm);
  if (params.status) queryParams.append("status", params.status);
  if (params.city) queryParams.append("city", params.city);
  if (params.pincode) queryParams.append("pincode", params.pincode);

  const queryString = queryParams.toString() ? `?${queryParams.toString()}` : "";

  try {
    return await handleApiRequestAfterLoginService(
      API_BASE_URL,
      `admin/proximityLoanOverview${queryString}`,
      "GET",
      token
    );
  } catch (e) {
    try {
      return await axios.get(`${MARKETPLACE_URL}/v1/admin/proximityLoanOverview${queryString}`, {
        headers: marketplaceHeaders(),
      });
    } catch (err) {
      return await axios.get(`${API_BASE_URL}admin/proximityLoanOverview${queryString}`, {
        headers: { accesstoken: token, accessToken: token },
      });
    }
  }
};

export const getProximityLoanOverview = getAdminProximityLoanOverview;
export const adminProximityLoanOverview = getAdminProximityLoanOverview;

export const deductBorrowerLoanDisbursementWallet = async (payload) => {
  const token = getToken();
  const response = await handleApiRequestAfterLoginService(
    API_BASE_URL,
    "admin/borrowerLoanDisbursementFile",
    "POST",
    token,
    payload
  );
  return response;
};

export const getBorrowerLoanGeneratedFiles = async () => {
  const token = getToken();
  const response = await handleApiRequestAfterLoginService(
    API_BASE_URL,
    "admin/borrowerLoanGeneratedFiles",
    "GET",
    token
  );
  return response;
};

// ============================================================
// BANK STATEMENT ANALYSIS & REPORT APIS
// ============================================================

/**
 * Upload & Analyze Bank Statement for Borrower
 * Endpoint: POST /v1/user/borrower/:borrowerId/analyze
 * Supports form-data with 'file' and 'password' matching backend API requirements
 */
export const analyzeBorrowerBankStatement = async (borrowerId, fileOrPassword = "", password = "") => {
  const token = getToken();
  const userId = borrowerId || getUserId();
  
  let isFile = false;
  let fileObj = null;
  let passVal = "";

  if (fileOrPassword && typeof fileOrPassword === "object" && (fileOrPassword instanceof File || fileOrPassword.name)) {
    isFile = true;
    fileObj = fileOrPassword;
    passVal = password || "";
  } else if (typeof fileOrPassword === "string") {
    passVal = fileOrPassword || password || "";
  }

  let body = {};
  let config = {
    headers: {
      accessToken: token,
      accesstoken: token,
      userId: userId,
    },
  };

  if (isFile) {
    const formData = new FormData();
    formData.append("file", fileObj);
    if (passVal) {
      formData.append("password", passVal);
    }
    body = formData;
  } else {
    body = passVal ? { password: passVal, bankStatementPassword: passVal } : {};
    config.params = passVal ? { password: passVal } : {};
  }

  try {
    return await axios.post(
      `${API_BASE_URL}borrower/${userId}/analyze`,
      body,
      config
    );
  } catch (e) {
    return await axios.post(
      `${MARKETPLACE_URL}/v1/user/borrower/${userId}/analyze`,
      body,
      config
    );
  }
};

/**
 * Get Bank Statement Analysis Summary for Borrower
 * Endpoint: GET /v1/user/borrower/:borrowerId
 */
export const getBorrowerAnalysis = async (borrowerId) => {
  const token = getToken();
  const userId = borrowerId || getUserId();
  try {
    return await axios.get(`${MARKETPLACE_URL}/v1/user/borrower/${userId}`, {
      headers: {
        accessToken: token,
        accesstoken: token,
        userId: userId,
      },
    });
  } catch (e) {
    return await axios.get(`${API_BASE_URL}borrower/${userId}`, {
      headers: {
        accessToken: token,
        accesstoken: token,
        userId: userId,
      },
    });
  }
};

/**
 * Get Specific Statement Details by Statement ID
 * Endpoint: GET /v1/user/:statementId/borrower
 */
export const getBorrowerStatementById = async (statementId) => {
  const token = getToken();
  const userId = getUserId();
  try {
    return await axios.get(`${MARKETPLACE_URL}/v1/user/${statementId}/borrower`, {
      headers: {
        accessToken: token,
        accesstoken: token,
        userId: userId,
      },
    });
  } catch (e) {
    return await axios.get(`${API_BASE_URL}${statementId}/borrower`, {
      headers: {
        accessToken: token,
        accesstoken: token,
        userId: userId,
      },
    });
  }
};

/**
 * Download / View Bank Statement PDF Analysis Report
 * Endpoint: GET /v1/user/:id/report/pdf/user
 */
export const getBorrowerReportPdfUser = async (id) => {
  const token = getToken();
  const userId = getUserId();
  const targetId = id || userId;
  try {
    return await axios.get(`${MARKETPLACE_URL}/v1/user/${targetId}/report/pdf/user`, {
      responseType: "blob",
      headers: {
        accessToken: token,
        accesstoken: token,
        userId: userId,
      },
    });
  } catch (e) {
    try {
      return await axios.get(`${MARKETPLACE_URL}/v1/borrower/${targetId}/report/pdf/user`, {
        responseType: "blob",
        headers: {
          accessToken: token,
          accesstoken: token,
          userId: userId,
        },
      });
    } catch (err) {
      return await axios.get(`${API_BASE_URL}${targetId}/report/pdf/user`, {
        responseType: "blob",
        headers: {
          accessToken: token,
          accesstoken: token,
          userId: userId,
        },
      });
    }
  }
};

export const getBorrowerCreditReport = async (id) => {
  const userId = getUserId();
  const token = getToken();
  const response = await handleApiRequestAfterLoginService(
    API_BASE_URL,
    `${id}/adminCreditReport`,
    "GET",
    token
  );
  return response;
};

export const fetchPaysprintCreditReport = async (payload) => {
  const token = getToken();

  return (
    {
    "success": true,
    "httpStatus": 200,
    "tokenUsed": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0aW1lc3RhbXAiOjE3OTA5MjQ4MjEsInBhcnRuZXJJZCI6IkNPUlAwMDAwMjY4MCIsInJlcWlkIjozOTA5OTgyMjZ9.v8isXl68yVsYgwkqGL52Ka_c323Zk3sESr1YxMmcInA",
    "requestUrl": "https://api.verifya2z.com/api/v1/verification/credit_report_checker",
    "rawResponse": "{\"statuscode\":200,\"status\":true,\"message\":\"Credit Report fetched successfully\",\"reference_id\":196843658,\"data\":{\"cCRResponse\":{\"status\":\"1\",\"cIRReportDataLst\":[{\"cIRReportData\":{\"iDAndContactInfo\":{\"personalInfo\":{\"name\":{\"fullName\":\"BALIJEPALLI NARENDRA \",\"firstName\":\"BALIJEPALLI \",\"middleName\":\"NARENDRA \"},\"dateOfBirth\":\"1994-08-08\",\"gender\":\"Male\",\"age\":{\"age\":\"32\"},\"totalIncome\":\"\"},\"identityInfo\":{\"pANId\":[{\"seq\":\"1\",\"reportedDate\":\"2026-09-23\",\"idNumber\":\"CDBPB2737H\"}],\"otherId\":[{\"seq\":\"1\",\"reportedDate\":\"2026-06-30\",\"idNumber\":\"60011901969107\"}]},\"addressInfo\":[{\"seq\":\"1\",\"reportedDate\":\"2026-09-23\",\"address\":\"4-15-124-2 BHARATH PET 8THLANE AMARAVATHI ROAD  GUNTUR GUNTUR\",\"state\":\"AP\",\"postal\":\"522002\",\"type\":\"Permanent\"},{\"seq\":\"2\",\"reportedDate\":\"2026-09-23\",\"address\":\"SRS FINTECH LABS PVT LTD  CCO2 BLOCK  C HINDU FORTUNE FIELDS 9TH PHASE ANNEXE HYDERABAD\",\"state\":\"AP\",\"postal\":\"500085\",\"type\":\"Office\"},{\"seq\":\"3\",\"reportedDate\":\"2026-09-23\",\"address\":\"PLOT NO 287 MIG\/2 KAHI PHOSE 9 KUKADPALLY  NEAR FORUM MALL HYDERABAD\",\"state\":\"TS\",\"postal\":\"500072\",\"type\":\"Office\"},{\"seq\":\"4\",\"reportedDate\":\"2026-09-23\",\"address\":\"SAI MSDHAV BOYS HOSTEL 155A ADDAGUTTA  NEAR JNTU HYDERABAD\",\"state\":\"TS\",\"postal\":\"500090\",\"type\":\"Primary\"},{\"seq\":\"5\",\"reportedDate\":\"2021-03-31\",\"address\":\"4-15-124-2 BHARATH PET 8THLANE AMARAVATHI ROAD  GUNTUR GUNTUR\",\"state\":\"AP\",\"postal\":\"522002\",\"type\":\"Permanent\"}],\"phoneInfo\":[{\"seq\":\"1\",\"typeCode\":\"H\",\"reportedDate\":\"2020-02-29\",\"number\":\"00522002\"},{\"seq\":\"2\",\"typeCode\":\"M\",\"reportedDate\":\"2026-09-23\",\"number\":\"09492902990\"},{\"seq\":\"3\",\"typeCode\":\"M\",\"reportedDate\":\"2023-02-01\",\"number\":\"9966888825\"},{\"seq\":\"4\",\"typeCode\":\"T\",\"reportedDate\":\"2026-06-30\",\"number\":\"9492902990\"},{\"seq\":\"5\",\"typeCode\":\"T\",\"reportedDate\":\"2023-04-01\",\"number\":\"00522002\"}],\"emailAddressInfo\":[{\"seq\":\"1\",\"reportedDate\":\"2023-02-01\",\"emailAddress\":\"NARENDRA@OXYLOANS.COM\"}]},\"retailAccountDetails\":[{\"seq\":\"1\",\"accountNumber\":\"0252965746111987943\",\"institution\":\"SBI CARDS AND PAYMENT SERVICES LIMITED\",\"accountType\":\"Credit Card\",\"ownershipType\":\"Individual\",\"balance\":\"125586\",\"pastDueAmount\":\"0\",\"open\":\"Yes\",\"highCredit\":\"150467\",\"lastPaymentDate\":\"2026-09-23\",\"dateReported\":\"2026-09-23\",\"dateOpened\":\"2022-03-10\",\"termFrequency\":\"Monthly\",\"creditLimit\":\"156000\",\"accountStatus\":\"Current Account\",\"source\":\"INDIVIDUAL\",\"history48Months\":[{\"key\":\"09-26\",\"paymentStatus\":\"000\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"08-26\",\"paymentStatus\":\"000\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"07-26\",\"paymentStatus\":\"000\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"06-26\",\"paymentStatus\":\"000\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"05-26\",\"paymentStatus\":\"000\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"04-26\",\"paymentStatus\":\"000\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"03-26\",\"paymentStatus\":\"000\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"02-26\",\"paymentStatus\":\"000\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"01-26\",\"paymentStatus\":\"000\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"12-25\",\"paymentStatus\":\"000\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"11-25\",\"paymentStatus\":\"000\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"10-25\",\"paymentStatus\":\"000\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"09-25\",\"paymentStatus\":\"000\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"08-25\",\"paymentStatus\":\"000\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"}],\"lastPayment\":\"\",\"writeOffAmount\":\"\",\"assetClassification\":\"\",\"dateClosed\":\"\",\"reason\":\"\",\"interestRate\":\"\",\"repaymentTenure\":\"\",\"installmentAmount\":\"\",\"collateralValue\":\"\",\"collateralType\":\"\"},{\"seq\":\"2\",\"accountNumber\":\"9406455010135272\",\"institution\":\"Kotak Mahindra Bank Ltd\",\"accountType\":\"Credit Card\",\"ownershipType\":\"Individual\",\"balance\":\"89883\",\"pastDueAmount\":\"0\",\"lastPayment\":\"107516\",\"open\":\"No\",\"highCredit\":\"161856\",\"lastPaymentDate\":\"2026-09-03\",\"dateReported\":\"2026-09-23\",\"dateOpened\":\"2019-12-10\",\"dateClosed\":\"2021-03-31\",\"termFrequency\":\"Monthly\",\"creditLimit\":\"162000\",\"accountStatus\":\"Current Account\",\"source\":\"INDIVIDUAL\",\"history48Months\":[{\"key\":\"09-26\",\"paymentStatus\":\"000\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"08-26\",\"paymentStatus\":\"000\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"07-26\",\"paymentStatus\":\"000\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"06-26\",\"paymentStatus\":\"000\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"05-26\",\"paymentStatus\":\"000\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"04-26\",\"paymentStatus\":\"000\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"03-26\",\"paymentStatus\":\"000\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"02-26\",\"paymentStatus\":\"000\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"01-26\",\"paymentStatus\":\"000\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"12-25\",\"paymentStatus\":\"*\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"11-25\",\"paymentStatus\":\"*\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"10-25\",\"paymentStatus\":\"*\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"09-25\",\"paymentStatus\":\"*\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"08-25\",\"paymentStatus\":\"*\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"07-25\",\"paymentStatus\":\"*\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"06-25\",\"paymentStatus\":\"*\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"05-25\",\"paymentStatus\":\"*\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"04-25\",\"paymentStatus\":\"*\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"03-25\",\"paymentStatus\":\"*\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"02-25\",\"paymentStatus\":\"*\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"01-25\",\"paymentStatus\":\"*\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"12-24\",\"paymentStatus\":\"*\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"11-24\",\"paymentStatus\":\"*\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"10-24\",\"paymentStatus\":\"*\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"09-24\",\"paymentStatus\":\"*\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"08-24\",\"paymentStatus\":\"*\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"07-24\",\"paymentStatus\":\"*\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"06-24\",\"paymentStatus\":\"*\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"05-24\",\"paymentStatus\":\"*\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"04-24\",\"paymentStatus\":\"*\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"03-24\",\"paymentStatus\":\"*\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"02-24\",\"paymentStatus\":\"*\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"01-24\",\"paymentStatus\":\"*\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"12-23\",\"paymentStatus\":\"*\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"11-23\",\"paymentStatus\":\"*\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"10-23\",\"paymentStatus\":\"*\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"09-23\",\"paymentStatus\":\"*\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"08-23\",\"paymentStatus\":\"*\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"07-23\",\"paymentStatus\":\"*\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"06-23\",\"paymentStatus\":\"*\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"05-23\",\"paymentStatus\":\"*\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"04-23\",\"paymentStatus\":\"*\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"03-23\",\"paymentStatus\":\"*\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"02-23\",\"paymentStatus\":\"*\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"01-23\",\"paymentStatus\":\"*\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"12-22\",\"paymentStatus\":\"*\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"11-22\",\"paymentStatus\":\"*\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"10-22\",\"paymentStatus\":\"*\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"}],\"writeOffAmount\":\"\",\"assetClassification\":\"\",\"reason\":\"\",\"interestRate\":\"\",\"repaymentTenure\":\"\",\"installmentAmount\":\"\",\"collateralValue\":\"\",\"collateralType\":\"\"},{\"seq\":\"3\",\"accountNumber\":\"7280514346111996607\",\"institution\":\"SBI CARDS AND PAYMENT SERVICES LIMITED\",\"accountType\":\"Credit Card\",\"ownershipType\":\"Individual\",\"balance\":\"0\",\"pastDueAmount\":\"0\",\"open\":\"No\",\"highCredit\":\"75339\",\"lastPaymentDate\":\"2025-06-18\",\"dateReported\":\"2025-08-30\",\"dateOpened\":\"2022-03-10\",\"dateClosed\":\"2025-07-09\",\"reason\":\"Closed Account\",\"termFrequency\":\"Monthly\",\"creditLimit\":\"0\",\"accountStatus\":\"Closed Account\",\"source\":\"INDIVIDUAL\",\"history48Months\":[{\"key\":\"08-25\",\"paymentStatus\":\"CLSD\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"07-25\",\"paymentStatus\":\"CLSD\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"06-25\",\"paymentStatus\":\"000\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"05-25\",\"paymentStatus\":\"000\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"04-25\",\"paymentStatus\":\"000\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"03-25\",\"paymentStatus\":\"000\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"02-25\",\"paymentStatus\":\"000\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"01-25\",\"paymentStatus\":\"000\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"12-24\",\"paymentStatus\":\"000\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"11-24\",\"paymentStatus\":\"000\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"10-24\",\"paymentStatus\":\"000\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"09-24\",\"paymentStatus\":\"000\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"08-24\",\"paymentStatus\":\"000\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"07-24\",\"paymentStatus\":\"000\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"06-24\",\"paymentStatus\":\"000\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"05-24\",\"paymentStatus\":\"000\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"04-24\",\"paymentStatus\":\"000\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"03-24\",\"paymentStatus\":\"000\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"02-24\",\"paymentStatus\":\"*\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"01-24\",\"paymentStatus\":\"000\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"12-23\",\"paymentStatus\":\"000\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"11-23\",\"paymentStatus\":\"000\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"10-23\",\"paymentStatus\":\"000\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"09-23\",\"paymentStatus\":\"000\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"08-23\",\"paymentStatus\":\"000\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"07-23\",\"paymentStatus\":\"000\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"06-23\",\"paymentStatus\":\"000\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"05-23\",\"paymentStatus\":\"000\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"04-23\",\"paymentStatus\":\"000\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"03-23\",\"paymentStatus\":\"000\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"02-23\",\"paymentStatus\":\"*\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"01-23\",\"paymentStatus\":\"000\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"12-22\",\"paymentStatus\":\"000\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"11-22\",\"paymentStatus\":\"000\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"10-22\",\"paymentStatus\":\"000\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"09-22\",\"paymentStatus\":\"000\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"08-22\",\"paymentStatus\":\"000\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"07-22\",\"paymentStatus\":\"000\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"06-22\",\"paymentStatus\":\"000\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"05-22\",\"paymentStatus\":\"000\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"04-22\",\"paymentStatus\":\"000\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"}],\"lastPayment\":\"\",\"writeOffAmount\":\"\",\"assetClassification\":\"\",\"interestRate\":\"\",\"repaymentTenure\":\"\",\"installmentAmount\":\"\",\"collateralValue\":\"\",\"collateralType\":\"\"},{\"seq\":\"4\",\"accountNumber\":\"9406151000648776\",\"institution\":\"Kotak Mahindra Bank Ltd\",\"accountType\":\"Credit Card\",\"ownershipType\":\"Individual\",\"balance\":\"0\",\"pastDueAmount\":\"0\",\"open\":\"No\",\"highCredit\":\"8284\",\"lastPaymentDate\":\"2021-01-04\",\"dateReported\":\"2025-04-22\",\"dateOpened\":\"2019-12-10\",\"dateClosed\":\"2021-10-21\",\"termFrequency\":\"Monthly\",\"accountStatus\":\"Closed Account\",\"source\":\"INDIVIDUAL\",\"history48Months\":[{\"key\":\"04-25\",\"paymentStatus\":\"CLSD\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"03-25\",\"paymentStatus\":\"*\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"02-25\",\"paymentStatus\":\"*\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"01-25\",\"paymentStatus\":\"*\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"12-24\",\"paymentStatus\":\"*\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"11-24\",\"paymentStatus\":\"*\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"10-24\",\"paymentStatus\":\"*\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"09-24\",\"paymentStatus\":\"*\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"08-24\",\"paymentStatus\":\"*\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"07-24\",\"paymentStatus\":\"*\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"06-24\",\"paymentStatus\":\"*\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"05-24\",\"paymentStatus\":\"*\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"04-24\",\"paymentStatus\":\"*\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"03-24\",\"paymentStatus\":\"*\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"02-24\",\"paymentStatus\":\"*\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"01-24\",\"paymentStatus\":\"*\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"12-23\",\"paymentStatus\":\"*\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"11-23\",\"paymentStatus\":\"*\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"10-23\",\"paymentStatus\":\"*\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"09-23\",\"paymentStatus\":\"*\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"08-23\",\"paymentStatus\":\"*\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"07-23\",\"paymentStatus\":\"*\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"06-23\",\"paymentStatus\":\"*\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"05-23\",\"paymentStatus\":\"*\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"04-23\",\"paymentStatus\":\"*\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"03-23\",\"paymentStatus\":\"*\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"02-23\",\"paymentStatus\":\"*\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"01-23\",\"paymentStatus\":\"*\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"12-22\",\"paymentStatus\":\"*\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"11-22\",\"paymentStatus\":\"*\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"10-22\",\"paymentStatus\":\"*\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"09-22\",\"paymentStatus\":\"*\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"08-22\",\"paymentStatus\":\"*\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"07-22\",\"paymentStatus\":\"*\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"06-22\",\"paymentStatus\":\"*\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"05-22\",\"paymentStatus\":\"*\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"04-22\",\"paymentStatus\":\"*\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"03-22\",\"paymentStatus\":\"*\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"02-22\",\"paymentStatus\":\"*\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"01-22\",\"paymentStatus\":\"*\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"12-21\",\"paymentStatus\":\"*\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"11-21\",\"paymentStatus\":\"*\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"10-21\",\"paymentStatus\":\"CLSD\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"09-21\",\"paymentStatus\":\"*\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"08-21\",\"paymentStatus\":\"*\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"07-21\",\"paymentStatus\":\"*\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"06-21\",\"paymentStatus\":\"*\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"05-21\",\"paymentStatus\":\"*\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"}],\"lastPayment\":\"\",\"writeOffAmount\":\"\",\"creditLimit\":\"\",\"assetClassification\":\"\",\"reason\":\"\",\"interestRate\":\"\",\"repaymentTenure\":\"\",\"installmentAmount\":\"\",\"collateralValue\":\"\",\"collateralType\":\"\"},{\"seq\":\"5\",\"accountNumber\":\"9406150005334457\",\"institution\":\"Kotak Mahindra Bank Ltd\",\"accountType\":\"Credit Card\",\"ownershipType\":\"Individual\",\"balance\":\"0\",\"pastDueAmount\":\"0\",\"open\":\"No\",\"highCredit\":\"2662\",\"lastPaymentDate\":\"2020-10-04\",\"dateReported\":\"2025-04-22\",\"dateOpened\":\"2019-12-10\",\"dateClosed\":\"2021-10-21\",\"termFrequency\":\"Monthly\",\"accountStatus\":\"Closed Account\",\"source\":\"INDIVIDUAL\",\"history48Months\":[{\"key\":\"04-25\",\"paymentStatus\":\"CLSD\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"03-25\",\"paymentStatus\":\"*\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"02-25\",\"paymentStatus\":\"*\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"01-25\",\"paymentStatus\":\"*\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"12-24\",\"paymentStatus\":\"*\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"11-24\",\"paymentStatus\":\"*\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"10-24\",\"paymentStatus\":\"*\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"09-24\",\"paymentStatus\":\"*\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"08-24\",\"paymentStatus\":\"*\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"07-24\",\"paymentStatus\":\"*\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"06-24\",\"paymentStatus\":\"*\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"05-24\",\"paymentStatus\":\"*\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"04-24\",\"paymentStatus\":\"*\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"03-24\",\"paymentStatus\":\"*\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"02-24\",\"paymentStatus\":\"*\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"01-24\",\"paymentStatus\":\"*\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"12-23\",\"paymentStatus\":\"*\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"11-23\",\"paymentStatus\":\"*\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"10-23\",\"paymentStatus\":\"*\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"09-23\",\"paymentStatus\":\"*\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"08-23\",\"paymentStatus\":\"*\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"07-23\",\"paymentStatus\":\"*\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"06-23\",\"paymentStatus\":\"*\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"05-23\",\"paymentStatus\":\"*\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"04-23\",\"paymentStatus\":\"*\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"03-23\",\"paymentStatus\":\"*\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"02-23\",\"paymentStatus\":\"*\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"01-23\",\"paymentStatus\":\"*\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"12-22\",\"paymentStatus\":\"*\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"11-22\",\"paymentStatus\":\"*\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"10-22\",\"paymentStatus\":\"*\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"09-22\",\"paymentStatus\":\"*\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"08-22\",\"paymentStatus\":\"*\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"07-22\",\"paymentStatus\":\"*\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"06-22\",\"paymentStatus\":\"*\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"05-22\",\"paymentStatus\":\"*\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"04-22\",\"paymentStatus\":\"*\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"03-22\",\"paymentStatus\":\"*\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"02-22\",\"paymentStatus\":\"*\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"01-22\",\"paymentStatus\":\"*\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"12-21\",\"paymentStatus\":\"*\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"11-21\",\"paymentStatus\":\"*\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"10-21\",\"paymentStatus\":\"CLSD\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"09-21\",\"paymentStatus\":\"*\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"08-21\",\"paymentStatus\":\"*\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"07-21\",\"paymentStatus\":\"*\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"06-21\",\"paymentStatus\":\"*\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"05-21\",\"paymentStatus\":\"*\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"}],\"lastPayment\":\"\",\"writeOffAmount\":\"\",\"creditLimit\":\"\",\"assetClassification\":\"\",\"reason\":\"\",\"interestRate\":\"\",\"repaymentTenure\":\"\",\"installmentAmount\":\"\",\"collateralValue\":\"\",\"collateralType\":\"\"},{\"seq\":\"6\",\"accountNumber\":\"0001014550015442292\",\"institution\":\"HDFC Bank Limited\",\"accountType\":\"Credit Card\",\"ownershipType\":\"Individual\",\"balance\":\"0\",\"open\":\"No\",\"highCredit\":\"55550\",\"lastPaymentDate\":\"2022-01-29\",\"dateReported\":\"2023-07-01\",\"dateOpened\":\"2018-12-14\",\"dateClosed\":\"2023-03-01\",\"reason\":\"Closed Account\",\"creditLimit\":\"150000\",\"accountStatus\":\"Closed Account\",\"source\":\"INDIVIDUAL\",\"history48Months\":[{\"key\":\"07-23\",\"paymentStatus\":\"CLSD\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"06-23\",\"paymentStatus\":\"CLSD\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"05-23\",\"paymentStatus\":\"CLSD\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"04-23\",\"paymentStatus\":\"CLSD\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"03-23\",\"paymentStatus\":\"000\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"02-23\",\"paymentStatus\":\"000\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"01-23\",\"paymentStatus\":\"000\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"12-22\",\"paymentStatus\":\"*\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"11-22\",\"paymentStatus\":\"000\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"10-22\",\"paymentStatus\":\"000\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"09-22\",\"paymentStatus\":\"000\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"08-22\",\"paymentStatus\":\"000\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"07-22\",\"paymentStatus\":\"000\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"06-22\",\"paymentStatus\":\"000\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"05-22\",\"paymentStatus\":\"000\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"04-22\",\"paymentStatus\":\"000\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"03-22\",\"paymentStatus\":\"000\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"02-22\",\"paymentStatus\":\"000\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"01-22\",\"paymentStatus\":\"000\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"12-21\",\"paymentStatus\":\"000\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"11-21\",\"paymentStatus\":\"000\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"10-21\",\"paymentStatus\":\"000\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"09-21\",\"paymentStatus\":\"000\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"08-21\",\"paymentStatus\":\"000\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"07-21\",\"paymentStatus\":\"000\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"06-21\",\"paymentStatus\":\"000\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"05-21\",\"paymentStatus\":\"000\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"04-21\",\"paymentStatus\":\"000\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"03-21\",\"paymentStatus\":\"000\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"02-21\",\"paymentStatus\":\"000\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"01-21\",\"paymentStatus\":\"000\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"12-20\",\"paymentStatus\":\"000\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"11-20\",\"paymentStatus\":\"000\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"10-20\",\"paymentStatus\":\"000\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"09-20\",\"paymentStatus\":\"000\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"08-20\",\"paymentStatus\":\"000\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"07-20\",\"paymentStatus\":\"000\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"06-20\",\"paymentStatus\":\"000\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"05-20\",\"paymentStatus\":\"000\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"04-20\",\"paymentStatus\":\"000\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"03-20\",\"paymentStatus\":\"000\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"02-20\",\"paymentStatus\":\"000\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"01-20\",\"paymentStatus\":\"000\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"12-19\",\"paymentStatus\":\"000\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"11-19\",\"paymentStatus\":\"000\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"10-19\",\"paymentStatus\":\"000\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"09-19\",\"paymentStatus\":\"000\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"},{\"key\":\"08-19\",\"paymentStatus\":\"000\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"*\"}],\"pastDueAmount\":\"\",\"lastPayment\":\"\",\"writeOffAmount\":\"\",\"termFrequency\":\"\",\"assetClassification\":\"\",\"interestRate\":\"\",\"repaymentTenure\":\"\",\"installmentAmount\":\"\",\"collateralValue\":\"\",\"collateralType\":\"\"},{\"seq\":\"7\",\"accountNumber\":\"6439810\",\"institution\":\"HDFC Bank Limited\",\"accountType\":\"Personal Loan\",\"ownershipType\":\"Individual\",\"balance\":\"0\",\"pastDueAmount\":\"0\",\"lastPayment\":\"3523\",\"open\":\"No\",\"sanctionAmount\":\"100000\",\"lastPaymentDate\":\"2022-05-07\",\"dateReported\":\"2022-05-31\",\"dateOpened\":\"2019-05-16\",\"dateClosed\":\"2022-05-07\",\"reason\":\"Closed Account\",\"termFrequency\":\"Monthly\",\"accountStatus\":\"Closed Account\",\"assetClassification\":\"Standard\",\"source\":\"INDIVIDUAL\",\"history48Months\":[{\"key\":\"05-22\",\"paymentStatus\":\"CLSD\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"STD\"},{\"key\":\"04-22\",\"paymentStatus\":\"000\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"STD\"},{\"key\":\"03-22\",\"paymentStatus\":\"000\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"STD\"},{\"key\":\"02-22\",\"paymentStatus\":\"000\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"STD\"},{\"key\":\"01-22\",\"paymentStatus\":\"000\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"STD\"},{\"key\":\"12-21\",\"paymentStatus\":\"000\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"STD\"},{\"key\":\"11-21\",\"paymentStatus\":\"000\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"STD\"},{\"key\":\"10-21\",\"paymentStatus\":\"000\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"STD\"},{\"key\":\"09-21\",\"paymentStatus\":\"000\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"STD\"},{\"key\":\"08-21\",\"paymentStatus\":\"000\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"STD\"},{\"key\":\"07-21\",\"paymentStatus\":\"000\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"STD\"},{\"key\":\"06-21\",\"paymentStatus\":\"000\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"STD\"},{\"key\":\"05-21\",\"paymentStatus\":\"000\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"STD\"},{\"key\":\"04-21\",\"paymentStatus\":\"000\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"STD\"},{\"key\":\"03-21\",\"paymentStatus\":\"000\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"STD\"},{\"key\":\"02-21\",\"paymentStatus\":\"000\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"STD\"},{\"key\":\"01-21\",\"paymentStatus\":\"000\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"STD\"},{\"key\":\"12-20\",\"paymentStatus\":\"000\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"STD\"},{\"key\":\"11-20\",\"paymentStatus\":\"000\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"STD\"},{\"key\":\"10-20\",\"paymentStatus\":\"000\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"STD\"},{\"key\":\"09-20\",\"paymentStatus\":\"000\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"STD\"},{\"key\":\"08-20\",\"paymentStatus\":\"000\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"STD\"},{\"key\":\"07-20\",\"paymentStatus\":\"000\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"STD\"},{\"key\":\"06-20\",\"paymentStatus\":\"000\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"STD\"},{\"key\":\"05-20\",\"paymentStatus\":\"000\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"STD\"},{\"key\":\"04-20\",\"paymentStatus\":\"000\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"STD\"},{\"key\":\"03-20\",\"paymentStatus\":\"000\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"STD\"},{\"key\":\"02-20\",\"paymentStatus\":\"000\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"STD\"},{\"key\":\"01-20\",\"paymentStatus\":\"000\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"STD\"},{\"key\":\"12-19\",\"paymentStatus\":\"000\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"STD\"},{\"key\":\"11-19\",\"paymentStatus\":\"000\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"STD\"},{\"key\":\"10-19\",\"paymentStatus\":\"000\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"STD\"},{\"key\":\"09-19\",\"paymentStatus\":\"000\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"STD\"},{\"key\":\"08-19\",\"paymentStatus\":\"000\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"STD\"},{\"key\":\"07-19\",\"paymentStatus\":\"000\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"STD\"},{\"key\":\"06-19\",\"paymentStatus\":\"000\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"STD\"},{\"key\":\"05-19\",\"paymentStatus\":\"NEW\",\"suitFiledStatus\":\"*\",\"assetClassificationStatus\":\"STD\"}],\"writeOffAmount\":\"\",\"highCredit\":\"\",\"creditLimit\":\"\",\"interestRate\":\"\",\"repaymentTenure\":\"\",\"installmentAmount\":\"\",\"collateralValue\":\"\",\"collateralType\":\"\"}],\"retailAccountsSummary\":{\"noOfAccounts\":\"7\",\"noOfActiveAccounts\":\"1\",\"noOfWriteOffs\":\"0\",\"totalPastDue\":\"0.00\",\"mostSevereStatusWithIn24Months\":\"Non-Delnqt\",\"singleHighestCredit\":\"150467.00\",\"singleHighestSanctionAmount\":\"0.00\",\"totalHighCredit\":\"150467.00\",\"averageOpenBalance\":\"125586.00\",\"singleHighestBalance\":\"125586.00\",\"noOfPastDueAccounts\":\"0\",\"noOfZeroBalanceAccounts\":\"0\",\"recentAccount\":\"Credit Card on 10-03-2022\",\"oldestAccount\":\"Credit Card on 14-12-2018\",\"totalBalanceAmount\":\"125586.00\",\"totalSanctionAmount\":\"0.00\",\"totalCreditLimit\":\"156000.0\",\"totalMonthlyPaymentAmount\":\"0.00\"},\"scoreDetails\":[{\"type\":\"ERS\",\"version\":\"4.0\",\"name\":\"ERS4.0\",\"value\":\"802\",\"scoringElements\":[{\"type\":\"RES\",\"seq\":\"1\",\"code\":\"703\",\"description\":\"Total Utilization\"},{\"type\":\"RES\",\"seq\":\"2\",\"code\":\"704\",\"description\":\"Credit Card Utilization\"},{\"type\":\"RES\",\"seq\":\"3\",\"code\":\"702\",\"description\":\"Total Credit Exposure\"}]}],\"enquirySummary\":{\"purpose\":\"ALL\",\"total\":\"0\",\"past30Days\":\"0\",\"past12Months\":\"0\",\"past24Months\":\"0\"},\"otherKeyInd\":{\"ageOfOldestTrade\":\"94\",\"numberOfOpenTrades\":\"1\",\"allLinesEVERWritten\":\"0.00\",\"allLinesEVERWrittenIn9Months\":\"0\",\"allLinesEVERWrittenIn6Months\":\"0\"},\"recentActivities\":{\"accountsDeliquent\":\"0\",\"accountsOpened\":\"0\",\"totalInquiries\":\"0\",\"accountsUpdated\":\"2\"}}}]},\"reportOrderNumber\":\"2989093135\"}}",
    "message": "Credit Report fetched successfully"
}
  )
  try {
    const response = await handleApiRequestAfterLoginService(
      API_BASE_URL,
      "paysprint/credit-report-checker12",
      "POST",
      token,
      payload
    );
    if (response) return response;
  } catch (error) {
    console.warn("handleApiRequestAfterLoginService credit report error:", error);
  }

  return await axios.post(
    `${API_BASE_URL}paysprint/credit-report-checker12`,
    payload,
    {
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
        accessToken: token,
      },
    }
  );
};




