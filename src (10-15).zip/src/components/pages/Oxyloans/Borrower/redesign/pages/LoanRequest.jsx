import React, { useEffect, useRef, useState, useMemo } from "react";
import { Link, useNavigate } from "react-router-dom";
import Swal from "sweetalert2";

import BorrowerHeader from "../../../../../Header/BorrowerHeader";
import BorrowerSidebar from "../../../../../SideBar/BorrowerSidebar";
import Footer from "../../../../../Footer/Footer";

import {
  getBorrowerEligibleAmount,
  getUserId,
  submitBorrowerLoanRequest,
  getBorrowerRequestAmount,
  getUserDetails,
  getCibilBasedRoi,
  getBorrowerCreditReport,
  getBorrowerReferenceDetails,
  loadlendernomineeDetails,
} from "../../../../../HttpRequest/afterlogin";
import BorrowerConsentSection, { BORROWER_CONSENTS } from "../../BorrowerConsentSection";
import FeeConfigInfo from "../../FeeConfigInfo";
import { calculateBorrowerProfileCompleteness } from "../../../../../../utils/borrowerValidation";
import "../redesign.css";

const LoanRequest = () => {
  const navigate = useNavigate();
  const [requestAmount, setRequestAmount] = useState("");
  const [consentItems, setConsentItems] = useState(new Array(BORROWER_CONSENTS.length).fill(false));
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [oxyscore, setOxyScore] = useState();
  const [selectedTenure, setSelectedTenure] = useState(3);
  
  const [eligibleAmount, setEligibleAmount] = useState({
    amount: null,
    processingFee: 0,
    verifiedMonthlyIncome: 0,
  });
  const [isEligibleLoading, setIsEligibleLoading] = useState(true);
  const [eligibleErrorMessage, setEligibleErrorMessage] = useState("");

  const [requestStatusInfo, setRequestStatusInfo] = useState({
    loading: true,
    status: "",
    pendingAmount: 0,
    requestAmount: 0,
    message: "",
  });

  const [cibilInfo, setCibilInfo] = useState({ loading: true, data: null });

  const [borrowerCreditReport, setBorrowerCreditReport] = useState({ loading: true, data: null });

  const [profileCompleteness, setProfileCompleteness] = useState({
    percentage: 100,
    isEligibleToRaiseLoan: true,
    missingRequirements: [],
    loading: true,
  });

  const borrowerId = getUserId() || "";

  useEffect(() => {
    document.body.classList.add("oxy-redesign-active");
    return () => {
      document.body.classList.remove("oxy-redesign-active");
    };
  }, []);

  useEffect(() => {
    const fetchCibilRoi = async () => {
      if (!borrowerId) { setCibilInfo({ loading: false, data: null }); return; }
      try {
        const res = await getCibilBasedRoi();
        setCibilInfo({ loading: false, data: res?.status === 200 ? res.data : null });
      } catch {
        setCibilInfo({ loading: false, data: null });
      }
    };
    const fetchBorrowerCreditReport = async (borrowerId) => {
      if (!borrowerId) { setBorrowerCreditReport({ loading: false, data: null }); return; }
      try {
        const res = await getBorrowerCreditReport(borrowerId);
        setBorrowerCreditReport({ loading: false, data: res?.status === 200 ? res.data : null });
        console.log("Borrower Credit Report:", res?.data.creditReportAvailable);
      } catch {
        setBorrowerCreditReport({ loading: false, data: null });
      }
    };
    const evaluateProfileCompleteness = async () => {
      try {
        const uId = borrowerId || sessionStorage.getItem("userId");
        const [userRes, refRes, nomineeRes] = await Promise.allSettled([
          getUserDetails(),
          uId ? getBorrowerReferenceDetails(uId) : Promise.resolve(null),
          loadlendernomineeDetails(),
        ]);

        const userData = userRes.status === "fulfilled" ? userRes.value?.data : null;
        const refData = refRes.status === "fulfilled" ? refRes.value?.data : null;
        const nomineeData = nomineeRes.status === "fulfilled" ? nomineeRes.value?.data : null;

        if (userData) {
          const comp = calculateBorrowerProfileCompleteness(
            userData,
            refData || userData.referenceDetailsResponseDto,
            nomineeData
          );
          setProfileCompleteness({
            percentage: comp.percentage,
            isEligibleToRaiseLoan: comp.isEligibleToRaiseLoan,
            missingRequirements: comp.missingRequirements,
            loading: false,
          });
        } else {
          setProfileCompleteness((prev) => ({ ...prev, loading: false }));
        }
      } catch (err) {
        console.error("Error evaluating profile completeness:", err);
        setProfileCompleteness((prev) => ({ ...prev, loading: false }));
      }
    };

    fetchBorrowerCreditReport(borrowerId);
    fetchCibilRoi();
    evaluateProfileCompleteness();
    getUserDetails().then(res=>{
      if (res?.data) {
        setOxyScore(res.data.profileScore || res.data.cibilScore);
      }
    });
  }, [borrowerId]);

  useEffect(() => {
    const fetchEligibleAmount = async () => {
      if (!borrowerId) {
        setEligibleErrorMessage("Your session has expired. Please sign in again.");
        setIsEligibleLoading(false);
        return;
      }

      setIsEligibleLoading(true);
      setEligibleErrorMessage("");
      try {
        const response = await getBorrowerEligibleAmount();
        const status = response?.status ?? response?.request?.status;
        if (status === 200) {
          const limitAmount = Number(response?.data?.amount ?? 0);
          const processingFee = Number(response?.data?.processingfee ?? 0);
          const verifiedMonthlyIncome = Number(response?.data?.verifiedMonthlyIncome ?? 0);
          setEligibleAmount({
            amount: isNaN(limitAmount) ? 0 : limitAmount,
            processingFee: isNaN(processingFee) ? 0 : processingFee,
            verifiedMonthlyIncome: isNaN(verifiedMonthlyIncome) ? 0 : verifiedMonthlyIncome,
          });
        } else {
          const apiErrorMsg =
            response?.data?.errorMessage ||
            response?.response?.data?.errorMessage ||
            response?.data?.message ||
            "Unable to fetch your eligible amount. Please try again.";
          setEligibleErrorMessage(apiErrorMsg);
        }
      } catch (error) {
        const apiErrorMsg =
          error?.response?.data?.errorMessage ||
          error?.data?.errorMessage ||
          error?.response?.data?.message ||
          error?.data?.message ||
          error?.message ||
          "Unable to fetch your eligible amount. Please try again.";
        setEligibleErrorMessage(apiErrorMsg);
      }
      borrowerCreditReport.data?.creditReportAvailable === false && setEligibleErrorMessage("Your credit report was not verified by the admin. Please upload a valid credit report.");
      setIsEligibleLoading(false);
    };

    fetchEligibleAmount();
  }, [borrowerId]);

  useEffect(() => {
    const fetchBorrowerRequestStatus = async () => {
      if (!borrowerId) {
        setRequestStatusInfo({
          loading: false,
          status: "",
          pendingAmount: 0,
          message: "Your session has expired. Please sign in again.",
        });
        return;
      }

      try {
        const response = await getBorrowerRequestAmount();
        if (response?.status === 200) {
          const requestList = Array.isArray(response?.data) ? response.data : [];
          const latestRequest = requestList.length
            ? [...requestList].sort((a, b) => Number(b?.id || 0) - Number(a?.id || 0))[0]
            : null;

          const latestStatus = String(latestRequest?.loanRequestStatus || "").trim().toUpperCase();
          const pendingAmount = Number(latestRequest?.partiallyPendingAmount || 0);
          const requestAmt = Number(latestRequest?.requestAmount || 0);
          const hasBlockedStatus = !!latestStatus && latestStatus !== "CLOSED" && latestStatus !== "PARTIALLYPROCESSING";

          setRequestStatusInfo({
            loading: false,
            status: latestStatus,
            pendingAmount: isNaN(pendingAmount) ? 0 : pendingAmount,
            requestAmount: isNaN(requestAmt) ? 0 : requestAmt,
            message: hasBlockedStatus
              ? "Your previous loan request is still active. You can raise a fresh request after the current request is closed."
              : "",
          });
          return;
        }
        setRequestStatusInfo({ loading: false, status: "", pendingAmount: 0, requestAmount: 0, message: "" });
      } catch {
        setRequestStatusInfo({ loading: false, status: "", pendingAmount: 0, requestAmount: 0, message: "" });
      }
    };

    fetchBorrowerRequestStatus();
  }, [borrowerId]);

  const formatCurrency = (amount) => {
    const numericValue = Number(amount || 0);
    return `₹ ${numericValue.toLocaleString("en-IN", {
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    })}`;
  };

  const eligibleAmountValue = eligibleAmount.amount;
  const verifiedMonthlyIncome = Number(eligibleAmount.verifiedMonthlyIncome || 0);
  const processingFeePercentage = Number(eligibleAmount.processingFee || 0);
  const eligibleCalculationAmount = (verifiedMonthlyIncome * processingFeePercentage) / 100;
  const isFormBlockedByStatus = !!requestStatusInfo.status && requestStatusInfo.status !== "CLOSED" && requestStatusInfo.status !== "PARTIALLYPROCESSING";
  
  const maxLimit = requestStatusInfo.status === "PARTIALLYPROCESSING"
    ? Math.max(0, (eligibleAmountValue || 0) - (requestStatusInfo.requestAmount || 0))
    : eligibleAmountValue;

  const applicableRoi = cibilInfo.data?.roi ? Number(cibilInfo.data.roi) : 24;
  const parsedAmount = Number(requestAmount || 0);

  const estimatedEmiInfo = useMemo(() => {
    if (!parsedAmount || parsedAmount <= 0) return { emi: 0, totalInterest: 0, totalPayable: 0 };
    const monthlyRate = applicableRoi / 12 / 100;
    const n = selectedTenure;
    if (monthlyRate === 0) {
      return { emi: Math.round(parsedAmount / n), totalInterest: 0, totalPayable: parsedAmount };
    }
    const emi = Math.round((parsedAmount * monthlyRate * Math.pow(1 + monthlyRate, n)) / (Math.pow(1 + monthlyRate, n) - 1));
    const totalPayable = emi * n;
    const totalInterest = Math.max(0, totalPayable - parsedAmount);
    return { emi, totalInterest, totalPayable };
  }, [parsedAmount, selectedTenure, applicableRoi]);

  const handlePresetClick = (pct) => {
    if (!maxLimit) return;
    const val = Math.round((maxLimit * pct) / 100);
    setRequestAmount(String(val));
  };

  const allConsentsChecked = consentItems.every(Boolean);

  const isSubmitDisabled =
    isSubmitting ||
    isEligibleLoading ||
    requestStatusInfo.loading ||
    !!eligibleErrorMessage ||
    isFormBlockedByStatus ||
    !allConsentsChecked ||
    (!profileCompleteness.loading && !profileCompleteness.isEligibleToRaiseLoan);

  const handleSubmit = async (event) => {
    event.preventDefault();

    if (!borrowerId) {
      Swal.fire("Session Expired", "Please sign in again to continue.", "warning");
      return;
    }

    if (!profileCompleteness.isEligibleToRaiseLoan) {
      Swal.fire({
        icon: "warning",
        title: "Profile Incomplete (90% Required)",
        html: `Your Profile Completeness is currently <strong>${profileCompleteness.percentage}%</strong>.<br/>You must achieve at least <strong>90% Profile Completeness</strong> before you can raise a loan request.<br/><br/><div style="font-size:13px; text-align:left; background:#f8fafc; padding:12px 16px; border-radius:8px; border:1px solid #e2e8f0;"><strong>Pending items to complete:</strong><br/>• ${profileCompleteness.missingRequirements.join("<br/>• ")}</div>`,
        confirmButtonText: "Complete Profile Now",
        confirmButtonColor: "#0040e0",
        showCancelButton: true,
        cancelButtonText: "Close",
      }).then((result) => {
        if (result.isConfirmed) {
          navigate("/borrowerProfile");
        }
      });
      return;
    }

    if (isFormBlockedByStatus) {
      Swal.fire("Request Not Allowed", "You already have a loan request in progress.", "warning");
      return;
    }

    if (!allConsentsChecked) {
      Swal.fire("Consent Required", "Please read and acknowledge all 8 consent items before proceeding.", "warning");
      return;
    }

    const normalizedAmount = Number(requestAmount);
    if (!normalizedAmount || normalizedAmount <= 0) {
      Swal.fire("Invalid Amount", "Please enter a valid loan amount.", "warning");
      return;
    }

    if (maxLimit !== null && normalizedAmount > maxLimit) {
      Swal.fire("Limit Exceeded", `Your maximum allowed request amount is ${formatCurrency(maxLimit)}.`, "warning");
      return;
    }

    const confirmation = await Swal.fire({
      title: "Confirm Your Loan Request",
      text: `Are you sure you want to request a loan amount of ₹ ${normalizedAmount}? By proceeding, you confirm your consent to share this request with lenders and abide by OxyLoans P2P terms.`,
      icon: "question",
      showCancelButton: true,
      confirmButtonText: "Confirm Request",
      cancelButtonText: "Cancel",
      confirmButtonColor: "#0040e0",
    });

    if (!confirmation.isConfirmed) return;

    setIsSubmitting(true);
    try {
      const payload = {
        borrowerId: Number(borrowerId),
        requestAmount: normalizedAmount,
      };
      const response = await submitBorrowerLoanRequest(payload);
      if (response?.status === 200 || response?.status === 201) {
        await Swal.fire("Congratulations!", "Your loan request has been successfully submitted.", "success");
        setRequestAmount("");
        navigate("/borrowerRequestAmount");
      } else {
        Swal.fire("Submission Failed", "Unable to submit your loan request. Please try again.", "error");
      }
    } catch (error) {
      Swal.fire("Submission Failed", error?.response?.data?.errorMessage || "Unable to submit your loan request. Please try again.", "error");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="main-wrapper">
      <BorrowerHeader />
      <BorrowerSidebar />

      <div className="page-wrapper">
        <div className="content container-fluid py-4" style={{ backgroundColor: "var(--oxy-background)" }}>
          
          <div className="mb-4">
            <h3 className="fw-bold mb-1 text-dark">Apply for a Loan Limit</h3>
            <span className="text-muted small">Submit your request to begin matchmaking with verified lenders.</span>
          </div>

          {/* Quick Metrics Summary */}
          <div className="row g-3 mb-4">
            <div className="col-md-3">
              <div className="oxy-card mb-0 h-100 border-start border-primary border-3" style={{ padding: "16px 20px" }}>
                <div className="d-flex justify-content-between align-items-center mb-1">
                  <span className="text-muted small uppercase text-uppercase">Verified Income</span>
                  <i className="fa-solid fa-wallet text-primary opacity-50"></i>
                </div>
                <h5 className="fw-bold text-dark mb-0">
                  {isEligibleLoading ? "..." : formatCurrency(verifiedMonthlyIncome)}
                </h5>
              </div>
            </div>
            <div className="col-md-3">
              <div className="oxy-card mb-0 h-100 border-start border-success border-3" style={{ padding: "16px 20px" }}>
                <div className="d-flex justify-content-between align-items-center mb-1">
                  <span className="text-muted small uppercase text-uppercase">Max Eligibility Cap</span>
                  <i className="fa-solid fa-shield-halved text-success opacity-50"></i>
                </div>
                <h5 className="fw-bold text-success mb-0">
                  {isEligibleLoading ? "..." : formatCurrency(eligibleAmountValue)}
                </h5>
              </div>
            </div>
            <div className="col-md-3">
              <div className="oxy-card mb-0 h-100 border-start border-info border-3" style={{ padding: "16px 20px" }}>
                <div className="d-flex justify-content-between align-items-center mb-1">
                  <span className="text-muted small uppercase text-uppercase">Oxy Score</span>
                  <i className="fa-solid fa-chart-line text-info opacity-50"></i>
                </div>
                <h5 className="fw-bold text-dark mb-0">
                  {cibilInfo.loading ? "..." : oxyscore != null ? `${oxyscore}` : "—"}
                </h5>
              </div>
            </div> 
            <div className="col-md-3">
              <div className="oxy-card mb-0 h-100 border-start border-warning border-3" style={{ padding: "16px 20px" }}>
                <div className="d-flex justify-content-between align-items-center mb-1">
                  <span className="text-muted small uppercase text-uppercase">ROI (Example Only)</span>
                  <i className="fa-solid fa-percent text-warning opacity-50"></i>
                </div>
                <h5 className="fw-bold text-dark mb-0">
                  {cibilInfo.loading ? "..." : `${applicableRoi}% p.a.`}
                </h5>
              </div>
            </div>
          </div>

          <div className="row justify-content-center">
            <div className="col-lg-9 col-xl-8">
              {/* Profile Completeness Warning Banner (< 90%) */}
              {!profileCompleteness.loading && !profileCompleteness.isEligibleToRaiseLoan && (
                <div className="alert alert-warning border border-warning-subtle rounded-4 p-4 mb-4 shadow-sm bg-warning bg-opacity-10">
                  <div className="d-flex align-items-start gap-3">
                    <div
                      className="rounded-circle d-flex align-items-center justify-content-center flex-shrink-0"
                      style={{ width: "46px", height: "46px", backgroundColor: "#fef3c7", color: "#d97706" }}
                    >
                      <i className="fa-solid fa-triangle-exclamation fs-5"></i>
                    </div>
                    <div className="flex-grow-1">
                      <div className="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-1">
                        <h6 className="fw-bold text-dark mb-0">
                          Profile Completeness: {profileCompleteness.percentage}% (90% Required)
                        </h6>
                        <span className="badge bg-warning text-dark px-3 py-1 rounded-pill fw-bold">
                          {profileCompleteness.percentage}% / 90%
                        </span>
                      </div>
                      <p className="text-muted small mb-2" style={{ lineHeight: "1.5" }}>
                        You cannot raise a loan request until your profile reaches at least <strong>90% Profile Completeness</strong>. Please complete the remaining mandatory profile sections to unlock loan requests.
                      </p>
                      <div className="progress mb-3" style={{ height: "8px", maxWidth: "340px", borderRadius: "10px" }}>
                        <div
                          className="progress-bar bg-warning rounded-pill"
                          role="progressbar"
                          style={{ width: `${profileCompleteness.percentage}%` }}
                        />
                      </div>
                      {profileCompleteness.missingRequirements?.length > 0 && (
                        <div className="small text-secondary mb-3">
                          <strong>Pending Profile Sections: </strong>
                          {profileCompleteness.missingRequirements.join(", ")}
                        </div>
                      )}
                      <button
                        type="button"
                        className="btn btn-warning btn-sm fw-bold px-3 py-2 rounded-pill shadow-sm"
                        onClick={() => navigate("/borrowerProfile")}
                      >
                        <i className="fa-solid fa-user-pen me-1"></i> Complete Profile Now
                      </button>
                    </div>
                  </div>
                </div>
              )}

              {eligibleErrorMessage ? (
                <div className="oxy-card text-center py-5">
                  <div 
                    className="d-flex align-items-center justify-content-center rounded-circle mx-auto mb-4"
                    style={{ width: "64px", height: "64px", backgroundColor: "#fef2f2", color: "#dc2626" }}
                  >
                    <i className="fa-solid fa-triangle-exclamation fa-xl"></i>
                  </div>
                  <h5 className="fw-bold text-dark mb-2">Admin Verification Pending</h5>
                  <p className="text-muted small mb-4 mx-auto" style={{ maxWidth: "480px", lineHeight: "1.6" }}>
                    {eligibleErrorMessage}
                  </p>
                  <button className="oxy-btn-primary btn-danger text-white" onClick={() => navigate("/borrowerProfile")}>
                    Go to Borrower Profile
                  </button>
                </div>
              ) : isFormBlockedByStatus || (maxLimit) === 0 ? (
                <div className="oxy-card text-center py-5">
                  <div 
                    className="d-flex align-items-center justify-content-center rounded-circle mx-auto mb-4 bg-primary bg-opacity-10 text-primary"
                    style={{ width: "64px", height: "64px" }}
                  >
                    <i className="fa-solid fa-clock-rotate-left fa-xl"></i>
                  </div>
                  <h5 className="fw-bold text-dark mb-2">Loan Request in Progress</h5>
                  <p className="text-muted small mb-4 max-w-sm mx-auto" style={{ maxWidth: "340px" }}>
                    You currently have an active loan application. Once this is closed, you can request a fresh limit.
                  </p>
                  <button className="oxy-btn-primary" onClick={() => navigate("/borrowerLoansInitiated")}>
                    View Proposals
                  </button>
                </div>
              ) : (
                <div className="oxy-card p-4">
                  <div className="d-flex justify-content-between align-items-start mb-3">
                    <div>
                      <h5 className="fw-bold mb-1">Request Loan Amount</h5>
                      <span className="text-muted small d-block">
                        Enter the amount you wish to borrow or choose a quick preset below.
                      </span>
                    </div>
                    {maxLimit > 0 && (
                      <span className="badge bg-primary-subtle text-primary px-3 py-2 rounded-pill fw-semibold small">
                        Cap: {formatCurrency(maxLimit)}
                      </span>
                    )}
                  </div>

                  {requestStatusInfo.status === "PARTIALLYPROCESSING" && maxLimit > 0 && (
                    <div className="alert alert-info py-2 px-3 small mb-4">
                      <i className="fa-solid fa-circle-info me-2"></i>
                      Active request of <strong>{formatCurrency(requestStatusInfo.requestAmount)}</strong> in <strong>PARTIALLY_PROCESSING</strong> ({formatCurrency(requestStatusInfo.pendingAmount)} pending match). You can apply for the remaining unused limit: <strong>{formatCurrency(maxLimit)}</strong>.
                    </div>
                  )}

                  {eligibleErrorMessage && (
                    <div className="alert alert-danger py-2 px-3 small mb-4">{eligibleErrorMessage}</div>
                  )}

                  <form onSubmit={handleSubmit}>
                    <div className="mb-4">
                      <label className="form-label text-muted small uppercase text-uppercase fw-semibold">Required Loan Amount (₹)</label>
                      <div className="input-group input-group-lg">
                        <span className="input-group-text bg-light text-muted fw-bold">₹</span>
                        <input 
                          type="number" 
                          className="form-control fw-bold fs-5" 
                          min="500"
                          max={maxLimit || undefined}
                          value={requestAmount} 
                          placeholder="e.g. 50000" 
                          onChange={(e) => setRequestAmount(e.target.value)}
                          required
                        />
                      </div>

                      {/* Quick Select Preset Chips */}
                      {maxLimit > 0 && (
                        <div className="mt-3">
                          <span className="text-muted small me-2 d-block d-sm-inline mb-2 mb-sm-0">Quick Presets:</span>
                          <div className="d-inline-flex flex-wrap gap-2">
                            {[25, 50, 75, 100]
                              .filter((pct) => Math.round((maxLimit * pct) / 100) >= 500)
                              .map((pct) => {
                                const val = Math.round((maxLimit * pct) / 100);
                                const isSelected = Number(requestAmount) === val;
                                return (
                                  <button
                                    key={pct}
                                    type="button"
                                    className={`btn btn-sm ${isSelected ? "btn-primary" : "btn-outline-secondary"}`}
                                    style={{ borderRadius: "20px", fontSize: "12px", padding: "4px 12px" }}
                                    onClick={() => handlePresetClick(pct)}
                                  >
                                    {pct === 100 ? `Max (${formatCurrency(val)})` : `${pct}% (${formatCurrency(val)})`}
                                  </button>
                                );
                              })}
                          </div>
                        </div>
                      )}

                      {/* Capacity Progress Bar */}
                      {maxLimit > 0 && parsedAmount > 0 && (
                        <div className="mt-3">
                          <div className="d-flex justify-content-between text-muted small mb-1">
                            <span>Requested: {formatCurrency(parsedAmount)}</span>
                            <span>Cap: {formatCurrency(maxLimit)}</span>
                          </div>
                          <div className="progress" style={{ height: "6px" }}>
                            <div 
                              className={`progress-bar ${parsedAmount > maxLimit ? "bg-danger" : "bg-success"}`} 
                              role="progressbar" 
                              style={{ width: `${Math.min(100, Math.round((parsedAmount / maxLimit) * 100))}%` }}
                            />
                          </div>
                        </div>
                      )}
                    </div>

                    {/* Dynamic Real-Time Live EMI Preview Card */}
                    {parsedAmount > 0 && (
                      <div className="p-3 mb-4 rounded-3 border bg-light">
                        <div className="d-flex justify-content-between align-items-center mb-3">
                          <span className="fw-bold text-dark small"><i className="fa-solid fa-calculator text-primary me-2" />Estimated EMI Calculator <span className="text-muted fw-normal" style={{ fontSize: "11px" }}>(ROI: {applicableRoi}% p.a. - Example Only)</span></span>
                          {/* Tenure Pills */}
                          <div className="btn-group btn-group-sm" role="group">
                            {[3, 6, 12].map((months) => (
                              <button
                                key={months}
                                type="button"
                                className={`btn ${selectedTenure === months ? "btn-primary" : "btn-outline-primary"}`}
                                style={{ fontSize: "11px" }}
                                onClick={() => setSelectedTenure(months)}
                              >
                                {months} M
                              </button>
                            ))}
                          </div>
                        </div>

                        <div className="row g-2 text-center">
                          <div className="col-4 border-end">
                            <span className="text-muted d-block small" style={{ fontSize: "11px" }}>Est. Monthly EMI</span>
                            <span className="fw-bold text-primary fs-6">{formatCurrency(estimatedEmiInfo.emi)}</span>
                          </div>
                          <div className="col-4 border-end">
                            <span className="text-muted d-block small" style={{ fontSize: "11px" }}>Est. Total Interest</span>
                            <span className="fw-bold text-dark fs-6">{formatCurrency(estimatedEmiInfo.totalInterest)}</span>
                          </div>
                          <div className="col-4">
                            <span className="text-muted d-block small" style={{ fontSize: "11px" }}>Tenure</span>
                            <span className="fw-bold text-dark fs-6">{selectedTenure} Months</span>
                          </div>
                        </div>
                      </div>
                    )}

                    {/* 8-Point Borrower Consent Section */}
                    <BorrowerConsentSection
                      consentItems={consentItems}
                      onChange={(updated) => setConsentItems(updated)}
                    />

                    <div className="d-flex justify-content-end gap-2 border-top pt-4">
                      <button 
                        type="button" 
                        className="oxy-btn-secondary" 
                        onClick={() => {
                          setRequestAmount("");
                          setConsentItems(new Array(BORROWER_CONSENTS.length).fill(false));
                        }}
                      >
                        Clear
                      </button>
                      <button 
                        type="submit" 
                        className="oxy-btn-primary"
                        disabled={isSubmitDisabled}
                      >
                        {isSubmitting
                          ? "Submitting..."
                          : !profileCompleteness.loading && !profileCompleteness.isEligibleToRaiseLoan
                          ? `Profile Incomplete (${profileCompleteness.percentage}% / 90%)`
                          : "Apply For Loan"}
                      </button>
                    </div>
                  </form>
                </div>
              )}
            </div>

            <div className="col-lg-9 col-xl-8 mt-4">
              <FeeConfigInfo />
            </div>
          </div>

        </div>
      </div>
    </div>
  );
};

export default LoanRequest;
