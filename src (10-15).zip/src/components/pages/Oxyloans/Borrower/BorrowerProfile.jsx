import React, { useState, useEffect, useMemo } from "react";
import { Link, useNavigate } from "react-router-dom";
import axios from "axios";
import Swal from "sweetalert2";
import Modal from "react-bootstrap/Modal";
import PhoneInput from "react-phone-number-input";

import BorrowerHeader from "../../../Header/BorrowerHeader";
import BorrowerSidebar from "../../../SideBar/BorrowerSidebar";
import Footer from "../../../Footer/Footer";

import {
  base_url,
  profileupadate,
  setLatLong,
  loadlendernomineeDetails,
  savenomineeDeatailsApi,
  saveBorrowerReferenceDetails,
  getBorrowerReferenceDetails,
  uploadkyc,
  getuploadCredit,
  getBorrowerRunningloans,
  getBorrowerLoanDetails,
  sendWhatsappOtpapi,
  verifyWhatsappOtpapi,
  updatebankDetails,
  sendMoblieOtp,
  verifyBankAccountAndIfsc,
  getUserDetails,
  getPanDoc,
  getdataPassport,
  getdatachequeLeaf,
  getdataDrivingLicence,
  getdataVoterId,
  getdataAadhar,
  getdataBankStatement,
  analyzeBorrowerBankStatement,
  getBorrowerAnalysis,
  getBorrowerStatementById,
  getBorrowerReportPdfUser,
  getdatatenth,
  getdataintermediate,
  getdatagraduation,
  getdataofferletter,
  getdatafeereceipt,
  getdatapayslips,
  getPCreditReportDoc,
} from "../../../HttpRequest/afterlogin";

import LoadingState from "./redesign/components/LoadingState";
import KYCModal from "./redesign/components/KYCModal";
import CreditScoreModal from "./redesign/components/CreditScoreModal";
import { getCachedCreditReport, parseCreditReportData } from "./redesign/components/creditReportUtils";
import "./redesign/redesign.css";
import { Button } from "antd";
import {
  validateBorrowerPersonalDetails,
  validateBankAccountNumber,
  validateIfscCode,
  isBankNameMatching,
  validateMobileNumber,
  validatePincode,
  validateName,
  validatePanNumber,
  calculateBorrowerProfileCompleteness,
  verifyPayslipCompany,
  verifySalaryFromBankStatement,
} from "../../../../utils/borrowerValidation";

const Profile = () => {
  const navigate = useNavigate();

  // Loading States
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);

  // Edit Modal State: null | "personal" | "bank" | "nominee" | "kyc" | "references" | "pan"
  const [editSection, setEditSection] = useState(null);
  const [hasRunningLoans, setHasRunningLoans] = useState(false);

  // KYC Production Modal State
  const [kycModal, setKycModal] = useState({
    open: false,
    mode: "preview",
    documentType: "",
    fileUrl: "",
    title: "",
    fileName: "",
  });
  const [modalUploading, setModalUploading] = useState(false);
  const [showCreditModal, setShowCreditModal] = useState(false);
  const [creditBureauData, setCreditBureauData] = useState(() => {
    const cached = getCachedCreditReport();
    return cached ? parseCreditReportData(cached) : null;
  });

  const handleOpenEditSection = (section) => {
    if (hasRunningLoans) {
      if (section === "personal") {
        const isPersonalCompletedAndVerified = Boolean(
          profileData.firstName &&
          profileData.email &&
          profileData.mobileNumber &&
          profileData.panNumber &&
          (profileData.kycStatus || isPanVerified)
        );
        if (isPersonalCompletedAndVerified) {
          Swal.fire({
            icon: "warning",
            title: "Profile Editing Locked",
            text: "You have active running loans. Verified personal profile details cannot be edited while loans are active.",
            confirmButtonColor: "#006242",
          });
          return;
        }
      }

      if (section === "bank") {
        const isBankCompletedAndVerified = Boolean(
          profileData.bankDetailsInfo ||
          isBankVerified ||
          (verifiedBankAccount.accountNumber && verifiedBankAccount.ifscCode)
        );
        if (isBankCompletedAndVerified) {
          Swal.fire({
            icon: "warning",
            title: "Bank Details Locked",
            text: "You have active running loans. Verified bank account details cannot be edited while loans are active.",
            confirmButtonColor: "#006242",
          });
          return;
        }
      }

      if (section === "kyc") {
        const isKycCompletedAndVerified = Boolean(
          profileData.kycStatus === true ||
          (kycDocs && Object.values(kycDocs).filter((v) => v !== null).length > 0)
        );
        if (isKycCompletedAndVerified) {
          Swal.fire({
            icon: "warning",
            title: "KYC & Documents Locked",
            text: "You have active running loans. Verified KYC documents cannot be edited or re-uploaded while loans are active.",
            confirmButtonColor: "#006242",
          });
          return;
        }
      }

      if (section === "pan") {
        if (isPanVerified || profileData.panNumber) {
          Swal.fire({
            icon: "warning",
            title: "PAN Details Locked",
            text: "You have active running loans. Verified PAN card details cannot be edited while loans are active.",
            confirmButtonColor: "#006242",
          });
          return;
        }
      }
    }
    setEditSection(section);
  };

  // Profile data state
  const [profileData, setProfileData] = useState({
    firstName: "",
    lastName: "",
    middleName: "",
    fatherName: "",
    motherName: "",
    maritalStatus: "Single",
    spouseName: "",
    spouseDob: null,
    dob: "",
    panNumber: "",
    aadharNumber: "",
    email: "",
    mobileNumber: "",
    whatsAppNumber: "",
    residenceAddress: "",
    permanentAddress: "",
    locality: "",
    pinCode: "",
    city: "",
    state: "",
    designation: "",
    officeAddress: "",
    officeMailId: "",
    officeLandLine: "",
    facebookUrl: "",
    linkedinUrl: "",
    twitterUrl: "",
    kycStatus: false,
    bankDetailsInfo: false,
    esignedStatus: false,
    enachStatus: false,
    profileScore: 0,
    cibilScore: 0,
    userId: "",
    studentOrNot: false,
    workExperience: "",
    companyName: "",
    salary: "",
    country: "",
    universityName: "",
    location: "",
    emailVerified: false,
    whatsappVerified: false,
  });

  // Employment Category: STUDENT / SALARIED / SELFEMPLOYED
  const [category, setCategory] = useState("SALARIED");

  // Bank Account State
  const [bankaccount, setBankaccount] = useState({
    accountNumber: "",
    confirmAccountNumber: "",
    bankAddress: "",
    bankName: "",
    branchName: "",
    ifscCode: "",
    nameAtBank: "",
    bankCity: "",
    moblieNumber: "",
    mobileOtp: "",
    mobileOtpSession: "",
  });

  const [verifiedBankAccount, setVerifiedBankAccount] = useState({
    accountNumber: "",
    confirmAccountNumber: "",
    bankAddress: "",
    bankName: "",
    branchName: "",
    ifscCode: "",
    nameAtBank: "",
    bankCity: "",
    moblieNumber: "",
  });

  // Nominee State
  const [nominee, setNominee] = useState({
    nomineeName: "",
    relation: "",
    nomineeEmail: "",
    nomineeMobile: "",
    accountNo: "",
    nomineeIfsc: "",
    bank: "",
    branch: "",
    nomineecity: "",
  });

  // Reference Contacts State (minimum 2 mandatory contacts)
  const [referenceList, setReferenceList] = useState([
    { name: "", referenceNumber: "", address: "", landMark: "" },
    { name: "", referenceNumber: "", address: "", landMark: "" },
  ]);

  // Secure Passwords State
  const [secureInfo, setSecureInfo] = useState({
    aadharPassword: "",
    panPassword: "",
    bankStatementPassword: "",
    companyAddress: "",
    designation: "",
    cibilScore: "",
    comments: "",
    cibilPassword: "",
    creditReportPassword: "",
    payslipsPassword: "",
    userId: "",
  });

  // KYC Upload Documents State
  const [kycDocs, setKycDocs] = useState({
    PanCard: null,
    Passport: null,
    CHEQUELEAF: null,
    DRIVINGLICENCE: null,
    VOTERID: null,
    aadhar: null,
    bankStatement: null,
    tenth: null,
    intermediate: null,
    graduation: null,
    offerletter: null,
    feereceipt: null,
    paySlips: null,
    creditReport: null,
  });

  // Geocoding and Verification states
  const [addressGeoStatus, setAddressGeoStatus] = useState({
    loading: false,
    message: "",
    valid: null,
  });
  const [isVerifyingPan, setIsVerifyingPan] = useState(false);
  const [panVerificationStatus, setPanVerificationStatus] = useState("");
  const [isPanVerified, setIsPanVerified] = useState(false);

  // WhatsApp OTP verification state
  const [whatsappVal, setWhatsappVal] = useState("");
  const [whatsappOtp, setWhatsappOtp] = useState("");
  const [whatsappSubmitted, setWhatsappSubmitted] = useState(false);

  // Document Verification States (Payslip Company & Bank Statement Salary)
  const [payslipVerification, setPayslipVerification] = useState(() => {
    try {
      const saved = localStorage.getItem("oxy_borrower_payslip_verified");
      return saved ? JSON.parse(saved) : null;
    } catch {
      return null;
    }
  });

  const [salaryVerification, setSalaryVerification] = useState(() => {
    try {
      const saved = localStorage.getItem("oxy_borrower_salary_verified");
      return saved ? JSON.parse(saved) : null;
    } catch {
      return null;
    }
  });

  const documentNames = {
  pan: "PAN Card",
  creditReport: "Credit Bureau Report",
  CREDITREPORT: "Credit Bureau Report",
  CHEQUELEAF: "Cancelled Cheque Leaf",
  BANKSTATEMENT: "6-Month Bank Statement",
  AADHAR: "Aadhaar Card",
  DRIVINGLICENCE: "Driving Licence",
  VOTERID: "Voter ID Card",
  PASSPORT: "Passport",
  PAYSLIPS: "Latest 6-Month Payslips",
  INTER: "Intermediate Marksheet",
  TENTH: "10th Grade Marksheet",
  GRADUATION: "Graduation Marksheet",
  UNIVERSITYOFFERLETTER: "Offer Letter",
  FEE: "Fee Receipt",
};

  useEffect(() => {
    document.body.classList.add("oxy-redesign-active");
    loadAllProfileData();
    return () => {
      document.body.classList.remove("oxy-redesign-active");
    };
  }, []);

  const loadAllProfileData = async () => {
    setLoading(true);
    console.log("Loading all profile data...");
    const userId = sessionStorage.getItem("userId") || localStorage.getItem("userId");
    
    try {
      // 1. Load Personal Details
      const userRes = await getUserDetails();
      if (userRes?.status === 200 && userRes.data) {
        const d = userRes.data;
        setProfileData({
          firstName: d.firstName || "",
          lastName: d.lastName || "",
          middleName: d.middleName || "",
          fatherName: d.fatherName || "",
          motherName: d.motherName || "",
          maritalStatus: d.maritalStatus || "Single",
          spouseName: d.maritalStatus === "Married" ? (d.spouseName || "") : "",
          spouseDob: d.maritalStatus === "Married" && d.spouseDob && d.spouseDob.toString().trim() ? d.spouseDob.toString().trim() : null,
          dob: d.dob || "",
          panNumber: d.panNumber || "",
          aadharNumber: d.aadharNumber || "",
          email: d.email || "",
          mobileNumber: d.mobileNumber || "",
          whatsAppNumber: d.whatsAppNumber || "",
          residenceAddress: d.address || "",
          permanentAddress: d.permanentAddress || "",
          locality: d.locality || "",
          pinCode: d.pinCode || "",
          city: d.city || "",
          state: d.state || "",
          designation: d.designation || "",
          officeAddress: d.officeAddress || "",
          officeMailId: d.officeMailId || "",
          officeLandLine: d.officeLandLine || "",
          facebookUrl: d.urlsDto?.faceBookUrl || "",
          linkedinUrl: d.urlsDto?.linkdinUrl || "",
          twitterUrl: d.urlsDto?.twitterUrl || "",
          kycStatus: d.kycStatus || false,
          bankDetailsInfo: d.bankDetailsInfo || false,
          esignedStatus: d.esignedStatus || false,
          enachStatus: d.enachStatus || false,
          profileScore: d.profileScore || 0,
          cibilScore: d.cibilScore || 0,
          userId: d.userId || userId,
          studentOrNot: d.studentOrNot || false,
          workExperience: d.workExperience || "",
          companyName: d.companyName || "",
          salary: d.salary || "",
          country: d.country || "",
          universityName: d.universityName || "",
          location: d.location || "",
          emailVerified: d.emailVerified || false,
          whatsappVerified: d.whatsappVerified || false,
        });

        setCategory(d.studentOrNot ? "STUDENT" : d.employment || "SALARIED");
        setWhatsappVal(d.whatsAppNumber || "");

        // Set Bank Details
        const bankInfo = {
          accountNumber: d.accountNumber || "",
          confirmAccountNumber: d.accountNumber || "",
          bankAddress: d.bankAddress || "",
          bankName: d.bankName || "",
          branchName: d.branchName || "",
          ifscCode: d.ifscCode || "",
          nameAtBank: d.userName || "",
          bankCity: d.bankAddress || "",
          moblieNumber: d.mobileNumber || "",
        };
        setBankaccount(bankInfo);
        setVerifiedBankAccount(bankInfo);

        // Set PAN Verified status initially
        if (d.panVerified) {
          setIsPanVerified(true);
          setPanVerificationStatus("PAN card verified successfully!");
        }

        // Set references via getBorrowerReferenceDetails API
        try {
          const uId = d.userId || sessionStorage.getItem("userId");
          if (uId) {
            const refRes = await getBorrowerReferenceDetails(uId);
            if (refRes?.data) {
              const parsed = normalizeReferenceList(refRes.data);
              if (parsed.length > 0) {
                while (parsed.length < 2) {
                  parsed.push({ name: "", referenceNumber: "", address: "", landMark: "" });
                }
                setReferenceList(parsed);
              }
            }
          }
        } catch (refErr) {
          console.warn("Could not fetch borrower reference details via GET API:", refErr);
          if (d.referenceDetailsResponseDto) {
            const parsed = normalizeReferenceList(d.referenceDetailsResponseDto);
            while (parsed.length < 2) {
              parsed.push({ name: "", referenceNumber: "", address: "", landMark: "" });
            }
            setReferenceList(parsed);
          }
        }
      }
        console.log("Loaded personal profile data:", userRes.data);
      // 2. Load Nominee details
      const nomineeRes = await loadlendernomineeDetails();
      if (nomineeRes?.request?.status === 200 && nomineeRes.data) {
        const nd = nomineeRes.data;
        setNominee({
          nomineeName: nd.name || "",
          relation: nd.relation || "",
          nomineeEmail: nd.emial || "",
          nomineeMobile: nd.mobileNumber || "",
          accountNo: nd.accountNumber || "",
          nomineeIfsc: nd.ifscCode || "",
          bank: nd.bankName || "",
          branch: nd.branchName || "",
          nomineecity: nd.city || "",
        });
      }
      console.log("Loaded nominee details:", nomineeRes.data);
      // 3. Load KYC Files status
      await fetchKycFiles();

      // 5. Check if borrower has active running loans via getBorrowerLoanDetails(userId)
      console.log("Checking borrower running loans for userId:", userId);
      try {
        const loanDetailsRes = await getBorrowerLoanDetails(userId);
        if (loanDetailsRes?.status === 200 && loanDetailsRes.data) {
          const list = Array.isArray(loanDetailsRes.data)
            ? loanDetailsRes.data
            : [loanDetailsRes.data];

          const hasActiveDetails = list.length > 0 && list.some((item) => {
            if (!item || Object.keys(item).length === 0) return false;
            const st = String(item.loanStatus || item.status || item.loanRequestStatus || "").toUpperCase();
            return (
              st === "ACTIVE" ||
              st === "DISBURSED" ||
              st === "ENACH_APPROVED" ||
              st === "ESIGN_DONE" ||
              st === "LOANACCEPTED" ||
              st === "RUNNING" ||
              st === "REQUEST" ||
              st === "PARTIALLYPROCESSING" ||
              Number(item.requestAmount || item.loanRequestAmount || item.amount || 0) > 0
            );
          });

          if (hasActiveDetails) {
            setHasRunningLoans(true);
          } else {
            const runningRes = await getBorrowerRunningloans(1, 10);
            if (runningRes?.status === 200 && runningRes.data) {
              const runList = Array.isArray(runningRes.data)
                ? runningRes.data
                : runningRes.data.results || runningRes.data.listOfApplications || runningRes.data.loans || [];
              setHasRunningLoans(runList.length > 0);
            }
          }
          console.log("Borrower running loans check:", hasActiveDetails);
        } else {
          const runningRes = await getBorrowerRunningloans(1, 10);
          if (runningRes?.status === 200 && runningRes.data) {
            const runList = Array.isArray(runningRes.data)
              ? runningRes.data
              : runningRes.data.results || runningRes.data.listOfApplications || runningRes.data.loans || [];
            setHasRunningLoans(runList.length > 0);
          }
          console.log("Borrower running loans check: No active loans found in getBorrowerLoanDetails, fallback to getBorrowerRunningloans.");
        }
      } catch (activeErr) {
        console.log("Failed to check getBorrowerLoanDetails for profile edit lock", activeErr);
        try {
          const runningRes = await getBorrowerRunningloans(1, 10);
          if (runningRes?.status === 200 && runningRes.data) {
            const runList = Array.isArray(runningRes.data)
              ? runningRes.data
              : runningRes.data.results || runningRes.data.listOfApplications || runningRes.data.loans || [];
            setHasRunningLoans(runList.length > 0);
          }
        } catch {
          setHasRunningLoans(false);
        }
      }
    } catch (err) {
      console.error("Error populating profile data", err);
    } finally {
      setLoading(false);
    }
  };

  const fetchKycFiles = async () => {
    try {
      const creditReportPass = secureInfo?.creditReportPassword || secureInfo?.cibilPassword || "";
      const res = await Promise.allSettled([
        getPanDoc(),
        getdataPassport(),
        getdatachequeLeaf(),
        getdataDrivingLicence(),
        getdataVoterId(),
        getdataAadhar(),
        getdataBankStatement(),
        getdatatenth(),
        getdataintermediate(),
        getdatagraduation(),
        getdataofferletter(),
        getdatafeereceipt(),
        getdatapayslips(),
        getPCreditReportDoc(creditReportPass),
      ]);

      const docKeys = [
        "PanCard", "Passport", "CHEQUELEAF", "DRIVINGLICENCE", "VOTERID",
        "aadhar", "bankStatement", "tenth", "inter", "graduation",
        "universityOfferLetter", "feeReceipt", "paySlips", "creditReport"
      ];

      const updatedDocs = {};
      docKeys.forEach((key, idx) => {
        if (res[idx]?.status === "fulfilled" && res[idx].value?.data) {
          updatedDocs[key] = res[idx].value.data;
        } else {
          updatedDocs[key] = null;
        }
      });
      console.log("Fetched KYC files status:", updatedDocs);
      setKycDocs(updatedDocs);
      await fetchBorrowerAnalysisData();
    } catch (e) {
      console.error("KYC files status load failed", e);
    }
  };

  // Bank Statement Analysis states & handlers
  const [bankAnalysisData, setBankAnalysisData] = useState(null);
  const [latestStatementId, setLatestStatementId] = useState(null);
  const [analyzingBankStatement, setAnalyzingBankStatement] = useState(false);
  const [processingDocument, setProcessingDocument] = useState({
    bankStatement: false,
    creditReport: false,
  });
  const [downloadingBankReport, setDownloadingBankReport] = useState(false);
  const [pdfPasswordModal, setPdfPasswordModal] = useState({
    open: false,
    title: "",
    text: "",
    placeholder: "",
    confirmText: "Continue",
    cancelText: "Skip",
    hasPasswordChoice: null, // null (unselected) | "yes" | "no"
    password: "",
    showPassword: false,
    error: "",
    resolver: null,
  });

  const fetchBorrowerAnalysisData = async () => {
    const userId = localStorage.getItem("userId") || sessionStorage.getItem("userId");
    if (!userId) return;
    try {
      const res = await getBorrowerAnalysis(userId);
      const resData = res?.data?.data || res?.data || {};
      const statementsList = resData?.statements || resData?.results || [];

      if (Array.isArray(statementsList) && statementsList.length > 0) {
        // Sort statements by uploadedAt descending or id descending to grab the LATEST statement!
        const sortedStatements = [...statementsList].sort((a, b) => {
          if (a.uploadedAt && b.uploadedAt) {
            return new Date(b.uploadedAt) - new Date(a.uploadedAt);
          }
          return (b.id || 0) - (a.id || 0);
        });

        const latestStatement = sortedStatements[0];
        if (latestStatement?.id) {
          setLatestStatementId(latestStatement.id);

          // Pass the latest statement's ID to /v1/user/:statementId/borrower to get statement details!
          try {
            const detailRes = await getBorrowerStatementById(latestStatement.id);
            const detailData = detailRes?.data?.data || detailRes?.data || {};
            setBankAnalysisData({
              ...latestStatement,
              ...detailData,
            });
          } catch (detailErr) {
            console.log("Statement detail by ID notice:", detailErr);
            setBankAnalysisData(latestStatement);
          }
        } else {
          setBankAnalysisData(latestStatement);
        }
      } else if (resData) {
        setBankAnalysisData(resData);
      }
    } catch (e) {
      console.log("No previous bank statement analysis found yet.");
    }
  };

  // Sync Salary Verification whenever bankAnalysisData or profileData.salary changes
  useEffect(() => {
    if (bankAnalysisData) {
      const result = verifySalaryFromBankStatement(profileData.salary, bankAnalysisData);
      setSalaryVerification(result);
      try {
        localStorage.setItem("oxy_borrower_salary_verified", JSON.stringify(result));
      } catch (err) {
        console.warn("Could not cache salary verification", err);
      }
    }
  }, [profileData.salary, bankAnalysisData]);

  const handleTriggerBankAnalysis = async (customPass = null) => {
    const userId = localStorage.getItem("userId") || sessionStorage.getItem("userId");
    if (!userId) return;

    let activePassword = customPass !== null ? customPass : (secureInfo?.bankStatementPassword || "");

    // If password is not provided yet, prompt borrower to check if their bank statement PDF requires a password
    if (!activePassword && customPass === null) {
      const enteredPassword = await promptForPdfPassword({
        title: "Bank Statement PDF Password",
        text: "Please indicate whether your Bank Statement PDF is password-protected.",
        placeholder: "Enter PDF Password (e.g. DOB or Name)",
        confirmText: "Analyze Statement",
        cancelText: "Skip & Continue",
      });

      if (enteredPassword === null) {
        return; // User closed modal
      }
      activePassword = enteredPassword || "";
      if (activePassword) {
        setSecureInfo((prev) => ({ ...prev, bankStatementPassword: activePassword }));
      }
    }

    setAnalyzingBankStatement(true);
    try {
      const res = await analyzeBorrowerBankStatement(userId, activePassword);
      if (res?.data || res?.status === 200) {
        Swal.fire({
          title: "Bank Statement Analyzed",
          text: res?.data?.message || "Bank statement analysis completed successfully!",
          icon: "success",
          confirmButtonColor: "var(--oxy-primary)"
        });
        await fetchBorrowerAnalysisData();
      }
    } catch (e) {
      const errMsg = e?.response?.data?.errorMessage || e?.message || "";
      const isPasswordError =
        errMsg.toLowerCase().includes("password") ||
        errMsg.toLowerCase().includes("protected") ||
        errMsg.toLowerCase().includes("encrypted") ||
        errMsg.toLowerCase().includes("decrypt") ||
        e?.response?.status === 400 ||
        e?.response?.status === 422;

      if (isPasswordError) {
        const retryPass = await promptForPdfPassword({
          title: "Password Required",
          text: errMsg || "The uploaded bank statement PDF is encrypted or requires a password to analyze. Please enter password:",
          placeholder: "Enter Bank Statement Password",
          confirmText: "Submit & Analyze",
          cancelText: "Cancel",
          initialPassword: activePassword,
        });

        if (retryPass !== null) {
          setSecureInfo((prev) => ({ ...prev, bankStatementPassword: retryPass }));
          setAnalyzingBankStatement(false);
          return handleTriggerBankAnalysis(retryPass);
        }
      } else {
        Swal.fire({
          title: "Analysis Error",
          text: errMsg || "Failed to analyze bank statement.",
          icon: "error",
          confirmButtonColor: "var(--oxy-error)"
        });
      }
    } finally {
      setAnalyzingBankStatement(false);
    }
  };

  const handleDownloadBankReportPdf = async () => {
    const userId = localStorage.getItem("userId") || sessionStorage.getItem("userId");
    if (!userId) return;
    setDownloadingBankReport(true);
    try {
      const targetId = latestStatementId || userId;
      const res = await getBorrowerReportPdfUser(targetId);
      if (res?.data) {
        const blob = new Blob([res.data], { type: "application/pdf" });
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = url;
        a.download = `Bank_Statement_Analysis_Report_${targetId}.pdf`;
        document.body.appendChild(a);
        a.click();
        a.remove();
        window.URL.revokeObjectURL(url);
        Swal.fire("Downloaded", "Bank statement PDF report downloaded successfully.", "success");
      }
    } catch (e) {
      Swal.fire("Download Failed", e?.response?.data?.errorMessage || "Could not download PDF report.", "error");
    } finally {
      setDownloadingBankReport(false);
    }
  };

  const profileCompletenessInfo = useMemo(() => {
    return calculateBorrowerProfileCompleteness(
      { ...profileData, isPanVerified },
      referenceList,
      nominee,
      bankaccount
    );
  }, [profileData, isPanVerified, referenceList, nominee, bankaccount]);

  const profileCompletionPct = profileCompletenessInfo.percentage;

const validateNomineeDetails = (nominee) => {
  if (!nominee?.nomineeName?.trim()) {
    return { valid: false, message: "Nominee name is mandatory." };
  }
  if (!/^[a-zA-Z\s.]{2,50}$/.test(nominee.nomineeName.trim())) {
    return { valid: false, message: "Nominee name must contain only letters and spaces (at least 2 characters)." };
  }
  if (!nominee?.relation?.trim()) {
    return { valid: false, message: "Nominee relation is mandatory." };
  }
  if (!nominee?.nomineeMobile?.trim()) {
    return { valid: false, message: "Nominee mobile number is mandatory." };
  }
  if (!/^[6-9]\d{9}$/.test(nominee.nomineeMobile.trim())) {
    return { valid: false, message: "Nominee mobile must be a valid 10-digit Indian mobile number starting with 6-9." };
  }
  if (nominee.nomineeEmail?.trim() && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(nominee.nomineeEmail.trim())) {
    return { valid: false, message: "Invalid Nominee email format." };
  }
  if (nominee.accountNo?.trim() && !/^\d{9,18}$/.test(nominee.accountNo.trim())) {
    return { valid: false, message: "Nominee account number must be 9 to 18 digits." };
  }
  if (nominee.nomineeIfsc?.trim() && !/^[A-Z]{4}0[A-Z0-9]{6}$/.test(nominee.nomineeIfsc.trim().toUpperCase())) {
    return { valid: false, message: "Invalid Nominee IFSC code format (e.g. SBIN0001234)." };
  }
  return { valid: true };
};

const normalizeReferenceList = (raw) => {
  if (!raw) return [];
  let list = [];
  if (Array.isArray(raw)) {
    list = raw;
  } else if (Array.isArray(raw.referenceDto)) {
    list = raw.referenceDto;
  } else if (Array.isArray(raw.referenceDetailsResponseDto)) {
    list = raw.referenceDetailsResponseDto;
  } else if (Array.isArray(raw.references)) {
    list = raw.references;
  } else if (typeof raw === "object") {
    const legacyRefs = [];
    for (let i = 1; i <= 8; i++) {
      const val = raw[`reference${i}`];
      if (val && String(val).trim()) {
        const str = String(val).trim();
        const phoneMatch = str.match(/[6-9]\d{9}/);
        const phone = phoneMatch ? phoneMatch[0] : "";
        let name = str.replace(/[6-9]\d{9}/, "").replace(/[-–()]/g, "").trim();
        if (!name) name = `Reference ${i}`;
        legacyRefs.push({
          name,
          referenceNumber: phone || str,
          address: "",
          landMark: "",
        });
      }
    }
    if (legacyRefs.length > 0) {
      list = legacyRefs;
    }
  }

  return list.map((item) => ({
    name: item.name || item.referenceName || "",
    referenceNumber: (item.referenceNumber || item.mobileNumber || item.number || "")
      .toString()
      .replace(/\D/g, "")
      .slice(0, 10),
    address: item.address || "",
    landMark: item.landMark || item.landmark || "",
  }));
};

const validateReferenceDetails = (referenceList, borrowerMobile = "") => {
  if (!Array.isArray(referenceList)) {
    return { valid: false, message: "Invalid reference details provided." };
  }

  // Filter entries that have any field filled
  const filledEntries = referenceList.filter(
    (item) =>
      (item.name && item.name.trim() !== "") ||
      (item.referenceNumber && item.referenceNumber.trim() !== "") ||
      (item.address && item.address.trim() !== "") ||
      (item.landMark && item.landMark.trim() !== "")
  );

  if (filledEntries.length < 2) {
    return {
      valid: false,
      message: "At least 2 reference contacts with valid 10-digit mobile numbers are mandatory.",
    };
  }

  const validContacts = [];
  const mobileSet = new Set();
  const cleanBorrowerMobile = String(borrowerMobile || "").replace(/\D/g, "");

  for (let i = 0; i < filledEntries.length; i++) {
    const item = filledEntries[i];
    const cleanNum = String(item.referenceNumber || "").replace(/\D/g, "");
    const cleanName = String(item.name || "").trim();

    if (!cleanName) {
      return {
        valid: false,
        message: `Please enter a name for Reference Contact ${i + 1}.`,
      };
    }

    if (!cleanNum || cleanNum.length !== 10 || !/^[6-9]\d{9}$/.test(cleanNum)) {
      return {
        valid: false,
        message: `Reference Contact ${i + 1} (${cleanName}) must have a valid 10-digit mobile number starting with 6-9.`,
      };
    }

    if (cleanBorrowerMobile && cleanNum === cleanBorrowerMobile) {
      return {
        valid: false,
        message: `Reference mobile number (${cleanNum}) cannot be your own registered mobile number.`,
      };
    }

    if (mobileSet.has(cleanNum)) {
      return {
        valid: false,
        message: `Duplicate reference mobile number detected: ${cleanNum}. Each reference contact must be unique.`,
      };
    }

    mobileSet.add(cleanNum);
    validContacts.push({
      referenceNumber: cleanNum,
      name: cleanName,
      address: String(item.address || "").trim(),
      landMark: String(item.landMark || "").trim(),
    });
  }

  return { valid: true, sanitizedDto: validContacts };
};


  const [localityOptions, setLocalityOptions] = useState([]);
  const [cityOptions, setCityOptions] = useState([]);

  const displayCityOptions = useMemo(() => {
    return Array.from(
      new Set([
        ...(profileData.city ? [profileData.city] : []),
        ...(cityOptions || []),
      ])
    ).filter(Boolean);
  }, [profileData.city, cityOptions]);

  const handlePinCodeLookup = async (pincodeVal) => {
    if (!pincodeVal || pincodeVal.length !== 6) return;
    try {
      const res = await axios.get(`${base_url}${pincodeVal}/pincode`);
      const resData = res.data || res;

      const blocks = resData.pinresults
        ? resData.pinresults
            .map((item) => item.block)
            .filter((block, index, self) => block && self.indexOf(block) === index)
        : [];

      setLocalityOptions(blocks);

        let cities = [];
        if (typeof resData.city === "string" && resData.city.trim()) {
          cities = resData.city.split(/[,/]+/).map((c) => c.trim()).filter(Boolean);
        } else if (Array.isArray(resData.city)) {
          cities = resData.city.filter(Boolean);
        }

        if (resData.cities && Array.isArray(resData.cities)) {
          const extraCities = resData.cities.map((c) => String(c).trim()).filter(Boolean);
          cities = [...cities, ...extraCities];
        }

        if (resData.pinresults && Array.isArray(resData.pinresults)) {
          const pinCities = resData.pinresults
            .map((item) => item.city || item.district || item.districtName || item.taluk)
            .filter(Boolean);
          cities = [...cities, ...pinCities];
        }

        cities = Array.from(new Set(cities));

        setCityOptions(cities);

        const fetchedState =
          resData.state ||
          (resData.pinresults && resData.pinresults[0]?.state) ||
          (resData.pinresults && resData.pinresults[0]?.statename) ||
          "";

      setProfileData((prev) => ({
        ...prev,
        locality: blocks.length > 0 ? (blocks.includes(prev.locality) ? prev.locality : blocks[0]) : prev.locality,
        city: cities.length > 0 ? (cities.includes(prev.city) ? prev.city : cities[0]) : (resData.city || prev.city),
        state: fetchedState || prev.state,
      }));
    } catch (error) {
      console.error("Failed to fetch pincode info", error);
      setLocalityOptions([]);
      setCityOptions([]);
    }
  };

  useEffect(() => {
    if (profileData.pinCode && String(profileData.pinCode).length === 6) {
      handlePinCodeLookup(String(profileData.pinCode));
    }
  }, [profileData.pinCode]);

  // Geocoding Timer hook
  useEffect(() => {
    const address = (profileData.residenceAddress || "").trim();
    const pin = String(profileData.pinCode || "").trim();
    const city = (profileData.city || "").trim();
    const state = (profileData.state || "").trim();

    if (!address || pin.length < 6 || !city || !state) {
      setAddressGeoStatus({ loading: false, message: "", valid: null });
      return;
    }

    setAddressGeoStatus({ loading: true, message: "Verifying residential geocode location...", valid: null });

    const timer = setTimeout(async () => {
      try {
        const query = encodeURIComponent(`${address}, ${pin}, ${city}, ${state}, India`);
        const res = await axios.get(
          `https://nominatim.openstreetmap.org/search?q=${query}&format=json&limit=1&countrycodes=in`,
          { headers: { "Accept-Language": "en" } }
        );
        if (res.data && res.data.length > 0) {
          const { lat, lon } = res.data[0];
          setAddressGeoStatus({
            loading: false,
            message: `✓ Verified geocode — Lat: ${parseFloat(lat).toFixed(5)}, Lng: ${parseFloat(lon).toFixed(5)}`,
            valid: true,
          });
        } else {
          setAddressGeoStatus({ loading: false, message: "Address geocode not found. Validate pincode.", valid: false });
        }
      } catch (err) {
        setAddressGeoStatus({ loading: false, message: "Geocode verification check failed.", valid: false });
      }
    }, 1500);

    return () => clearTimeout(timer);
  }, [profileData.residenceAddress, profileData.pinCode, profileData.city, profileData.state]);

  const handleVerifyPan = async () => {
    const panCheck = validatePanNumber(profileData.panNumber);
    if (!panCheck.valid) {
      Swal.fire({
        title: "Invalid PAN Format",
        html: `${panCheck.message}<br/><br/>Would you like to edit your PAN number now?`,
        icon: "warning",
        showCancelButton: true,
        confirmButtonText: "Edit PAN Number",
        cancelButtonText: "Cancel",
      }).then((result) => {
        if (result.isConfirmed) {
          setIsPanVerified(false);
          setEditSection("personal");
        }
      });
      return;
    }
    if (!profileData.firstName) {
      Swal.fire("Validation Error", "First name is mandatory for PAN verification", "warning");
      return;
    }

    setIsVerifyingPan(true);
    setPanVerificationStatus("");
    try {
      const response = await axios.get(
        `${base_url}verifyPan?name=${encodeURIComponent(profileData.firstName)}&pan=${encodeURIComponent(profileData.panNumber)}`,
        {
          headers: {
            accessToken: sessionStorage.getItem("accessToken"),
          },
        }
      );
      if (response.status === 200 && (response.data?.valid === "true" || response.data?.valid === true || response.data?.valid === undefined)) {
        setIsPanVerified(true);
        setPanVerificationStatus("PAN card verified successfully!");
        const panName = response.data?.registered_name || response.data?.name || response.data?.panName || response.data?.registeredName || response.data?.fullName;
        if (panName) {
          setProfileData((prev) => ({ ...prev, firstName: panName }));
          try {
            const currentMaritalStatus = profileData.maritalStatus || "Single";
            const isMarried = currentMaritalStatus === "Married";
            await profileupadate({
              ...profileData,
              firstName: panName,
              panVerified: true,
              maritalStatus: currentMaritalStatus,
              spouseName: isMarried ? (profileData.spouseName || "") : "",
              spouseDob: isMarried && profileData.spouseDob && profileData.spouseDob.toString().trim() ? profileData.spouseDob.toString().trim() : null,
            });
          } catch (persistErr) {
            console.log("Error saving PAN name update", persistErr);
          }
        }
        Swal.fire("Success", panName ? `PAN verified successfully! Name updated to "${panName}".` : "PAN verified successfully!", "success");
        setEditSection(null);
      } else {
        setIsPanVerified(false);
        setPanVerificationStatus("PAN record verification failed.");
        Swal.fire({
          title: "PAN Verification Failed",
          html: `The entered PAN number <strong>${profileData.panNumber}</strong> could not be verified against tax records.<br/><br/>Please edit your PAN number and try again.`,
          icon: "error",
          showCancelButton: true,
          confirmButtonText: "Edit PAN Number",
          cancelButtonText: "Close",
        }).then((result) => {
          if (result.isConfirmed) {
            setIsPanVerified(false);
            setEditSection("personal");
          }
        });
      }
    } catch (err) {
      setIsPanVerified(false);
      setPanVerificationStatus("Verification failure.");
      Swal.fire({
        title: "PAN Verification Failed",
        html: "Unable to verify PAN card at this time.<br/><br/>Would you like to edit your PAN number?",
        icon: "error",
        showCancelButton: true,
        confirmButtonText: "Edit PAN Number",
        cancelButtonText: "Close",
      }).then((result) => {
        if (result.isConfirmed) {
          setIsPanVerified(false);
          setEditSection("personal");
        }
      });
    } finally {
      setIsVerifyingPan(false);
    }
  };

  const handleprofileInput = (e) => {
    const { name, value } = e.target;
    let sanitizedValue = value;

    if (name === "maritalStatus") {
      const selectedStatus = value || "Single";
      setProfileData((prev) => ({
        ...prev,
        maritalStatus: selectedStatus,
        ...(selectedStatus !== "Married" ? { spouseName: "", spouseDob: null } : {}),
      }));
      return;
    }

    if (name === "firstName" || name === "lastName" || name === "fatherName" || name === "motherName" || name === "spouseName" || name === "city" || name === "state") {
      sanitizedValue = value.replace(/[^a-zA-Z\s.-]/g, "").slice(0, 50);
    } else if (name === "officeLandLine") {
      sanitizedValue = value.replace(/\D/g, "").slice(0, 15);
    } else if (name === "whatsAppNumber") {
      sanitizedValue = value.replace(/\D/g, "").slice(0, 10);
    } else if (name === "pinCode") {
      sanitizedValue = value.replace(/\D/g, "").slice(0, 6);
      if (sanitizedValue.length === 6) {
        const pinCheck = validatePincode(sanitizedValue);
        if (pinCheck.valid) {
          handlePinCodeLookup(sanitizedValue);
        } else {
          setLocalityOptions([]);
          setCityOptions([]);
        }
      } else {
        setLocalityOptions([]);
        setCityOptions([]);
      }
    } else if (name === "workExperience") {
      sanitizedValue = value.replace(/\D/g, "").slice(0, 2);
    } else if (name === "panNumber") {
      sanitizedValue = value.toUpperCase().replace(/[^A-Z0-9]/g, "").slice(0, 10);
    } else if (name === "aadharNumber") {
      sanitizedValue = value.replace(/\D/g, "").slice(0, 12);
    } else if (name === "workExperience"){
      sanitizedValue = value.replace(/\D/g, "").slice(0, 2);
    } else if (name === "salary"){
      sanitizedValue = value.replace(/\D/g, "").slice(0, 10);
    }

    setProfileData((prev) => ({ ...prev, [name]: sanitizedValue }));
  };

  const handleBankInput = (e) => {
    const { name, value } = e.target;
    let sanitizedValue = value;

    if (name === "accountNumber" || name === "confirmAccountNumber") {
      sanitizedValue = value.replace(/\D/g, "").slice(0, 18);
    } else if (name === "ifscCode") {
      sanitizedValue = value.toUpperCase().replace(/[^A-Z0-9]/g, "").slice(0, 11);
    } else if (name === "moblieNumber") {
      sanitizedValue = value.replace(/\D/g, "").slice(0, 10);
    } else if (name === "mobileOtp") {
      sanitizedValue = value.replace(/\D/g, "").slice(0, 6);
    }

    setBankaccount((prev) => ({ ...prev, [name]: sanitizedValue }));
    if (name === "accountNumber" || name === "confirmAccountNumber" || name === "ifscCode") {
      setIsBankVerified(false);
    }
  };

  const handleNomineeInput = (e) => {
    const { name, value } = e.target;
    let sanitized = value;
    if (name === "nomineeMobile") {
      sanitized = value.replace(/\D/g, "").slice(0, 10);
    } else if (name === "accountNo") {
      sanitized = value.replace(/\D/g, "").slice(0, 18);
    } else if (name === "nomineeIfsc") {
      sanitized = value.toUpperCase().replace(/[^A-Z0-9]/g, "").slice(0, 11);
    }
    setNominee((prev) => ({ ...prev, [name]: sanitized }));
  };

  const handleReferenceChange = (index, field, value) => {
    setReferenceList((prev) => {
      const updated = [...prev];
      let sanitizedVal = value;
      if (field === "referenceNumber") {
        sanitizedVal = value.replace(/\D/g, "").slice(0, 10);
      }
      updated[index] = { ...updated[index], [field]: sanitizedVal };
      return updated;
    });
  };

  const handleAddReference = () => {
    setReferenceList((prev) => [
      ...prev,
      { name: "", referenceNumber: "", address: "", landMark: "" },
    ]);
  };

  const handleRemoveReference = (index) => {
    setReferenceList((prev) => {
      if (prev.length <= 2) {
        const updated = [...prev];
        updated[index] = { name: "", referenceNumber: "", address: "", landMark: "" };
        return updated;
      }
      return prev.filter((_, idx) => idx !== index);
    });
  };

  const handleSecureInput = (e) => {
    const { name, value } = e.target;
    setSecureInfo((prev) => {
      const updated = { ...prev, [name]: value };
      if (name === "cibilPassword") {
        updated.creditReportPassword = value;
      } else if (name === "creditReportPassword") {
        updated.cibilPassword = value;
      }
      return updated;
    });
  };

  const promptForPdfPassword = async ({
    title,
    text,
    placeholder,
    confirmText = "Continue",
    cancelText = "Skip",
    validationMessage = "Password is required!",
    initialPassword = "",
  }) => {
    return new Promise((resolve) => {
      setPdfPasswordModal({
        open: true,
        title,
        text,
        placeholder,
        confirmText,
        cancelText,
        hasPasswordChoice: initialPassword ? "yes" : null,
        password: initialPassword || "",
        showPassword: false,
        error: "",
        resolver: resolve,
      });
    }).then((value) => {
      if (value === undefined || value === null) return null;
      return String(value).trim();
    });
  };

  const handlePdfPasswordModalClose = () => {
    const resolver = pdfPasswordModal.resolver;
    setPdfPasswordModal({
      open: false,
      title: "",
      text: "",
      placeholder: "",
      confirmText: "Continue",
      cancelText: "Skip",
      hasPasswordChoice: null,
      password: "",
      showPassword: false,
      error: "",
      resolver: null,
    });
    if (resolver) {
      resolver(null);
    }
  };

  const handlePdfPasswordModalChange = (e) => {
    const value = e.target.value;
    // Allows all letters (a-z, A-Z), numbers, and special characters
    setPdfPasswordModal((prev) => ({ ...prev, password: value, error: "" }));
  };

  const handlePdfPasswordModalSubmit = () => {
    if (!pdfPasswordModal.hasPasswordChoice) {
      setPdfPasswordModal((prev) => ({
        ...prev,
        error: "Please select whether this file contains a password or not.",
      }));
      return;
    }

    if (pdfPasswordModal.hasPasswordChoice === "yes" && !pdfPasswordModal.password.trim()) {
      setPdfPasswordModal((prev) => ({
        ...prev,
        error: "Password is required for password-protected files.",
      }));
      return;
    }

    const password = pdfPasswordModal.hasPasswordChoice === "yes" ? (pdfPasswordModal.password || "").trim() : "";
    const resolver = pdfPasswordModal.resolver;

    setPdfPasswordModal({
      open: false,
      title: "",
      text: "",
      placeholder: "",
      confirmText: "Continue",
      cancelText: "Skip",
      hasPasswordChoice: null,
      password: "",
      showPassword: false,
      error: "",
      resolver: null,
    });

    if (resolver) {
      resolver(password);
    }
  };

  // Upload File handler
  const handleFileUploadInput = async (e) => {
    if (profileCompletionPct < 75) {
      Swal.fire("Incomplete Profile", "Personal details must be at least 75% complete before files can be uploaded.", "warning");
      return;
    }

    const file = e.target.files?.[0];

    if (e.target.name === "BANKSTATEMENT" && file) {
      let pass = secureInfo?.bankStatementPassword || "";
      setProcessingDocument((prev) => ({ ...prev, bankStatement: true }));

      const enteredPass = await promptForPdfPassword({
        title: "Bank Statement Password",
        text: "Enter the password if this PDF is protected. Leave it blank if the document is not password protected.",
        placeholder: "Enter PDF Password (optional)",
        confirmText: "Verify & Upload",
        cancelText: "Cancel",
        validationMessage: "Password can be left blank if the file is not protected.",
        initialPassword: pass,
      });

      if (enteredPass === null) {
        setProcessingDocument((prev) => ({ ...prev, bankStatement: false }));
        return;
      }

      pass = enteredPass || "";
      if (pass) {
        setSecureInfo((prev) => ({ ...prev, bankStatementPassword: pass }));
      }

      setAnalyzingBankStatement(true);
      try {
        const userId = localStorage.getItem("userId") || sessionStorage.getItem("userId");
        const analyzeRes = await analyzeBorrowerBankStatement(userId, file, pass);

        try { await uploadkyc(e, pass); } catch (uErr) { console.log("Legacy upload notice:", uErr); }

        const statementData = analyzeRes?.data?.data || analyzeRes?.data || {};
        const salaryCheck = verifySalaryFromBankStatement(profileData.salary, statementData);
        setSalaryVerification(salaryCheck);
        try {
          localStorage.setItem("oxy_borrower_salary_verified", JSON.stringify(salaryCheck));
        } catch (err) {}

        Swal.fire({
          title: salaryCheck.isMatch ? "Bank Statement Verified & Analyzed" : "Upload & Analysis Successful",
          html: `<div>${analyzeRes?.data?.message || "Bank statement uploaded and analyzed successfully!"}</div>
                 <div class="mt-3 p-3 rounded text-start" style="background:${salaryCheck.isMatch ? '#f0fdf4' : '#fffbeb'}; border:1px solid ${salaryCheck.isMatch ? '#bbf7d0' : '#fde68a'}; font-size:13px;">
                   <div><b>Declared Monthly Salary:</b> ₹${Number(profileData.salary || 0).toLocaleString("en-IN")}</div>
                   ${salaryCheck.detectedSalary > 0 ? `<div><b>Detected Monthly Inflow:</b> ₹${Number(salaryCheck.detectedSalary).toLocaleString("en-IN")}</div>` : ""}
                   <div class="mt-2 ${salaryCheck.isMatch ? 'text-success fw-bold' : 'text-dark fw-semibold'}">
                     <i class="fa-solid ${salaryCheck.isMatch ? 'fa-circle-check text-success' : 'fa-circle-info text-warning'} me-1"></i>
                     ${salaryCheck.message}
                   </div>
                 </div>`,
          icon: "success",
          confirmButtonColor: "var(--oxy-primary)"
        });
        await fetchKycFiles();
        await fetchBorrowerAnalysisData();
      } catch (err) {
        const errMsg = err?.response?.data?.errorMessage || err?.message || "";
        const isPasswordError =
          errMsg.toLowerCase().includes("password") ||
          errMsg.toLowerCase().includes("protected") ||
          errMsg.toLowerCase().includes("encrypted") ||
          errMsg.toLowerCase().includes("decrypt") ||
          err?.response?.status === 400 ||
          err?.response?.status === 422;

        if (isPasswordError) {
          const retryPass = await promptForPdfPassword({
            title: "Password Required",
            text: errMsg || "The uploaded bank statement PDF is password-protected. Please enter password:",
            placeholder: "Enter Bank Statement Password",
            confirmText: "Submit & Analyze",
            cancelText: "Cancel",
            validationMessage: "Password is required to decrypt statement PDF!",
          });

          if (retryPass === null) {
            setProcessingDocument((prev) => ({ ...prev, bankStatement: false }));
            return;
          }

          setSecureInfo((prev) => ({ ...prev, bankStatementPassword: retryPass }));

          try {
            const userId = localStorage.getItem("userId") || sessionStorage.getItem("userId");
            const retryRes = await analyzeBorrowerBankStatement(userId, file, retryPass);
            try { await uploadkyc(e, retryPass); } catch (uErr) {}
            const retryData = retryRes?.data?.data || retryRes?.data || {};
            const retrySalaryCheck = verifySalaryFromBankStatement(profileData.salary, retryData);
            setSalaryVerification(retrySalaryCheck);
            try {
              localStorage.setItem("oxy_borrower_salary_verified", JSON.stringify(retrySalaryCheck));
            } catch (err) {}

            Swal.fire({
              title: retrySalaryCheck.isMatch ? "Bank Statement Verified & Analyzed" : "Analysis Successful",
              html: `<div>Bank statement analyzed successfully!</div>
                     <div class="mt-3 p-3 rounded text-start" style="background:${retrySalaryCheck.isMatch ? '#f0fdf4' : '#fffbeb'}; border:1px solid ${retrySalaryCheck.isMatch ? '#bbf7d0' : '#fde68a'}; font-size:13px;">
                       <div><b>Declared Monthly Salary:</b> ₹${Number(profileData.salary || 0).toLocaleString("en-IN")}</div>
                       ${retrySalaryCheck.detectedSalary > 0 ? `<div><b>Detected Monthly Inflow:</b> ₹${Number(retrySalaryCheck.detectedSalary).toLocaleString("en-IN")}</div>` : ""}
                       <div class="mt-2 ${retrySalaryCheck.isMatch ? 'text-success fw-bold' : 'text-dark fw-semibold'}">
                         <i class="fa-solid ${retrySalaryCheck.isMatch ? 'fa-circle-check text-success' : 'fa-circle-info text-warning'} me-1"></i>
                         ${retrySalaryCheck.message}
                       </div>
                     </div>`,
              icon: "success",
              confirmButtonColor: "var(--oxy-primary)"
            });
            await fetchKycFiles();
            await fetchBorrowerAnalysisData();
          } catch (retryErr) {
            Swal.fire("Analysis Error", retryErr?.response?.data?.errorMessage || "Failed to analyze bank statement.", "error");
          }
          return;
        }

        try {
          const res = await uploadkyc(e, pass);
          if (res?.request?.status === 200 || res?.status === 200) {
            Swal.fire("Upload Successful", "Document uploaded successfully.", "success");
            await fetchKycFiles();
          } else {
            Swal.fire("Upload Failed", res?.data?.errorMessage || "File cannot be uploaded.", "error");
          }
        } catch {
          Swal.fire("Upload Failed", errMsg || "An error occurred during upload.", "error");
        }
      } finally {
        setAnalyzingBankStatement(false);
        setProcessingDocument((prev) => ({ ...prev, bankStatement: false }));
      }
      return;
    }

    if (
      (e.target.name === "CREDITREPORT" || e.target.name === "creditReport") &&
      file
    ) {
      setProcessingDocument((prev) => ({ ...prev, creditReport: true }));
      let pass =
        secureInfo?.creditReportPassword ||
        secureInfo?.cibilPassword ||
        "";

      const enteredPass = await promptForPdfPassword({
        title: "Credit Report Password",
        text: "Enter the password if this report is protected. Leave blank if the PDF is not password protected.",
        placeholder: "Enter Credit Report Password (optional)",
        confirmText: "Verify & Upload",
        cancelText: "Cancel",
        validationMessage: "Password can be left blank if the file is not protected.",
        initialPassword: pass,
      });

      if (enteredPass === null) {
        setProcessingDocument((prev) => ({ ...prev, creditReport: false }));
        return;
      }

      pass = enteredPass || "";
      if (pass) {
        setSecureInfo((prev) => ({
          ...prev,
          cibilPassword: pass,
          creditReportPassword: pass,
        }));
      }

      try {
        const res = await uploadkyc(e, pass);

        if (res?.request?.status === 200 || res?.status === 200) {
          await Swal.fire({
            title: "Upload Successful",
            text: "Credit Bureau Report has been uploaded and processed successfully.",
            icon: "success",
          });

          await fetchKycFiles();
        } else {
          await Swal.fire({
            title: "Upload Failed",
            text:
              res?.data?.errorMessage ||
              "Credit report cannot be uploaded.",
            icon: "error",
          });
        }
      } catch (err) {
        const errMsg =
          err?.response?.data?.errorMessage ||
          err?.message ||
          "";

        const isPasswordError =
          errMsg.toLowerCase().includes("password") ||
          errMsg.toLowerCase().includes("protected") ||
          errMsg.toLowerCase().includes("encrypted") ||
          errMsg.toLowerCase().includes("decrypt") ||
          err?.response?.status === 400 ||
          err?.response?.status === 422;

        if (isPasswordError) {
          const retryPass = await promptForPdfPassword({
            title: "Password Required",
            text: errMsg || "The uploaded Credit Report PDF is password-protected.",
            placeholder: "Enter Credit Report Password",
            confirmText: "Submit & Upload",
            cancelText: "Cancel",
            validationMessage: "Password is required!",
          });

          if (retryPass === null) {
            setProcessingDocument((prev) => ({ ...prev, creditReport: false }));
            return;
          }

          setSecureInfo((prev) => ({
            ...prev,
            cibilPassword: retryPass,
            creditReportPassword: retryPass,
          }));

          try {
            const retryRes = await uploadkyc(e, retryPass);

            if (
              retryRes?.request?.status === 200 ||
              retryRes?.status === 200
            ) {
              await Swal.fire({
                title: "Upload Successful",
                text: "Credit Bureau Report uploaded successfully.",
                icon: "success",
              });

              await fetchKycFiles();
            } else {
              await Swal.fire({
                title: "Upload Failed",
                text:
                  retryRes?.data?.errorMessage ||
                  "Credit report cannot be uploaded.",
                icon: "error",
              });
            }
          } catch (retryErr) {
            await Swal.fire({
              title: "Upload Failed",
              text:
                retryErr?.response?.data?.errorMessage ||
                "Failed to upload credit report.",
              icon: "error",
            });
          }
        } else {
          await Swal.fire({
            title: "Upload Failed",
            text: errMsg || "An error occurred during upload.",
            icon: "error",
          });
        }
      } finally {
        setProcessingDocument((prev) => ({ ...prev, creditReport: false }));
      }

      return;
    }

    if ((e.target.name === "PAYSLIPS" || e.target.name === "paySlips") && file) {
      const currentCompany = profileData.companyName || "";
      let pass = secureInfo?.payslipsPassword || "";

      const enteredPass = await promptForPdfPassword({
        title: "Payslip PDF Password",
        text: "Is your payslip password-protected? Enter the password below (leave blank if unencrypted).",
        placeholder: "Enter Payslip Password (optional)",
        confirmText: "Verify & Upload",
        cancelText: "Cancel",
        validationMessage: "Password can be left blank if not protected.",
        initialPassword: pass,
      });

      if (enteredPass === null) return;
      pass = enteredPass || "";
      if (pass) {
        setSecureInfo((prev) => ({ ...prev, payslipsPassword: pass }));
      }

      let verification = await verifyPayslipCompany(file, currentCompany);

      if (!verification.verified) {
        if (!currentCompany) {
          const { value: inputCompany, isConfirmed } = await Swal.fire({
            title: "Employer / Company Name Required",
            text: "Please enter your Employer / Company name to verify against your payslip:",
            input: "text",
            inputPlaceholder: "e.g. Infosys, TCS, Wipro, Oxyloans",
            showCancelButton: true,
            confirmButtonText: "Save & Verify",
            cancelButtonText: "Cancel",
            confirmButtonColor: "var(--oxy-primary)",
            inputValidator: (val) => (!val?.trim() ? "Company name is required!" : null),
          });

          if (!isConfirmed || !inputCompany) return;
          setProfileData((prev) => ({ ...prev, companyName: inputCompany }));
          verification = await verifyPayslipCompany(file, inputCompany);
        }

        if (!verification.verified) {
          const confirmCheck = await Swal.fire({
            title: "Verify Employer on Payslip",
            html: `We could not automatically read "<b>${currentCompany || verification.companyName}</b>" from this document text (it may be a scanned image or protected PDF).<br/><br/>Please confirm: Is this payslip officially issued by <b>${currentCompany || verification.companyName}</b>?`,
            icon: "question",
            showCancelButton: true,
            confirmButtonText: `Yes, Confirm (${currentCompany || verification.companyName})`,
            cancelButtonText: "Cancel",
            confirmButtonColor: "var(--oxy-primary)",
          });

          if (!confirmCheck.isConfirmed) return;
          verification = {
            verified: true,
            confidence: "CONFIRMED_BY_BORROWER",
            companyName: currentCompany || verification.companyName,
            message: `Confirmed by borrower for ${currentCompany || verification.companyName}`,
          };
        }
      }

      try {
        const res = await uploadkyc(e, pass);
          await fetchKycFiles();
      } catch (err) {
        Swal.fire("Upload Failed", err?.response?.data?.errorMessage || "An error occurred during upload.", "error");
      }
      return;
    }

    try {
      const res = await uploadkyc(e);
      if (res?.request?.status === 200 || res?.status === 200) {
        Swal.fire(
          "Upload Successful",
          `${documentNames[e.target.name] || "Document"} has been uploaded and processed successfully.`,
          "success"
        );
        await fetchKycFiles();
      } else {
        Swal.fire("Upload Failed", res?.data?.errorMessage || "File cannot be uploaded.", "error");
      }
    } catch {
      Swal.fire("Upload Failed", "An error occurred during upload.", "error");
    }
  };

  

  // Send Whatsapp OTP
  const handleSendWhatsappOtp = async () => {
    if (!whatsappVal) {
      Swal.fire("Invalid Number", "Enter a valid number.", "warning");
      return;
    }
    try {
      const res = await sendWhatsappOtpapi({ whatapp: whatsappVal }, whatsappVal);
      if (res) {
        setWhatsappSubmitted(true);
        Swal.fire("OTP Dispatched", "Enter OTP sent to your WhatsApp number.", "info");
      }
    } catch {
      Swal.fire("OTP Error", "Failed to dispatch verification OTP.", "error");
    }
  };

  const handleVerifyWhatsappOtp = async () => {
    if (!whatsappOtp) return;
    try {
      const res = await verifyWhatsappOtpapi({ whatapp: whatsappVal, otp: whatsappOtp });
      if (res) {
        Swal.fire("Verified", "WhatsApp number updated successfully.", "success");
        setProfileData((prev) => ({ ...prev, whatsAppNumber: whatsappVal }));
        setWhatsappSubmitted(false);
        setWhatsappOtp("");
        setEditSection(null);
      }
    } catch {
      Swal.fire("Verification Error", "Verification OTP mismatch.", "error");
    }
  };

  // distance
    const triggerSavingGoogleDistance = async (userId) => {
        try {
          await axios.post(
            `${base_url}savingGoogleDistance`,
            {
              userId: String(userId),
            },
            {
              headers: {
                accessToken: sessionStorage.getItem("accessToken"),
              },
            },
          );
        } catch (error) {
          // Silent background call - no user popup required.
          console.log("savingGoogleDistance api failed", error);
        }
      };

  // Save Personal Details form
  const savePersonalDetails = async () => {
    const effectiveMaritalStatus = profileData.maritalStatus || "Single";
    const isMarried = effectiveMaritalStatus === "Married";
    const effectiveSpouseName = isMarried ? (profileData.spouseName || "") : "";
    const rawSpouseDob = isMarried ? profileData.spouseDob : null;
    const effectiveSpouseDob = isMarried && rawSpouseDob && rawSpouseDob.toString().trim()
      ? rawSpouseDob.toString().trim()
      : null;

    const dataToValidate = {
      ...profileData,
      maritalStatus: effectiveMaritalStatus,
      spouseName: effectiveSpouseName,
      spouseDob: effectiveSpouseDob,
    };

    // Run comprehensive borrower validation rule
    console.log("Validating borrower personal details before save...", dataToValidate);
    const validationResult = validateBorrowerPersonalDetails(dataToValidate, category);
    if (!validationResult.valid) {
      Swal.fire("Validation Error", validationResult.message, "warning");
      return;
    }

    setSubmitting(true);
    try {
      // Inline verify PAN card details if not verified
      let updatedFirstName = profileData.firstName;
      if (!isPanVerified) {
        setIsVerifyingPan(true);
        setPanVerificationStatus("");
        try {
          const verifyRes = await axios.get(
            `${base_url}verifyPan?name=${encodeURIComponent(profileData.firstName)}&pan=${encodeURIComponent(profileData.panNumber)}`,
            {
              headers: {
                accessToken: sessionStorage.getItem("accessToken"),
              },
            }
          );
          if (verifyRes.status === 200 && (verifyRes.data?.valid === "true" || verifyRes.data?.valid === true || verifyRes.data?.valid === undefined)) {
            setIsPanVerified(true);
            setPanVerificationStatus("PAN card verified successfully!");
            const panName = verifyRes.data?.registered_name || verifyRes.data?.name || verifyRes.data?.panName || verifyRes.data?.registeredName || verifyRes.data?.fullName;
            if (panName) {
              updatedFirstName = panName;
              setProfileData((prev) => ({ ...prev, firstName: panName }));
            }
          } else {
            setIsPanVerified(false);
            Swal.fire({
              title: "PAN Verification Failed",
              text: "Check PAN number and Name. Must match registered tax record. Please edit your PAN number.",
              icon: "error",
              showCancelButton: true,
              confirmButtonText: "Edit PAN Number",
              cancelButtonText: "Cancel",
            }).then((result) => {
              if (result.isConfirmed) {
                setEditSection("personal");
              }
            });
            setSubmitting(false);
            return;
          }
        } catch (err) {
          setIsPanVerified(false);
          Swal.fire({
            title: "PAN Verification Failed",
            text: "Unable to verify PAN card at this time. Please edit your PAN number.",
            icon: "error",
            showCancelButton: true,
            confirmButtonText: "Edit PAN Number",
            cancelButtonText: "Cancel",
          }).then((result) => {
            if (result.isConfirmed) {
              setEditSection("personal");
            }
          });
          setSubmitting(false);
          return;
        } finally {
          setIsVerifyingPan(false);
        }
      }

      const userProfilePayload = {
        firstName: updatedFirstName,
        lastName: profileData.lastName,
        middleName: profileData.middleName,
        fatherName: profileData.fatherName,
        motherName: profileData.motherName,
        maritalStatus: effectiveMaritalStatus,
        spouseName: effectiveSpouseName,
        spouseDob: effectiveSpouseDob,
        dob: profileData.dob,
        panNumber: profileData.panNumber,
        residenceAddress: profileData.residenceAddress,
        permanentAddress: profileData.permanentAddress,
        pinCode: profileData.pinCode,
        city: profileData.city,
        state: profileData.state,
        locality: profileData.locality,
        facebookUrl: profileData.facebookUrl,
        linkedinUrl: profileData.linkedinUrl,
        twitterUrl: profileData.twitterUrl,
        whatsAppNumber: profileData.whatsAppNumber,
        aadharNumber: profileData.aadharNumber,
        designation: profileData.designation,
        officeAddress: profileData.officeAddress,
        officeMailId: profileData.officeMailId,
        officeLandLine: profileData.officeLandLine,
      };

      const formDataPayload = {
        totalExperience: profileData.workExperience,
        company: profileData.companyName,
        salary: profileData.salary,
        designation: profileData.designation,
        officeAddress: profileData.officeAddress,
        officeMailId: profileData.officeMailId,
        officeLandLine: profileData.officeLandLine,
        country: profileData.country,
        universityName: profileData.universityName,
        universityLocation: profileData.location,
      };

      const response = await profileupadate(userProfilePayload, formDataPayload, category);
      if (response?.status === 200 || response?.request?.status === 200) {
        try {
          await setLatLong();
           triggerSavingGoogleDistance(response.data.userId);
        } catch (error) {
          console.error("Failed to update google distance", error);
        }
        Swal.fire("Success", "Personal details & PAN verification saved successfully.", "success");
        setEditSection(null);
        loadAllProfileData();
      } else {
        Swal.fire("Save Failure", response?.data?.errorMessage || "Update failed.", "error");
      }
    } catch (e) {
      Swal.fire("Save Failure", "Update failed.", "error");
    } finally {
      setSubmitting(false);
    }
  };

  const [isBankVerified, setIsBankVerified] = useState(false);
  const [isVerifyingBank, setIsVerifyingBank] = useState(false);

  useEffect(() => {
    if (editSection === "bank") {
      setBankaccount({
        ...verifiedBankAccount,
        confirmAccountNumber: verifiedBankAccount.accountNumber,
        mobileOtp: "",
        mobileOtpSession: "",
      });
      if (profileData.bankDetailsInfo && verifiedBankAccount.accountNumber && verifiedBankAccount.ifscCode) {
        setIsBankVerified(true);
      } else {
        setIsBankVerified(false);
      }
      setOtpSent(false);
      setOtpButtonText("Send OTP");
    }
  }, [editSection, verifiedBankAccount, profileData.bankDetailsInfo]);

  const verifyBankDetails = async () => {
    const accCheck = validateBankAccountNumber(bankaccount.accountNumber);
    if (!accCheck.valid) {
      Swal.fire("Validation Error", accCheck.message, "warning");
      return;
    }

    if (bankaccount.accountNumber !== bankaccount.confirmAccountNumber) {
      Swal.fire("Validation Error", "Account numbers do not match!", "warning");
      return;
    }

    const ifscCheck = validateIfscCode(bankaccount.ifscCode);
    if (!ifscCheck.valid) {
      Swal.fire("Validation Error", ifscCheck.message, "warning");
      return;
    }

    setIsVerifyingBank(true);
    try {
      const response = await verifyBankAccountAndIfsc(bankaccount);
      const status = response?.status ?? response?.request?.status;
      if (status === 200) {
        const resData = response.data;
        if (resData.accountStatus === "VALID") {
          const nameAtBank = resData?.nameAtBank || bankaccount.nameAtBank || "";
          const borrowerFullName = `${profileData.firstName} ${profileData.lastName}`.trim();

          // Check if Bank Account Holder Name matches Borrower Full Name
          if (nameAtBank && borrowerFullName && !isBankNameMatching(nameAtBank, borrowerFullName)) {
            Swal.fire(
              "Bank Account Name Mismatch",
              `Bank Account Holder Name ("${nameAtBank}") does NOT match Borrower Profile Name ("${borrowerFullName}"). Bank account must belong to the borrower.`,
              "error"
            );
            setIsBankVerified(false);
            return;
          }

          Swal.fire("Verified", "Bank Account & IFSC verified successfully via Cashfree.", "success");
          setIsBankVerified(true);
          console.log("Bank Verification Response:", resData);
          setBankaccount((prev) => ({
            ...prev,
            nameAtBank: nameAtBank,
            bankName: resData?.bankName || prev.bankName || "",
            bankCity: resData?.city || prev.bankCity || "",
            branchName: resData?.branch || prev.branchName || "",
          }));
        } else {
          Swal.fire("Verification Failed", resData.message || "Failed to verify bank details. Please check your details.", "warning");
        }
      } else {
        const errorMsg = response?.response?.data?.errorMessage || "Failed to verify bank account details.";
        Swal.fire("Error", errorMsg, "error");
      }
    } catch (e) {
      Swal.fire("Error", "Failed to connect to bank verification service.", "error");
    } finally {
      setIsVerifyingBank(false);
    }
  };

  const [otpSent, setOtpSent] = useState(false);
  const [otpLoading, setOtpLoading] = useState(false);
  const [otpButtonText, setOtpButtonText] = useState("Send OTP");

  const sendBankOtp = async () => {
    if (!isBankVerified) {
      Swal.fire("Verification Required", "Please click 'Verify Bank Account' to validate your Account Number & IFSC first.", "warning");
      return;
    }
    if(otpButtonText === "Resend OTP"){
    setBankaccount((prev) => ({ ...prev, mobileOtp: "" }));
  }

    const borrowerFullName = `${profileData.firstName} ${profileData.lastName}`.trim();
    if (bankaccount.nameAtBank && borrowerFullName && !isBankNameMatching(bankaccount.nameAtBank, borrowerFullName)) {
      Swal.fire(
        "Bank Account Name Mismatch",
        `Bank Account Holder Name ("${bankaccount.nameAtBank}") does NOT match Borrower Profile Name ("${borrowerFullName}"). Bank account must belong to the borrower.`,
        "error"
      );
      return;
    }

    const phoneCheck = validateMobileNumber(bankaccount.moblieNumber, "Mobile Number");
    if (!phoneCheck.valid) {
      Swal.fire("Validation Error", phoneCheck.message, "warning");
      return;
    }

    setOtpLoading(true);
    try {
      const response = await sendMoblieOtp(bankaccount);
      if (response?.status === 200 || response?.request?.status === 200) {
        Swal.fire("OTP Sent", "A verification OTP has been sent to your mobile number.", "success");
        setOtpSent(true);
        setOtpButtonText("Resend OTP");
        setBankaccount((prev) => ({
          ...prev,
          mobileOtpSession: response.data.mobileOtpSession,
        }));
      } else {
        const errorMsg = response?.response?.data?.errorMessage || "Failed to send OTP. Please try again.";
        Swal.fire("Error", errorMsg, "error");
      }
    } catch (e) {
      Swal.fire("Error", "Failed to connect to OTP service.", "error");
    } finally {
      setOtpLoading(false);
    }
  };

  // Save Bank Details Form
  const saveBankDetails = async () => {
    if (!isBankVerified) {
      Swal.fire("Verification Required", "Please click 'Verify Bank Account' to validate your details first.", "warning");
      return;
    }

    const borrowerFullName = `${profileData.firstName} ${profileData.lastName}`.trim();
    if (bankaccount.nameAtBank && borrowerFullName && !isBankNameMatching(bankaccount.nameAtBank, borrowerFullName)) {
      Swal.fire(
        "Bank Account Name Mismatch",
        `Bank Account Holder Name ("${bankaccount.nameAtBank}") does NOT match Borrower Profile Name ("${borrowerFullName}"). Bank account must belong to the borrower.`,
        "error"
      );
      return;
    }

    const phoneCheck = validateMobileNumber(bankaccount.moblieNumber, "Mobile Number");
    if (!phoneCheck.valid) {
      Swal.fire("Validation Error", phoneCheck.message, "warning");
      return;
    }

    if (!bankaccount.mobileOtp) {
      Swal.fire("OTP Required", "Please enter the verification OTP sent to your mobile.", "warning");
      return;
    }

    setSubmitting(true);
    try {
      const res = await updatebankDetails(bankaccount);
      if (res?.status === 200 || res?.request?.status === 200) {
        Swal.fire("Success", "Linked bank information updated successfully.", "success");
        setEditSection(null);
        setOtpSent(false);
        setOtpButtonText("Send OTP");
        loadAllProfileData();
      } else {
        const errorMsg = res?.response?.data?.errorMessage || "Unable to update bank account records.";
        Swal.fire("Save Failure", errorMsg, "error");
      }
    } catch {
      Swal.fire("Save Failure", "Unable to update bank account records.", "error");
    } finally {
      setSubmitting(false);
    }
  };

  // Save Nominee details
  const saveNomineeDetails = async () => {
    const valRes = validateNomineeDetails(nominee);
    if (!valRes.valid) {
      Swal.fire("Validation Error", valRes.message, "warning");
      return;
    }

    setSubmitting(true);
    try {
      const res = await savenomineeDeatailsApi(nominee);
      if (res?.status === 200 || res?.request?.status === 200) {
        Swal.fire("Success", "Nominee details updated successfully.", "success");
        setEditSection(null);
      } else {
        Swal.fire("Save Failure", "Unable to update nominee details.", "error");
      }
    } catch {
      Swal.fire("Save Failure", "Unable to update nominee details.", "error");
    } finally {
      setSubmitting(false);
    }
  };

  // Save reference details
  const saveReferenceDetails = async () => {
    const valRes = validateReferenceDetails(referenceList, profileData.mobileNumber);
    if (!valRes.valid) {
      Swal.fire("Validation Error", valRes.message, "warning");
      return;
    }

    setSubmitting(true);
    try {
      const currentUserId = Number(profileData.userId || sessionStorage.getItem("userId"));
      const payload = {
        userId: currentUserId,
        updateReferenceDetails: true,
        referenceDto: valRes.sanitizedDto,
      };
      const res = await saveBorrowerReferenceDetails(payload);
      if (res?.status === 200 || res?.request?.status === 200) {
        Swal.fire("Success", "Reference contacts updated successfully.", "success");
        setEditSection(null);
        // Refresh reference details from GET API
        try {
          const refRes = await getBorrowerReferenceDetails(currentUserId);
          if (refRes?.data) {
            const parsed = normalizeReferenceList(refRes.data);
            while (parsed.length < 2) {
              parsed.push({ name: "", referenceNumber: "", address: "", landMark: "" });
            }
            setReferenceList(parsed);
          }
        } catch {
          // ignore
        }
      } else {
        const msg = res?.data?.errorMessage || "Unable to update reference details.";
        Swal.fire("Save Failure", msg, "error");
      }
    } catch (err) {
      console.error("Error saving reference details:", err);
      const msg = err?.response?.data?.errorMessage || "Unable to update reference details.";
      Swal.fire("Save Failure", msg, "error");
    } finally {
      setSubmitting(false);
    }
  };

  const openKYCModal = (docType, mode = null) => {
    if (!docType) return;
    const docKeyMap = {
      pan: "PanCard",
      PanCard: "PanCard",
      CREDITREPORT: "creditReport",
      creditReport: "creditReport",
      CHEQUELEAF: "CHEQUELEAF",
      BANKSTATEMENT: "bankStatement",
      bankStatement: "bankStatement",
      AADHAR: "aadhar",
      aadhar: "aadhar",
      DRIVINGLICENCE: "DRIVINGLICENCE",
      VOTERID: "VOTERID",
      PASSPORT: "Passport",
      Passport: "Passport",
      PAYSLIPS: "paySlips",
      paySlips: "paySlips",
      INTER: "intermediate",
      intermediate: "intermediate",
      TENTH: "tenth",
      tenth: "tenth",
      GRADUATION: "graduation",
      graduation: "graduation",
      OFFERLETTER: "universityOfferLetter",
      offerletter: "universityOfferLetter",
      FEERECEIPT: "feeReceipt",
      feereceipt: "feeReceipt",
    };
    const kycKey = docKeyMap[docType] || docType;
    const docObj = kycDocs?.[kycKey];
    const downloadUrl = docObj?.downloadUrl || "";
    const fileName = docObj?.fileName || "";
    const title = documentNames[docType] || docType;

    setKycModal({
      open: true,
      mode: mode || (downloadUrl ? "preview" : "upload"),
      documentType: docType,
      fileUrl: downloadUrl,
      title: title,
      fileName: fileName,
    });
  };

  const closeKYCModal = () => {
    setKycModal((prev) => ({
      ...prev,
      open: false,
    }));
  };

  const viewKYCFile = (fileUrl, title = "", docType = "", fileName = "") => {
    if (!fileUrl) {
      Swal.fire("File Not Found", "The requested KYC file is not available.", "error");
      return;
    }
    setKycModal({
      open: true,
      mode: "preview",
      documentType: docType,
      fileUrl: fileUrl,
      title: title || (docType && documentNames[docType]) || "Document Preview",
      fileName: fileName,
    });
  };

  const handleModalUploadFile = async (file, docType, password) => {
    setModalUploading(true);
    try {
      const syntheticEvent = {
        target: {
          name: docType,
          files: [file],
        },
      };

      if (docType === "BANKSTATEMENT" || docType === "bankStatement") {
        const userId = localStorage.getItem("userId") || sessionStorage.getItem("userId");
        if (password) {
          setSecureInfo((prev) => ({ ...prev, bankStatementPassword: password }));
        }
        let analyzeRes = null;
        try {
          analyzeRes = await analyzeBorrowerBankStatement(userId, file, password || "");
        } catch (aErr) {
          console.log("Bank analysis notice:", aErr);
        }
        await uploadkyc(syntheticEvent, password || "");

        const statementData = analyzeRes?.data?.data || analyzeRes?.data || {};
        const salaryCheck = verifySalaryFromBankStatement(profileData.salary, statementData);
        setSalaryVerification(salaryCheck);
        await fetchKycFiles();
        await fetchBorrowerAnalysisData();
      } else if (docType === "PAYSLIPS" || docType === "paySlips") {
        const currentCompany = profileData.companyName || "";
        let verification = await verifyPayslipCompany(file, currentCompany);

        if (!verification.verified && currentCompany) {
          const confirmCheck = await Swal.fire({
            title: "Verify Employer on Payslip",
            html: `We could not automatically read "<b>${currentCompany}</b>" from this document text (it may be a scanned image or protected PDF).<br/><br/>Please confirm: Is this payslip officially issued by <b>${currentCompany}</b>?`,
            icon: "question",
            showCancelButton: true,
            confirmButtonText: `Yes, Confirm (${currentCompany})`,
            cancelButtonText: "Cancel",
            confirmButtonColor: "var(--oxy-primary)",
          });

          if (!confirmCheck.isConfirmed) {
            setModalUploading(false);
            return;
          }
          verification = {
            verified: true,
            confidence: "CONFIRMED_BY_BORROWER",
            companyName: currentCompany,
            message: `Confirmed by borrower for ${currentCompany}`,
          };
        }

        if (password) {
          setSecureInfo((prev) => ({ ...prev, payslipsPassword: password }));
        }
        await uploadkyc(syntheticEvent, password || "");


        await fetchKycFiles();
      } else if (docType === "CREDITREPORT" || docType === "creditReport") {
        if (password) {
          setSecureInfo((prev) => ({ ...prev, creditReportPassword: password, cibilPassword: password }));
        }
        await uploadkyc(syntheticEvent, password || "");
        Swal.fire("Upload Successful", "Credit Bureau Report uploaded successfully.", "success");
        await fetchKycFiles();
      } else {
        await uploadkyc(syntheticEvent, password || "");
        Swal.fire("Upload Successful", `${documentNames[docType] || "Document"} uploaded successfully.`, "success");
        await fetchKycFiles();
      }

      closeKYCModal();
    } catch (err) {
      console.error("KYC modal upload failed:", err);
      Swal.fire("Upload Failed", err?.response?.data?.errorMessage || "An error occurred during upload.", "error");
    } finally {
      setModalUploading(false);
    }
  };

  return (
    <div className="main-wrapper">
      <BorrowerHeader />
      <BorrowerSidebar />
      <div className="page-wrapper">
        <div className="content container-fluid py-4" style={{ backgroundColor: "var(--oxy-background)" }}>
          
          {/* Active Running Loans Lock Banner */}
          {/* {hasRunningLoans && (
            <div className="alert alert-warning border border-warning shadow-sm rounded-4 mb-4 p-3 d-flex align-items-center gap-3 bg-warning bg-opacity-10">
              <div className="rounded-circle bg-warning text-dark p-3 d-flex align-items-center justify-content-center" style={{ width: "45px", height: "45px" }}>
                <i className="fa-solid fa-lock fs-5"></i>
              </div>
              <div>
                <h6 className="fw-bold text-dark mb-1">Active Loans Lock Policy Active</h6>
                <span className="text-dark small">
                  Because you have running loans, verified profile details and bank account information are locked and cannot be edited until your active loans are completed.
                </span>
              </div>
            </div>
          )} */}
          
          {loading ? (
            <LoadingState count={2} type="card" />
          ) : (
            <>
              {/* TOP HEADER BANNER CARD */}
              <div className="profile-banner mb-4">
                <div className="d-flex align-items-center justify-content-between flex-wrap gap-3">
                  <div className="d-flex align-items-center gap-3">
                    <div className="profile-avatar-circle">
                      <i className="fa-regular fa-user"></i>
                    </div>
                    <div>
                      <h4 className="fw-bold mb-1 text-white text-capitalize">
                        {profileData.firstName ? `${profileData.firstName} ${profileData.lastName}` : "—"}
                      </h4>
                      <p className="text-white-50 mb-2 small">Borrower ID: BR{profileData.userId}</p>
                      
                      <div className="d-flex gap-2 flex-wrap">
                        {/* PAN Pending warning badge */}
                        {!isPanVerified ? (
                          <span className="badge px-3 py-1.5 rounded text-dark font-bold d-inline-flex align-items-center gap-1" style={{ backgroundColor: "#ffd60a", fontSize: "12px" }}>
                            <i className="fa-solid fa-triangle-exclamation"></i> PAN Pending
                          </span>
                        ) : (
                          <span className="badge px-3 py-1.5 rounded text-white font-bold d-inline-flex align-items-center gap-1" style={{ backgroundColor: "#38b000", fontSize: "12px" }}>
                            <i className="fa-solid fa-circle-check"></i> PAN Linked
                          </span>
                        )}

                        {/* Bank account Pending badge */}
                        {!profileData.bankDetailsInfo ? (
                          <span className="badge px-3 py-1.5 rounded text-dark font-bold d-inline-flex align-items-center gap-1" style={{ backgroundColor: "#ffd60a", fontSize: "12px" }}>
                            <i className="fa-solid fa-triangle-exclamation"></i> Bank Pending
                          </span>
                        ) : verifiedBankAccount.nameAtBank && profileData.firstName && !isBankNameMatching(verifiedBankAccount.nameAtBank, `${profileData.firstName} ${profileData.lastName}`.trim()) ? (
                          <span className="badge px-3 py-1.5 rounded text-white font-bold d-inline-flex align-items-center gap-1" style={{ backgroundColor: "#dc3545", fontSize: "12px" }}>
                            <i className="fa-solid fa-triangle-exclamation"></i> Name Mismatch
                          </span>
                        ) : (
                          <span className="badge px-3 py-1.5 rounded text-white font-bold d-inline-flex align-items-center gap-1" style={{ backgroundColor: "#38b000", fontSize: "12px" }}>
                            <i className="fa-solid fa-circle-check"></i> Bank Linked
                          </span>
                        )}

                        {/* KYC Verification badge */}
                        {profileData.kycStatus === true ? (
                          <span className="badge px-3 py-1.5 rounded text-white font-bold d-inline-flex align-items-center gap-1" style={{ backgroundColor: "#38b000", fontSize: "12px" }}>
                            <i className="fa-solid fa-user-shield"></i> KYC Verified
                          </span>
                        ) : (
                          <span className="badge px-3 py-1.5 rounded text-white font-bold d-inline-flex align-items-center gap-1" style={{ backgroundColor: "#0284c7", fontSize: "12px" }}>
                            <i className="fa-solid fa-clock-rotate-left"></i> KYC Pending
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                  
                  <button 
                    className="btn edit-profile-btn"
                    onClick={() => handleOpenEditSection("personal")}
                  >
                    <i className="fa-regular fa-edit me-2"></i> Edit Profile
                  </button>
                </div>
              </div>

              {/* PROFILE COMPLETION PROGRESS & CHECKLIST CARD */}
              <div className="card border-0 shadow-sm rounded-4 mb-4 bg-white p-4">
                <div className="d-flex justify-content-between align-items-center mb-3 flex-wrap gap-2">
                  <div>
                    <h6 className="fw-bold mb-1 text-dark d-flex align-items-center gap-2">
                      <i className="fa-solid fa-sliders text-primary"></i> Profile Completeness
                    </h6>
                    <span className="text-muted small">
                      You must achieve at least <strong>90% Profile Completeness</strong> to raise a loan request.
                    </span>
                  </div>
                  <div className="d-flex align-items-center gap-2">
                    {profileCompletionPct >= 90 ? (
                      <span className="badge bg-success-subtle text-success px-3 py-2 rounded-pill fw-bold">
                        <i className="fa-solid fa-check-circle me-1"></i> Loan Request Eligible ({profileCompletionPct}%)
                      </span>
                    ) : (
                      <span className="badge bg-warning-subtle text-dark px-3 py-2 rounded-pill fw-bold">
                        <i className="fa-solid fa-triangle-exclamation me-1 text-warning"></i> {profileCompletionPct}% Completed (90% Required)
                      </span>
                    )}
                  </div>
                </div>

                <div className="progress mb-3" style={{ height: "10px", borderRadius: "10px" }}>
                  <div 
                    className={`progress-bar rounded-pill ${profileCompletionPct >= 90 ? "bg-success" : "bg-warning"}`} 
                    role="progressbar" 
                    style={{ width: `${profileCompletionPct}%`, transition: "width 0.4s ease" }}
                  />
                </div>

                {/* Checklist Chips */}
                <div className="d-flex flex-wrap gap-2 pt-2 border-top">
                  <span 
                    className={`badge p-2 px-3 rounded-pill fw-semibold border ${profileData.firstName && profileData.pinCode ? "bg-success-subtle text-success border-success-subtle" : "bg-light text-muted"}`}
                    onClick={() => handleOpenEditSection("personal")}
                    style={{ cursor: "pointer" }}
                  >
                    <i className={`fa-solid ${profileData.firstName && profileData.pinCode ? "fa-circle-check" : "fa-circle-dot"} me-1`}></i> Personal & Address
                  </span>

                  <span 
                    className={`badge p-2 px-3 rounded-pill fw-semibold border ${isPanVerified ? "bg-success-subtle text-success border-success-subtle" : "bg-light text-muted"}`}
                    onClick={() => handleOpenEditSection("personal")}
                    style={{ cursor: "pointer" }}
                  >
                    <i className={`fa-solid ${isPanVerified ? "fa-circle-check" : "fa-circle-dot"} me-1`}></i> PAN Verified
                  </span>

                  <span 
                    className={`badge p-2 px-3 rounded-pill fw-semibold border ${profileData.bankDetailsInfo && isBankVerified ? "bg-success-subtle text-success border-success-subtle" : "bg-light text-muted"}`}
                    onClick={() => handleOpenEditSection("bank")}
                    style={{ cursor: "pointer" }}
                  >
                    <i className={`fa-solid ${profileData.bankDetailsInfo && isBankVerified ? "fa-circle-check" : "fa-circle-dot"} me-1`}></i> Bank Account Linked
                  </span>

                  <span 
                    className={`badge p-2 px-3 rounded-pill fw-semibold border ${referenceList.filter(r => r.name?.trim() && r.referenceNumber?.trim()).length >= 2 ? "bg-success-subtle text-success border-success-subtle" : "bg-light text-muted"}`}
                    onClick={() => setEditSection("references")}
                    style={{ cursor: "pointer" }}
                  >
                    <i className={`fa-solid ${referenceList.filter(r => r.name?.trim() && r.referenceNumber?.trim()).length >= 2 ? "fa-circle-check" : "fa-circle-dot"} me-1`}></i> 2 Emergency References
                  </span>

                  <span 
                    className={`badge p-2 px-3 rounded-pill fw-semibold border ${profileData.kycStatus === true ? "bg-success-subtle text-success border-success-subtle" : "bg-light text-muted"}`}
                    onClick={() => handleOpenEditSection("kyc")}
                    style={{ cursor: "pointer" }}
                  >
                    <i className={`fa-solid ${profileData.kycStatus === true ? "fa-circle-check" : "fa-circle-dot"} me-1`}></i> KYC Documents
                  </span>
                </div>
              </div>

              {/* MAIN LAYOUT: TWO COLUMNS */}
              <div className="row g-4">
                
                {/* LEFT COLUMN: PERSONAL INFO CARD */}
                <div className="col-lg-6">
                  <div className="card border-0 shadow-sm rounded-4 h-100">
                    <div className="card-header bg-transparent border-0 pt-4 px-4 d-flex justify-content-between align-items-center">
                      <h5 className="fw-bold mb-0 text-dark">PERSONAL INFO</h5>
                      <button 
                        className="btn btn-link text-primary p-0 fw-semibold text-decoration-none d-flex align-items-center gap-1"
                        onClick={() => handleOpenEditSection("personal")}
                        style={{ fontSize: "14px" }}
                      >
                        <i className="fa-regular fa-edit"></i> Edit
                      </button>
                    </div>
                    
                    <div className="card-body px-4 pb-4">
                      <div className="space-y-1">
                        <div className="personal-info-row">
                          <span className="personal-info-label">Full Name as for PAN</span>
                          <span className="personal-info-value text-capitalize">{profileData.firstName} {profileData.lastName}</span>
                        </div>
                        <div className="personal-info-row">
                          <span className="personal-info-label">Date of Birth</span>
                          <span className="personal-info-value">{profileData.dob || "—"}</span>
                        </div>
                        <div className="personal-info-row">
                          <span className="personal-info-label">Email Address</span>
                          <span className="personal-info-value">{profileData.email || "—"}</span>
                        </div>
                        <div className="personal-info-row">
                          <span className="personal-info-label">WhatsApp Number</span>
                          <span className="personal-info-value">{profileData.whatsAppNumber || "—"}</span>
                        </div>
                        <div className="personal-info-row" style={{ alignItems: "flex-start" }}>
                          <span className="personal-info-label pt-1">Address</span>
                          <span className="personal-info-value text-end" style={{ maxWidth: "280px", lineHeight: "1.4" }}>
                            {profileData.residenceAddress || "—"}
                          </span>
                        </div>
                        <div className="personal-info-row">
                          <span className="personal-info-label">Pincode</span>
                          <span className="personal-info-value d-flex align-items-center gap-1">
                            {profileData.pinCode || "—"}
                            {profileData.pinCode && validatePincode(profileData.pinCode).valid ? (
                              <span className="text-success small ms-1" title="Valid Pincode"><i className="fa-solid fa-circle-check"></i></span>
                            ) : profileData.pinCode ? (
                              <span className="badge bg-danger text-white ms-1">Invalid</span>
                            ) : null}
                          </span>
                        </div>
                        <div className="personal-info-row">
                          <span className="personal-info-label">City / State</span>
                          <span className="personal-info-value">
                            {profileData.city && profileData.state ? `${profileData.city}, ${profileData.state}` : (profileData.city || profileData.state || "—")}
                          </span>
                        </div>
                        <div className="personal-info-row">
                          <span className="personal-info-label">Mother's Name</span>
                          <span className="personal-info-value">{profileData.motherName || "—"}</span>
                        </div>
                        <div className="personal-info-row">
                          <span className="personal-info-label">Marital Status</span>
                          <span className="personal-info-value">{profileData.maritalStatus || "—"}</span>
                        </div>
                        {profileData.maritalStatus === "Married" && profileData.spouseName && (
                          <>
                            <div className="personal-info-row">
                              <span className="personal-info-label">Spouse Name</span>
                              <span className="personal-info-value">{profileData.spouseName || "—"}</span>
                            </div>
                            <div className="personal-info-row">
                              <span className="personal-info-label">Spouse DOB</span>
                              <span className="personal-info-value">{profileData.spouseDob || "—"}</span>
                            </div>
                          </>
                        )}
                        <div className="personal-info-row">
                          <span className="personal-info-label">Occupation Category</span>
                          <span className="personal-info-value" style={{ fontSize: "12px" }}>{category}</span>
                        </div>
                        {category !== "STUDENT" ? (
                          <>
                            <div className="personal-info-row">
                              <span className="personal-info-label">Experience</span>
                              <span className="personal-info-value">{profileData.workExperience ? `${profileData.workExperience} Years` : "—"}</span>
                            </div>
                            <div className="personal-info-row">
                              <span className="personal-info-label">Company Name</span>
                              <span className="personal-info-value">{profileData.companyName || "—"}</span>
                            </div>
                            <div className="personal-info-row">
                              <span className="personal-info-label">Designation</span>
                              <span className="personal-info-value">{profileData.designation || "—"}</span>
                            </div>
                            <div className="personal-info-row" style={{ alignItems: "flex-start" }}>
                              <span className="personal-info-label pt-1">Office Address</span>
                              <span className="personal-info-value text-end" style={{ maxWidth: "280px", lineHeight: "1.4" }}>
                                {profileData.officeAddress || "—"}
                              </span>
                            </div>
                            <div className="personal-info-row">
                              <span className="personal-info-label">Office Email</span>
                              <span className="personal-info-value">{profileData.officeMailId || "—"}</span>
                            </div>
                            <div className="personal-info-row">
                              <span className="personal-info-label">Office Landline</span>
                              <span className="personal-info-value">{profileData.officeLandLine || "—"}</span>
                            </div>
                          </>
                        ) : (
                          <>
                            <div className="personal-info-row">
                              <span className="personal-info-label">University</span>
                              <span className="personal-info-value">{profileData.universityName || "—"}</span>
                            </div>
                          </>
                        )}
                      </div>

                      {/* NOMINEE & REFERENCES SHORTCUT TILES */}
                      <div className="row g-3 mt-4 pt-3">
                        <div className="col-6">
                          <div className="shortcut-box" onClick={() => setEditSection("nominee")} style={{ cursor: "pointer" }}>
                            <span className="text-muted d-block small mb-1">Nominee Info</span>
                            <span className="fw-bold text-primary small d-flex align-items-center gap-1">
                              {nominee.nomineeName ? nominee.nomineeName : "Add Nominee"} <i className="fa-solid fa-arrow-right-long"></i>
                            </span>
                          </div>
                        </div>
                        <div className="col-6">
                          <div className="shortcut-box" onClick={() => setEditSection("references")} style={{ cursor: "pointer" }}>
                            <span className="text-muted d-block small mb-1">References</span>
                            <span className="fw-bold text-primary small d-flex align-items-center gap-1">
                              {referenceList.filter(r => r.name?.trim() && r.referenceNumber?.trim()).length >= 2
                                ? `${referenceList.filter(r => r.name?.trim() && r.referenceNumber?.trim()).length} Added`
                                : "Add (Min 2)"} <i className="fa-solid fa-arrow-right-long"></i>
                            </span>
                          </div>
                        </div>
                      </div>

                    </div>
                  </div>
                </div>

                {/* RIGHT COLUMN: STACKED PANEL CARDS */}
                <div className="col-lg-6">
                  <div className="d-flex flex-column gap-4">
                    
                    {/* BANK ACCOUNT CARD */}
                    <div className="card border-0 shadow-sm rounded-4">
                      <div className="card-body p-4">
                        <div className="d-flex justify-content-between align-items-start mb-3">
                          <div className="d-flex align-items-center gap-2">
                            <div className="rounded bg-primary bg-opacity-10 text-primary p-2 d-flex align-items-center justify-content-center" style={{ width: "38px", height: "38px" }}>
                              <i className="fa-solid fa-building-columns"></i>
                            </div>
                            <h6 className="fw-bold text-dark mb-0" style={{ fontSize: "15px", letterSpacing: "0.5px" }}>BANK ACCOUNT</h6>
                          </div>
                          <button 
                            className="btn btn-link text-primary p-0 fw-semibold text-decoration-none d-flex align-items-center gap-1"
                            onClick={() => handleOpenEditSection("bank")}
                            style={{ fontSize: "14px" }}
                          >
                            <i className="fa-regular fa-edit"></i> Edit
                          </button>
                        </div>
                        
                        {verifiedBankAccount.accountNumber ? (
                          <div className="bank-details-box">
                            <div className="row g-3 text-start">
                              <div className="col-6">
                                <span className="bank-grid-label">Bank Name - </span>
                                <span className="bank-grid-value">{verifiedBankAccount.bankName}</span>
                              </div>
                              <div className="col-6">
                                <span className="bank-grid-label">Account Number - </span>
                                <span className="bank-grid-value">•••• {verifiedBankAccount.accountNumber.slice(-4)}</span>
                              </div>
                              <div className="col-6">
                                <span className="bank-grid-label">IFSC Code - </span>
                                <span className="bank-grid-value">{verifiedBankAccount.ifscCode}</span>
                              </div>
                              <div className="col-6">
                                <span className="bank-grid-label">Account Holder - </span>
                                <span className={`bank-grid-value text-uppercase ${verifiedBankAccount.nameAtBank && profileData.firstName && !isBankNameMatching(verifiedBankAccount.nameAtBank, `${profileData.firstName} ${profileData.lastName}`.trim()) ? "text-danger fw-bold" : ""}`}>
                                  {verifiedBankAccount.nameAtBank}
                                </span>
                              </div>
                            </div>
                            {verifiedBankAccount.nameAtBank && profileData.firstName && !isBankNameMatching(verifiedBankAccount.nameAtBank, `${profileData.firstName} ${profileData.lastName}`.trim()) && (
                              <div
                                className="mt-3 p-3 rounded-3 small fw-semibold d-flex align-items-center gap-2"
                                style={{ backgroundColor: "#fff5f5", color: "#d9534f", border: "1px solid #f5c6cb" }}
                              >
                                <i className="fa-solid fa-triangle-exclamation fs-6 me-1" style={{ color: "#d9534f" }}></i>
                                <div>
                                  <strong>Name Mismatch Warning:</strong> Bank Account Holder ("{verifiedBankAccount.nameAtBank}") does not match Borrower Name ("{`${profileData.firstName} ${profileData.lastName}`.trim()}"). Please edit bank info to link an account registered in your own name.
                                </div>
                              </div>
                            )}
                          </div>
                        ) : (
                          <p className="text-muted mb-0 small">No bank account linked. Add one to enable withdrawals.</p>
                        )}
                      </div>
                    </div>

                    {/* CREDIT BUREAU SCORE & HEALTH CARD */}
                    {/* <div className="card border-0 shadow-sm rounded-4">
                      <div className="card-body p-4">
                        <div className="d-flex justify-content-between align-items-start mb-3">
                          <div className="d-flex align-items-center gap-2">
                            <div className="rounded p-2 d-flex align-items-center justify-content-center text-white" style={{ width: "38px", height: "38px", backgroundColor: "#059669" }}>
                              <i className="fa-solid fa-chart-line"></i>
                            </div>
                            <div>
                              <h6 className="fw-bold text-dark mb-0" style={{ fontSize: "15px", letterSpacing: "0.5px" }}>CREDIT BUREAU REPORT</h6>
                              <span className="text-muted" style={{ fontSize: "11px" }}>Official Bureau Analysis</span>
                            </div>
                          </div>
                          {creditBureauData?.score ? (
                            <span className="badge bg-success bg-opacity-10 text-success border border-success border-opacity-25 px-2 py-1 rounded-pill small">
                              Verified
                            </span>
                          ) : (
                            <span className="badge bg-secondary bg-opacity-10 text-secondary border border-secondary border-opacity-25 px-2 py-1 rounded-pill small">
                              Pending
                            </span>
                          )}
                        </div>

                        {creditBureauData?.score ? (
                          <div className="p-3 bg-light rounded-3 border mb-3">
                            <div className="d-flex justify-content-between align-items-center mb-1">
                              <span className="text-muted small">Bureau Score</span>
                              <div className="d-flex align-items-baseline gap-1">
                                <span className="fw-bold text-success fs-5">{creditBureauData.score}</span>
                                <span className="text-muted small">/ 900</span>
                              </div>
                            </div>
                            <div className="d-flex justify-content-between align-items-center small">
                              <span className="text-muted">Rating & Status</span>
                              <span className="fw-semibold text-dark">
                                {creditBureauData.scoreTier?.tier || "Standard"}
                                {creditBureauData.scoreTier?.badge ? ` (${creditBureauData.scoreTier.badge})` : ""}
                              </span>
                            </div>
                            <div className="d-flex justify-content-between align-items-center small mt-1">
                              <span className="text-muted">Accounts Track</span>
                              <span className="text-muted">
                                {creditBureauData.metrics?.totalAccountsCount ?? 0} reported ({creditBureauData.metrics?.activeAccountsCount ?? 0} active)
                              </span>
                            </div>
                          </div>
                        ) : (
                          <div className="p-3 bg-light rounded-3 border mb-3 text-center">
                            <p className="text-muted small mb-0">No credit report fetched yet.</p>
                          </div>
                        )}

                        <div className="d-flex gap-2">
                          <button
                            type="button"
                            className="btn btn-outline-primary btn-sm flex-fill rounded-3"
                            onClick={() => setShowCreditModal(true)}
                          >
                            <i className="fa-solid fa-arrows-rotate me-1"></i> {creditBureauData?.score ? "Refresh" : "Fetch Report"}
                          </button>
                          {creditBureauData?.score && (
                            <Link
                              to="/instant-borrower-credit-report"
                              className="btn btn-primary btn-sm flex-fill rounded-3 text-white text-decoration-none d-flex align-items-center justify-content-center"
                              style={{ backgroundColor: "#0040e0", borderColor: "#0040e0" }}
                            >
                              Full Report <i className="fa-solid fa-arrow-right ms-1"></i>
                            </Link>
                          )}
                        </div>
                      </div>
                    </div> */}

                    {/* PAN CARD CARD */}
                    <div className="card border-0 shadow-sm rounded-4">
                      <div className="card-body p-4">
                        <div className="d-flex justify-content-between align-items-start mb-3">
                          <div className="d-flex align-items-center gap-2">
                            <div className="rounded bg-primary bg-opacity-10 text-primary p-2 d-flex align-items-center justify-content-center" style={{ width: "38px", height: "38px" }}>
                              <i className="fa-solid fa-credit-card"></i>
                            </div>
                            <h6 className="fw-bold text-dark mb-0" style={{ fontSize: "15px", letterSpacing: "0.5px" }}>PAN CARD</h6>
                          </div>
                          <button 
                            className="btn btn-link text-primary p-0 fw-semibold text-decoration-none d-flex align-items-center gap-1"
                            onClick={() => {
                              setIsPanVerified(false);
                              handleOpenEditSection("personal");
                            }}
                            style={{ fontSize: "14px" }}
                          >
                            <i className="fa-solid fa-pen-to-square"></i> {isPanVerified ? "Edit / Re-verify" : "Verify / Edit"}
                          </button>
                        </div>
                        {isPanVerified ? (
                          <div className="p-3 bg-light rounded-3 border d-flex justify-content-between align-items-center">
                            <div>
                              <span className="text-muted d-block small">PAN Number</span>
                              <span className="fw-bold text-dark">{profileData.panNumber}</span>
                            </div>
                            <span className="text-success small fw-semibold"><i className="fa-solid fa-circle-check"></i> Verified</span>
                          </div>
                        ) : (
                          <div>
                            <div className="p-3 bg-danger bg-opacity-10 rounded-3 border border-danger border-opacity-25 mb-2 d-flex justify-content-between align-items-center">
                              <div>
                                <span className="text-muted d-block small">PAN Number</span>
                                <span className="fw-bold text-danger">{profileData.panNumber || "Not Provided"}</span>
                              </div>
                              <span className="badge bg-danger text-white">Unverified / Invalid</span>
                            </div>
                            {(!profileData.panNumber || !/^[A-Z]{5}[0-9]{4}[A-Z]{1}$/.test(profileData.panNumber)) && (
                              <p className="text-danger small mb-2">
                                <i className="fa-solid fa-circle-exclamation me-1"></i>
                                {!profileData.panNumber
                                  ? "PAN number is missing. Please edit your profile to add a valid 10-character PAN."
                                  : "Invalid PAN format (must be 10 characters: e.g. ABCDE1234F). Please edit your PAN."}
                              </p>
                            )}
                            <button
                              className="btn btn-sm btn-outline-primary mt-1 d-inline-flex align-items-center gap-1"
                              onClick={() => {
                                setIsPanVerified(false);
                                handleOpenEditSection("personal");
                              }}
                            >
                              <i className="fa-solid fa-pen-to-square"></i> Edit PAN Number
                            </button>
                          </div>
                        )}
                      </div>
                    </div>

                    {/* KYC & SECURE DOCUMENTS CARD */}
                    <div className="card border-0 shadow-sm rounded-4">
                      <div className="card-body p-4">
                        <div className="d-flex justify-content-between align-items-start mb-3">
                          <div className="d-flex align-items-center gap-2">
                            <div className="rounded p-2 d-flex align-items-center justify-content-center" style={{ width: "38px", height: "38px", backgroundColor: "#fffbeb", color: "#d97706" }}>
                              <i className="fa-solid fa-folder-open"></i>
                            </div>
                            <h6 className="fw-bold text-dark mb-0" style={{ fontSize: "15px", letterSpacing: "0.5px" }}>KYC & DOCUMENT SECURE VAULT</h6>
                          </div>
                          <button 
                            className="btn btn-link text-primary p-0 fw-semibold text-decoration-none d-flex align-items-center gap-1"
                            onClick={() => handleOpenEditSection("kyc")}
                            style={{ fontSize: "14px" }}
                          >
                            <i className="fa-solid fa-cloud-arrow-up me-1"></i> Upload
                          </button>
                        </div>
                        
                        <div className="row g-2 text-start">
                          <div className="col-6">
                            <span className="text-muted d-block small">Uploaded Files</span>
                            <span className="fw-bold text-dark" style={{ fontSize: "15px" }}>
                              {Object.values(kycDocs).filter(v => v?.downloadUrl != null).length} Files
                            </span>
                          </div>
                          <div className="col-6">
                            <span className="text-muted d-block small">OxyScore</span>
                            <span className="fw-bold text-success" style={{ fontSize: "15px" }}>{profileData.profileScore || "—"}</span>
                          </div>
                        </div>

                        {/* Verification Badges Section */}
                        <div className="mt-3 pt-2 border-top">
                          <div className="d-flex flex-column gap-2" style={{ fontSize: "12px" }}>
                            {/* <div className="d-flex justify-content-between align-items-center">
                              <span className="text-muted">
                                <i className="fa-solid fa-file-invoice-dollar me-1 text-primary"></i>Employer Match:
                              </span>
                              {payslipVerification?.verified ? (
                                <span className="badge bg-success-subtle text-success py-1 px-2">
                                  <i className="fa-solid fa-check me-1"></i>Verified ({payslipVerification.companyName || profileData.companyName || "Employer"})
                                </span>
                              ) : (
                                <span className="badge bg-light text-muted py-1 px-2 border">Pending Upload</span>
                              )}
                            </div> */}
                            {/* <div className="d-flex justify-content-between align-items-center">
                              <span className="text-muted">
                                <i className="fa-solid fa-building-columns me-1 text-primary"></i>Salary Inflow:
                              </span>
                              {salaryVerification?.isMatch ? (
                                <span className="badge bg-success-subtle text-success py-1 px-2">
                                  <i className="fa-solid fa-check me-1"></i>Verified (₹{Number(salaryVerification.detectedSalary || profileData.salary || 0).toLocaleString("en-IN")})
                                </span>
                              ) : salaryVerification?.status === "VARIANCE" ? (
                                <span className="badge bg-warning-subtle text-warning py-1 px-2">
                                  Variance Review
                                </span>
                              ) : (
                                <span className="badge bg-light text-muted py-1 px-2 border">Pending Bank Statement</span>
                              )}
                            </div> */}
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* ACCOUNT SECURITY CARD */}
                    <div className="card border-0 shadow-sm rounded-4">
                      <div className="card-body p-4">
                        <div className="d-flex align-items-center gap-2 mb-3">
                          <div className="rounded p-2 d-flex align-items-center justify-content-center" style={{ width: "38px", height: "38px", backgroundColor: "#ecfdf5", color: "#059669" }}>
                            <i className="fa-solid fa-shield-halved"></i>
                          </div>
                          <h6 className="fw-bold text-dark mb-0" style={{ fontSize: "15px", letterSpacing: "0.5px" }}>ACCOUNT SECURITY</h6>
                        </div>

                        <div className="space-y-3">
                          <div className="d-flex justify-content-between align-items-center pb-2 border-bottom">
                            <span className="text-muted small">Email verified</span>
                            {profileData.emailVerified ? (
                              <span className="security-badge-yes">Yes</span>
                            ) : (
                              <span className="security-badge-no">No</span>
                            )}
                          </div>
                          <div className="d-flex justify-content-between align-items-center pt-2">
                            <span className="text-muted small">WhatsApp verified</span>
                            {profileData.whatsappVerified ? (
                              <span className="security-badge-yes">Yes</span>
                            ) : (
                              <span className="security-badge-no" onClick={() => setEditSection("whatsapp")} style={{ cursor: "pointer" }}>
                                Verify Now
                              </span>
                            )}
                          </div>
                        </div>
                      </div>
                    </div>

                  </div>
                </div>

              </div>
            </>
          )}

        </div>
      </div>

      {/* ========================================================================= */}
      {/* EDIT MODAL DIALOGS */}
      {/* ========================================================================= */}

      {/* 1. PERSONAL DETAILS EDIT MODAL */}
      <Modal show={editSection === "personal"} onHide={() => setEditSection(null)} size="lg" centered enforceFocus={false}>
        <Modal.Header closeButton>
          <Modal.Title className="fw-bold text-dark h5">Edit Profile Information</Modal.Title>
        </Modal.Header>
        <Modal.Body className="p-4">
          <div className="row g-3">
            <div className="col-md-4">
              <label className="form-label text-muted small">Name As PAN Card <span className="text-danger">*</span></label>
              <input type="text" className="form-control rounded-3" name="firstName" value={profileData.firstName} onChange={handleprofileInput} />
            </div>
            {/* <div className="col-md-4">
              <label className="form-label text-muted small">Middle Name</label>
              <input type="text" className="form-control rounded-3" name="middleName" value={profileData.middleName} onChange={handleprofileInput} />
            </div>
            <div className="col-md-4">
              <label className="form-label text-muted small">Last Name</label>
              <input type="text" className="form-control rounded-3" name="lastName" value={profileData.lastName} onChange={handleprofileInput} />
            </div> */}
            <div className="col-md-6">
              <label className="form-label text-muted small">Father's Name <span className="text-danger">*</span></label>
              <input type="text" className="form-control rounded-3" name="fatherName" value={profileData.fatherName} onChange={handleprofileInput} />
            </div>
            <div className="col-md-6">
              <label className="form-label text-muted small">Mother's Name <span className="text-danger">*</span></label>
              <input type="text" className="form-control rounded-3" name="motherName" value={profileData.motherName} onChange={handleprofileInput} placeholder="Enter Mother's Name" />
            </div>
            <div className="col-md-6">
              <label className="form-label text-muted small">Date of Birth (YYYY-MM-DD) <span className="text-danger">*</span></label>
              <input type="text" className="form-control rounded-3" name="dob" value={profileData.dob} onChange={handleprofileInput} placeholder="YYYY-MM-DD" />
            </div>
            <div className="col-md-6">
              <label className="form-label text-muted small">Marital Status <span className="text-danger">*</span></label>
              <select className="form-select rounded-3" name="maritalStatus" value={profileData.maritalStatus || "Single"} onChange={handleprofileInput} required>
                <option value="Single">Single</option>
                <option value="Married">Married</option>
                <option value="Divorced">Divorced</option>
                <option value="Widowed">Widowed</option>
              </select>
            </div>
            {(profileData.maritalStatus || "Single") === "Married" && (
              <>
                <div className="col-md-6">
                  <label className="form-label text-muted small">Spouse Name <span className="text-danger">*</span></label>
                  <input type="text" className="form-control rounded-3" name="spouseName" value={profileData.spouseName || ""} onChange={handleprofileInput} placeholder="Enter spouse full name" required />
                </div>
                <div className="col-md-6">
                  <label className="form-label text-muted small">Spouse Date of Birth</label>
                  <input type="text" className="form-control rounded-3" name="spouseDob" value={profileData.spouseDob || ""} onChange={handleprofileInput} placeholder="DD/MM/YYYY or YYYY-MM-DD" />
                </div>
              </>
            )}
            <div className="col-md-6">
              <div className="d-flex justify-content-between align-items-center mb-1">
                <label className="form-label text-muted small mb-0">PAN Card Number <span className="text-danger">*</span></label>
                {isPanVerified && (
                  <button
                    type="button"
                    className="btn btn-link btn-sm p-0 text-primary text-decoration-none small"
                    onClick={() => setIsPanVerified(false)}
                  >
                    <i className="fa-solid fa-pen-to-square me-1"></i>Unlock to Edit
                  </button>
                )}
              </div>
              <input
                type="text"
                className={`form-control rounded-3 ${profileData.panNumber && !/^[A-Z]{5}[0-9]{4}[A-Z]{1}$/.test(profileData.panNumber) ? "is-invalid" : ""}`}
                name="panNumber"
                value={profileData.panNumber}
                onChange={handleprofileInput}
                maxLength={10}
                placeholder="ABCDE1234F"
                disabled={isPanVerified}
              />
              {profileData.panNumber && !/^[A-Z]{5}[0-9]{4}[A-Z]{1}$/.test(profileData.panNumber) ? (
                <div className="invalid-feedback d-block small mt-1">
                  <i className="fa-solid fa-circle-exclamation me-1"></i>
                  Invalid PAN format (must be 10 characters: 5 letters, 4 digits, 1 letter, e.g. ABCDE1234F).
                </div>
              ) : isPanVerified ? (
                <div className="text-success small mt-1">
                  <i className="fa-solid fa-circle-check me-1"></i>Verified PAN Card
                </div>
              ) : null}
            </div>
            <div className="col-md-6">
              <label className="form-label text-muted small">Aadhaar Number</label>
              <input type="text" className="form-control rounded-3" name="aadharNumber" value={profileData.aadharNumber} onChange={handleprofileInput} />
            </div>
            <div className="col-md-6">
              <label className="form-label text-muted small">WhatsApp Number <span className="text-danger">*</span></label>
              <input type="text" className="form-control rounded-3" name="whatsAppNumber" value={profileData.whatsAppNumber} onChange={handleprofileInput} />
            </div>
            <div className="col-12">
              <label className="form-label text-muted small">Residential Address <span className="text-danger">*</span></label>
              <input type="text" className="form-control rounded-3" name="residenceAddress" value={profileData.residenceAddress} onChange={handleprofileInput} />
            </div>
            <div className="col-md-4">
              <label className="form-label text-muted small">Pincode <span className="text-danger">*</span></label>
              <input
                type="text"
                className={`form-control rounded-3 ${profileData.pinCode && !validatePincode(profileData.pinCode).valid ? "is-invalid" : ""}`}
                name="pinCode"
                value={profileData.pinCode}
                onChange={handleprofileInput}
                maxLength={6}
                placeholder="e.g. 500072"
              />
              {profileData.pinCode && !validatePincode(profileData.pinCode).valid ? (
                <div className="invalid-feedback d-block small mt-1">
                  <i className="fa-solid fa-triangle-exclamation me-1"></i>
                  {validatePincode(profileData.pinCode).message}
                </div>
              ) : profileData.pinCode && profileData.pinCode.length === 6 && validatePincode(profileData.pinCode).valid ? (
                <div className="text-success small mt-1">
                  <i className="fa-solid fa-circle-check me-1"></i>Valid Pincode
                </div>
              ) : null}
            </div>
            <div className="col-md-4">
              <label className="form-label text-muted small">City <span className="text-danger">*</span></label>
              {displayCityOptions && displayCityOptions.length > 0 ? (
                <select
                  className={`form-select rounded-3 ${profileData.city && !validateName(profileData.city, "City").valid ? "is-invalid" : ""}`}
                  name="city"
                  value={profileData.city}
                  onChange={handleprofileInput}
                >
                  <option value="">Select City</option>
                  {displayCityOptions.map((c, index) => (
                    <option key={index} value={c}>
                      {c}
                    </option>
                  ))}
                </select>
              ) : (
                <input
                  type="text"
                  className={`form-control rounded-3 ${profileData.city && !validateName(profileData.city, "City").valid ? "is-invalid" : ""}`}
                  name="city"
                  value={profileData.city}
                  onChange={handleprofileInput}
                  placeholder="e.g. Hyderabad"
                />
              )}
              {profileData.city && !validateName(profileData.city, "City").valid && (
                <div className="invalid-feedback d-block small mt-1">
                  <i className="fa-solid fa-triangle-exclamation me-1"></i>
                  {validateName(profileData.city, "City").message}
                </div>
              )}
            </div>
            <div className="col-md-4">
              <label className="form-label text-muted small">State <span className="text-danger">*</span></label>
              <input
                type="text"
                className={`form-control rounded-3 ${profileData.state && !validateName(profileData.state, "State").valid ? "is-invalid" : ""}`}
                name="state"
                value={profileData.state}
                onChange={handleprofileInput}
                placeholder="e.g. Telangana"
              />
              {profileData.state && !validateName(profileData.state, "State").valid && (
                <div className="invalid-feedback d-block small mt-1">
                  <i className="fa-solid fa-triangle-exclamation me-1"></i>
                  {validateName(profileData.state, "State").message}
                </div>
              )}
            </div>
            {localityOptions && localityOptions.length > 0 && (
              <div className="col-md-4">
                <label className="form-label text-muted small">Locality</label>
                <select
                  className="form-select rounded-3"
                  name="locality"
                  value={profileData.locality}
                  onChange={handleprofileInput}
                >
                  <option value="">Select Locality</option>
                  {localityOptions.map((loc, index) => (
                    <option key={index} value={loc}>
                      {loc}
                    </option>
                  ))}
                </select>
              </div>
            )}
            
            <hr className="my-3 opacity-10" />
            <h6 className="fw-bold text-dark">Occupation & Category Details</h6>
            <div className="col-md-6">
              <label className="form-label text-muted small">Employment Category <span className="text-danger">*</span></label>
              <select className="form-select rounded-3" value={category} onChange={(e) => setCategory(e.target.value)}>
                <option value="SALARIED">Salaried Employee</option>
                <option value="SELFEMPLOYED">Self-Employed</option>
                <option value="STUDENT">Student Profile</option>
              </select>
            </div>
            {category !== "STUDENT" ? (
              <>
                <div className="col-md-6">
                  <label className="form-label text-muted small">Work Experience (Years) <span className="text-danger">*</span></label>
                  <input type="text" className="form-control rounded-3" name="workExperience" value={profileData.workExperience} onChange={handleprofileInput} placeholder="Years of experience" required />
                </div>
                <div className="col-md-6">
                  <label className="form-label text-muted small">Company Name <span className="text-danger">*</span></label>
                  <input type="text" className="form-control rounded-3" name="companyName" value={profileData.companyName} onChange={handleprofileInput} placeholder="Enter company name" required />
                </div>
                <div className="col-md-6">
                  <label className="form-label text-muted small">Monthly Net Salary (₹) <span className="text-danger">*</span></label>
                  <input type="text" className="form-control rounded-3" name="salary" value={profileData.salary} onChange={handleprofileInput} placeholder="Enter monthly net salary" required />
                </div>
                <div className="col-md-6">
                  <label className="form-label text-muted small">Designation / Role</label>
                  <input type="text" className="form-control rounded-3" name="designation" value={profileData.designation} onChange={handleprofileInput} placeholder="Enter designation / role" />
                </div>
                <div className="col-md-6">
                  <label className="form-label text-muted small">Official / Work Email</label>
                  <input type="email" className="form-control rounded-3" name="officeMailId" value={profileData.officeMailId} onChange={handleprofileInput} placeholder="e.g. name@company.com" />
                </div>
                <div className="col-md-6">
                  <label className="form-label text-muted small">Office Landline No. <span className="text-muted">(Optional)</span></label>
                  <input type="text" className="form-control rounded-3" name="officeLandLine" value={profileData.officeLandLine} onChange={handleprofileInput} placeholder="e.g. 04012345678" />
                </div>
                <div className="col-12">
                  <label className="form-label text-muted small">Office / Company Address</label>
                  <input type="text" className="form-control rounded-3" name="officeAddress" value={profileData.officeAddress} onChange={handleprofileInput} placeholder="Enter office / company address" />
                </div>
              </>
            ) : (
              <>
                <div className="col-md-6">
                  <label className="form-label text-muted small">Target Study Country</label>
                  <input type="text" className="form-control rounded-3" name="country" value={profileData.country} onChange={handleprofileInput} />
                </div>
                <div className="col-md-6">
                  <label className="form-label text-muted small">University Name</label>
                  <input type="text" className="form-control rounded-3" name="universityName" value={profileData.universityName} onChange={handleprofileInput} />
                </div>
                <div className="col-md-6">
                  <label className="form-label text-muted small">University Location</label>
                  <input type="text" className="form-control rounded-3" name="location" value={profileData.location} onChange={handleprofileInput} />
                </div>
              </>
            )}
            
            <hr className="my-3 opacity-10" />
            <h6 className="fw-bold text-dark">Social Media Profiles</h6>
            <div className="col-md-4">
              <label className="form-label text-muted small">Facebook URL</label>
              <input type="text" className="form-control rounded-3" name="facebookUrl" value={profileData.facebookUrl} onChange={handleprofileInput} />
            </div>
            <div className="col-md-4">
              <label className="form-label text-muted small">LinkedIn URL</label>
              <input type="text" className="form-control rounded-3" name="linkedinUrl" value={profileData.linkedinUrl} onChange={handleprofileInput} />
            </div>
            <div className="col-md-4">
              <label className="form-label text-muted small">Twitter URL</label>
              <input type="text" className="form-control rounded-3" name="twitterUrl" value={profileData.twitterUrl} onChange={handleprofileInput} />
            </div>
          </div>
        </Modal.Body>
        <Modal.Footer>
          <button className="oxy-btn-secondary" onClick={() => setEditSection(null)}>Cancel</button>
          <button className="oxy-btn-primary" onClick={savePersonalDetails} disabled={submitting}>
            {submitting ? "Saving..." : "Save Changes"}
          </button>
        </Modal.Footer>
      </Modal>

      {/* 2. BANK ACCOUNT DETAILS MODAL */}
      <Modal show={editSection === "bank"} onHide={() => { setEditSection(null); setOtpSent(false); setOtpButtonText("Send OTP"); }} centered enforceFocus={false}>
        <Modal.Header closeButton>
          <Modal.Title className="fw-bold text-dark h5">Edit Bank Information</Modal.Title>
        </Modal.Header>
        <Modal.Body className="p-4">
          <div className="row g-3">
            <div className="col-12">
              <label className="form-label text-muted small">Account Number</label>
              <input type="text" className="form-control rounded-3" name="accountNumber" value={bankaccount.accountNumber} onChange={handleBankInput} />
            </div>
            <div className="col-12">
              <label className="form-label text-muted small">Confirm Account Number</label>
              <input type="text" className="form-control rounded-3" name="confirmAccountNumber" value={bankaccount.confirmAccountNumber} onChange={handleBankInput} />
            </div>
            <div className="col-12">
              <label className="form-label text-muted small">IFSC Code</label>
              <input type="text" className="form-control rounded-3" name="ifscCode" value={bankaccount.ifscCode} onChange={handleBankInput} />
            </div>

            {!isBankVerified && (
              <div className="col-12 text-end">
                <button className="btn btn-primary btn-sm rounded-3" type="button" onClick={verifyBankDetails} disabled={isVerifyingBank}>
                  {isVerifyingBank ? <span className="spinner-border spinner-border-sm me-1" /> : null}
                  Verify Bank Account
                </button>
              </div>
            )}

            {isBankVerified && (
              <>
                <div className="col-12 bg-success-subtle p-2 rounded-3 text-success small mb-2 d-flex align-items-center">
                  <i className="fa-solid fa-circle-check me-2"></i> Account Verified Successfully
                </div>
                <div className="col-12">
                  <label className="form-label text-muted small">Name at Bank</label>
                  <input type="text" className="form-control rounded-3 bg-light" name="nameAtBank" value={bankaccount.nameAtBank} readOnly />
                </div>
                <div className="col-12">
                  <label className="form-label text-muted small">Bank Name</label>
                  <input type="text" className="form-control rounded-3 bg-light" name="bankName" value={bankaccount.bankName} readOnly />
                </div>
                <div className="col-md-6">
                  <label className="form-label text-muted small">Branch Name</label>
                  <input type="text" className="form-control rounded-3 bg-light" name="branchName" value={bankaccount.branchName} readOnly />
                </div>
                <div className="col-md-6">
                  <label className="form-label text-muted small">Bank City</label>
                  <input type="text" className="form-control rounded-3 bg-light" name="bankCity" value={bankaccount.bankCity} readOnly />
                </div>
                <div className="col-12">
                  <label className="form-label text-muted small">Mobile Number (For Verification)</label>
                  <div className="input-group">
                    <input type="text" className="form-control rounded-3-start" name="moblieNumber" value={bankaccount.moblieNumber} onChange={handleBankInput} maxLength={10} placeholder="Enter 10-digit mobile number" />
                    <button className="btn btn-outline-secondary" type="button" onClick={sendBankOtp} disabled={otpLoading}>
                      {otpLoading ? <span className="spinner-border spinner-border-sm me-1" /> : null}
                      {otpButtonText}
                    </button>
                  </div>
                </div>
                {otpSent && (
                  <div className="col-12">
                    <label className="form-label text-success small fw-bold">Enter Mobile OTP</label>
                    <input type="text" className="form-control rounded-3 border-success" name="mobileOtp" value={bankaccount.mobileOtp} onChange={handleBankInput} maxLength={6} placeholder="Enter 6-digit verification OTP" />
                  </div>
                )}
              </>
            )}
          </div>
        </Modal.Body>
        <Modal.Footer>
          <button className="oxy-btn-secondary" onClick={() => { setEditSection(null); setOtpSent(false); setOtpButtonText("Send OTP"); }}>Cancel</button>
          <button className="oxy-btn-primary" onClick={saveBankDetails} disabled={submitting || !isBankVerified}>
            {submitting ? "Saving..." : "Save Bank Info"}
          </button>
        </Modal.Footer>
      </Modal>

      {/* 3. NOMINEE DETAILS MODAL */}
      <Modal show={editSection === "nominee"} onHide={() => setEditSection(null)} size="lg" centered enforceFocus={false}>
        <Modal.Header closeButton>
          <Modal.Title className="fw-bold text-dark h5">Nominee details</Modal.Title>
        </Modal.Header>
        <Modal.Body className="p-4">
          <div className="row g-3">
            <div className="col-md-4">
              <label className="form-label text-muted small">Nominee Name</label>
              <input type="text" className="form-control rounded-3" name="nomineeName" value={nominee.nomineeName} onChange={handleNomineeInput} />
            </div>
            <div className="col-md-4">
              <label className="form-label text-muted small">Relation</label>
              <input type="text" className="form-control rounded-3" name="relation" value={nominee.relation} onChange={handleNomineeInput} />
            </div>
            <div className="col-md-4">
              <label className="form-label text-muted small">Nominee Mobile</label>
              <input type="text" className="form-control rounded-3" name="nomineeMobile" value={nominee.nomineeMobile} onChange={handleNomineeInput} />
            </div>
            <div className="col-md-6">
              <label className="form-label text-muted small">Nominee Email</label>
              <input type="email" className="form-control rounded-3" name="nomineeEmail" value={nominee.nomineeEmail} onChange={handleNomineeInput} />
            </div>
            <div className="col-md-6">
              <label className="form-label text-muted small">Nominee Account No</label>
              <input type="text" className="form-control rounded-3" name="accountNo" value={nominee.accountNo} onChange={handleNomineeInput} />
            </div>
            <div className="col-md-4">
              <label className="form-label text-muted small">Nominee IFSC Code</label>
              <input type="text" className="form-control rounded-3" name="nomineeIfsc" value={nominee.nomineeIfsc} onChange={handleNomineeInput} />
            </div>
            <div className="col-md-4">
              <label className="form-label text-muted small">Nominee Bank Name</label>
              <input type="text" className="form-control rounded-3" name="bank" value={nominee.bank} onChange={handleNomineeInput} />
            </div>
            <div className="col-md-4">
              <label className="form-label text-muted small">Nominee Bank City</label>
              <input type="text" className="form-control rounded-3" name="nomineecity" value={nominee.nomineecity} onChange={handleNomineeInput} />
            </div>
          </div>
        </Modal.Body>
        <Modal.Footer>
          <button className="oxy-btn-secondary" onClick={() => setEditSection(null)}>Cancel</button>
          <button className="oxy-btn-primary" onClick={saveNomineeDetails} disabled={submitting}>
            {submitting ? "Saving..." : "Save Nominee Info"}
          </button>
        </Modal.Footer>
      </Modal>

      {/* 4. REFERENCES EDIT MODAL */}
      <Modal show={editSection === "references"} onHide={() => setEditSection(null)} size="lg" centered enforceFocus={false}>
        <Modal.Header closeButton>
          <div>
            <Modal.Title className="fw-bold text-dark h5 mb-0">Emergency Reference Contacts</Modal.Title>
            <small className="text-muted">
              Any two reference contact numbers are mandatory (<span className="text-danger">*</span>).
            </small>
          </div>
        </Modal.Header>
        <Modal.Body className="p-4" style={{ maxHeight: "70vh", overflowY: "auto" }}>
          <div className="alert alert-light border d-flex align-items-center gap-2 py-2 px-3 mb-4 rounded-3 text-secondary small">
            <i className="fa-solid fa-circle-info text-primary fs-6"></i>
            <span>
              Please provide at least <strong>2 valid reference contacts</strong> with their name, 10-digit mobile number, address, and landmark.
            </span>
          </div>

          <div className="d-flex flex-column gap-3">
            {referenceList.map((ref, index) => {
              const isMandatory = index < 2;
              return (
                <div key={index} className="card border rounded-3 p-3 bg-light-subtle shadow-none">
                  <div className="d-flex justify-content-between align-items-center mb-3">
                    <div className="d-flex align-items-center gap-2">
                      <span className="badge bg-primary rounded-pill px-2 py-1 small">
                        #{index + 1}
                      </span>
                      <strong className="text-dark">
                        Reference Contact {index + 1}
                      </strong>
                      {isMandatory ? (
                        <span className="badge bg-danger-subtle text-danger border border-danger-subtle small">
                          Mandatory Contact
                        </span>
                      ) : (
                        <span className="badge bg-secondary-subtle text-secondary small">
                          Additional Contact
                        </span>
                      )}
                    </div>
                    {referenceList.length > 2 && (
                      <button
                        type="button"
                        className="btn btn-outline-danger btn-sm py-0 px-2"
                        onClick={() => handleRemoveReference(index)}
                        title="Remove contact"
                      >
                        <i className="fa-solid fa-trash-can small me-1"></i> Remove
                      </button>
                    )}
                  </div>

                  <div className="row g-3">
                    <div className="col-md-6">
                      <label className="form-label text-muted small mb-1">
                        Contact Name {isMandatory && <span className="text-danger">*</span>}
                      </label>
                      <input
                        type="text"
                        className="form-control rounded-3"
                        placeholder="Enter contact full name"
                        value={ref.name}
                        onChange={(e) => handleReferenceChange(index, "name", e.target.value)}
                      />
                    </div>
                    <div className="col-md-6">
                      <label className="form-label text-muted small mb-1">
                        Mobile Number {isMandatory && <span className="text-danger">*</span>}
                      </label>
                      <input
                        type="text"
                        maxLength={10}
                        className="form-control rounded-3"
                        placeholder="10-digit mobile number"
                        value={ref.referenceNumber}
                        onChange={(e) => handleReferenceChange(index, "referenceNumber", e.target.value)}
                      />
                    </div>
                    <div className="col-md-6">
                      <label className="form-label text-muted small mb-1">
                        Address
                      </label>
                      <input
                        type="text"
                        className="form-control rounded-3"
                        placeholder="Enter house no., street, area"
                        value={ref.address}
                        onChange={(e) => handleReferenceChange(index, "address", e.target.value)}
                      />
                    </div>
                    <div className="col-md-6">
                      <label className="form-label text-muted small mb-1">
                        Landmark
                      </label>
                      <input
                        type="text"
                        className="form-control rounded-3"
                        placeholder="Enter nearby landmark (optional)"
                        value={ref.landMark}
                        onChange={(e) => handleReferenceChange(index, "landMark", e.target.value)}
                      />
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          {referenceList.length < 8 && (
            <div className="mt-3 text-end">
              <button
                type="button"
                className="btn btn-outline-primary btn-sm rounded-pill px-3"
                onClick={handleAddReference}
              >
                <i className="fa-solid fa-plus me-1"></i> Add Another Reference
              </button>
            </div>
          )}
        </Modal.Body>
        <Modal.Footer>
          <button className="oxy-btn-secondary" onClick={() => setEditSection(null)}>Cancel</button>
          <button className="oxy-btn-primary" onClick={saveReferenceDetails} disabled={submitting}>
            {submitting ? "Saving..." : "Save References"}
          </button>
        </Modal.Footer>
      </Modal>

      {/* 5. KYC & PASSWORDS EDIT MODAL */}
      <Modal show={editSection === "kyc" && !kycModal.open} onHide={() => setEditSection(null)} size="lg" centered enforceFocus={false}>
        <Modal.Header closeButton>
          <Modal.Title className="fw-bold text-dark h5">KYC Documents</Modal.Title>
        </Modal.Header>
        <Modal.Body className="p-4" style={{ maxHeight: "70vh", overflowY: "auto" }}>
          <div className="row g-4">
          {[
              { label: "PAN Card Document", name: "pan", value: kycDocs.PanCard, passwordField: "panPassword", downloadUrl: kycDocs.PanCard?.downloadUrl },
              { label: "Credit Bureau Report", name: "CREDITREPORT", value: kycDocs.creditReport, passwordField: "creditReportPassword", downloadUrl: kycDocs.creditReport?.downloadUrl },
              { label: "Cancelled Cheque Leaf", name: "CHEQUELEAF", value: kycDocs.CHEQUELEAF, downloadUrl: kycDocs.CHEQUELEAF?.downloadUrl },
              { label: "6-Month Bank Statement", name: "BANKSTATEMENT", value: kycDocs.bankStatement, passwordField: "bankStatementPassword", downloadUrl: kycDocs.bankStatement?.downloadUrl },
              { label: "Registered Aadhaar Card", name: "AADHAR", value: kycDocs.aadhar, passwordField: "aadharPassword", downloadUrl: kycDocs.aadhar?.downloadUrl },
              { label: "Driving Licence Scan", name: "DRIVINGLICENCE", value: kycDocs.DRIVINGLICENCE, downloadUrl: kycDocs.DRIVINGLICENCE?.downloadUrl },
              { label: "Voter Identity Card", name: "VOTERID", value: kycDocs.VOTERID, downloadUrl: kycDocs.VOTERID?.downloadUrl },
              { label: "Official Passport Page", name: "PASSPORT", value: kycDocs.Passport, downloadUrl: kycDocs.Passport?.downloadUrl },
              { label: "Latest 6-Month Payslips", name: "PAYSLIPS", value: kycDocs.paySlips, passwordField: "payslipsPassword", downloadUrl: kycDocs.paySlips?.downloadUrl },

              ...(category === "STUDENT"
                ? [
                    { label: "Intermediate Marksheet", name: "INTER", value: kycDocs.inter, downloadUrl: kycDocs.inter?.downloadUrl },
                    { label: "10th Grade Marksheet", name: "TENTH", value: kycDocs.tenth, downloadUrl: kycDocs.tenth?.downloadUrl },
                    { label: "Graduation Marksheet", name: "GRADUATION", value: kycDocs.graduation, downloadUrl: kycDocs.graduation?.downloadUrl },
                    { label: "Offer Letter", name: "UNIVERSITYOFFERLETTER", value: kycDocs.universityOfferLetter, downloadUrl: kycDocs.universityOfferLetter?.downloadUrl },
                    { label: "Fee Receipt", name: "FEE", value: kycDocs.feeReceipt, downloadUrl: kycDocs.feeReceipt?.downloadUrl },
                  ]
                : [])
            ].map((doc) => (
              <div className="col-md-6" key={doc.name}>
                <div className="p-3 border rounded-3 bg-light d-flex flex-column justify-content-between h-100">
                  <div className="d-flex justify-content-between align-items-start mb-2">
                    <div>
                      <span className="fw-bold d-block text-dark small">{doc.label}</span>
                      {doc.downloadUrl != null ? (
                        <span
                          onClick={() => viewKYCFile(doc.downloadUrl, doc.label, doc.name, doc.value?.fileName)}
                          className="text-success small"
                          style={{ fontSize: "11px", cursor: "pointer", textDecoration: "underline" }}
                          title="Click to preview document"
                        >
                          ✓ {doc.value?.fileName || "Uploaded"}
                        </span>
                      ) : (
                        <span className="text-muted small" style={{ fontSize: "11px" }}>No file uploaded</span>
                      )}
                    </div>
                    <div className="d-flex align-items-center gap-1">
                      {doc.downloadUrl != null && (
                        <button
                          type="button"
                          className="btn btn-outline-secondary btn-xs py-1 px-2 cursor-pointer"
                          style={{ fontSize: "11px" }}
                          onClick={() => viewKYCFile(doc.downloadUrl, doc.label, doc.name, doc.value?.fileName)}
                          title="Preview Document"
                        >
                          <i className="fa-solid fa-eye"></i>
                        </button>
                      )}
                      <button
                        type="button"
                        className="btn btn-outline-primary btn-xs py-1 px-2 cursor-pointer"
                        style={{ fontSize: "11px" }}
                        onClick={() => openKYCModal(doc.name, "upload")}
                        title="Upload Document"
                      >
                        <i className="fa-solid fa-cloud-arrow-up"></i>
                      </button>
                    </div>
                  </div>
                  {/* {doc.passwordField && (
                    <div className="mt-2 pt-2 border-top">
                      <label className="form-label text-muted text-xs mb-1" style={{ fontSize: "10px" }}>File Password</label>
                      <input 
                        type="text" 
                        className="form-control form-control-sm rounded-2 text-xs py-1" 
                        name={doc.passwordField}
                        placeholder="Enter file password"
                        value={secureInfo[doc.passwordField] || ""} 
                        onChange={handleSecureInput} 
                      />
                    </div>
                  )} */}

                  {doc.name === "BANKSTATEMENT" && (
                    <div className="mt-2 pt-2 border-top">
                      <div className="d-flex flex-wrap gap-2 mb-2">

                        <button
                          type="button"
                          className="btn btn-sm btn-outline-secondary d-flex align-items-center gap-1 py-1 px-2"
                          style={{ fontSize: "11px" }}
                          onClick={handleDownloadBankReportPdf}
                          disabled={downloadingBankReport}
                        >
                          {downloadingBankReport ? (
                            <span className="spinner-border spinner-border-sm me-1" role="status"></span>
                          ) : (
                            <i className="fa-solid fa-file-pdf text-danger me-1"></i>
                          )}
                          PDF Report
                        </button>
                      </div>

                      {bankAnalysisData && (
                        <div className="p-2 bg-white rounded border text-xs" style={{ fontSize: "11px" }}>
                          <div className="d-flex justify-content-between mb-1">
                            <span className="text-muted">Analysis Status:</span>
                            <span className="fw-bold text-success">{bankAnalysisData.status || bankAnalysisData.analysisStatus || "Completed"}</span>
                          </div>
                          {(bankAnalysisData.averageMonthlyBalance != null || bankAnalysisData.avgMonthlyBalance != null) && (
                            <div className="d-flex justify-content-between mb-1">
                              <span className="text-muted">Avg Monthly Bal:</span>
                              <span className="fw-bold">₹ {Number(bankAnalysisData.averageMonthlyBalance || bankAnalysisData.avgMonthlyBalance || 0).toLocaleString("en-IN")}</span>
                            </div>
                          )}
                          {(bankAnalysisData.totalTurnover != null || bankAnalysisData.turnover != null) && (
                            <div className="d-flex justify-content-between mb-1">
                              <span className="text-muted">Total Turnover:</span>
                              <span className="fw-bold">₹ {Number(bankAnalysisData.totalTurnover || bankAnalysisData.turnover || 0).toLocaleString("en-IN")}</span>
                            </div>
                          )}
                          {bankAnalysisData.riskRating && (
                            <div className="d-flex justify-content-between">
                              <span className="text-muted">Risk Rating:</span>
                              <span className="fw-bold text-primary">{bankAnalysisData.riskRating}</span>
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        </Modal.Body>
        <Modal.Footer>
          <button className="oxy-btn-secondary" onClick={() => setEditSection(null)}>Cancel</button>
        </Modal.Footer>
      </Modal>

      <Modal show={pdfPasswordModal.open} onHide={handlePdfPasswordModalClose} centered enforceFocus={false}>
        <Modal.Header closeButton>
          <Modal.Title className="fw-bold text-dark h5">{pdfPasswordModal.title}</Modal.Title>
        </Modal.Header>
        <Modal.Body className="p-4">
          <p className="text-muted small mb-3">{pdfPasswordModal.text}</p>

          <div className="p-3 bg-light rounded-3 border mb-3">
            <label className="fw-semibold small d-block mb-2 text-dark">
              Does this file contain a password? <span className="text-danger">*</span>
            </label>
            <div className="d-flex align-items-center gap-4 mb-2">
              <div className="form-check form-check-inline d-flex align-items-center gap-2 mb-0" style={{ cursor: "pointer" }}>
                <input
                  className="form-check-input"
                  type="radio"
                  name="pdfModalHasPassword"
                  id="pdfModalHasPasswordYes"
                  value="yes"
                  checked={pdfPasswordModal.hasPasswordChoice === "yes"}
                  onChange={() => setPdfPasswordModal((prev) => ({ ...prev, hasPasswordChoice: "yes", error: "" }))}
                  style={{ cursor: "pointer", width: "16px", height: "16px" }}
                />
                <label className="form-check-label small fw-semibold text-dark mb-0" htmlFor="pdfModalHasPasswordYes" style={{ cursor: "pointer" }}>
                  Yes, file is password-protected
                </label>
              </div>
              <div className="form-check form-check-inline d-flex align-items-center gap-2 mb-0" style={{ cursor: "pointer" }}>
                <input
                  className="form-check-input"
                  type="radio"
                  name="pdfModalHasPassword"
                  id="pdfModalHasPasswordNo"
                  value="no"
                  checked={pdfPasswordModal.hasPasswordChoice === "no"}
                  onChange={() => setPdfPasswordModal((prev) => ({ ...prev, hasPasswordChoice: "no", password: "", error: "" }))}
                  style={{ cursor: "pointer", width: "16px", height: "16px" }}
                />
                <label className="form-check-label small fw-semibold text-dark mb-0" htmlFor="pdfModalHasPasswordNo" style={{ cursor: "pointer" }}>
                  No, unencrypted file
                </label>
              </div>
            </div>

            {pdfPasswordModal.hasPasswordChoice === "yes" && (
              <div className="mt-3">
                <label className="small text-muted mb-1 d-block">
                  Enter File Password <span className="text-danger">*</span>
                </label>
                <div className="input-group">
                  <input
                    type={pdfPasswordModal.showPassword ? "text" : "password"}
                    className="form-control rounded-start-3"
                    placeholder={pdfPasswordModal.placeholder || "Enter file password (letters, numbers, symbols)"}
                    value={pdfPasswordModal.password}
                    onChange={handlePdfPasswordModalChange}
                    autoFocus
                    autoComplete="off"
                    onKeyDown={(e) => {
                      if (e.key === "Enter") {
                        e.preventDefault();
                        handlePdfPasswordModalSubmit();
                      }
                    }}
                  />
                  <button
                    type="button"
                    className="btn btn-outline-secondary"
                    onClick={() => setPdfPasswordModal((prev) => ({ ...prev, showPassword: !prev.showPassword }))}
                    title={pdfPasswordModal.showPassword ? "Hide password" : "Show password"}
                  >
                    <i className={`fa-solid ${pdfPasswordModal.showPassword ? "fa-eye-slash" : "fa-eye"}`}></i>
                  </button>
                </div>
              </div>
            )}

            {pdfPasswordModal.error && (
              <div className="text-danger small mt-2 d-flex align-items-center gap-1 fw-medium">
                <i className="fa-solid fa-circle-exclamation"></i>
                <span>{pdfPasswordModal.error}</span>
              </div>
            )}
          </div>
        </Modal.Body>
        <Modal.Footer>
          <button className="oxy-btn-secondary" onClick={handlePdfPasswordModalClose}>
            {pdfPasswordModal.cancelText}
          </button>
          <button className="oxy-btn-primary" onClick={handlePdfPasswordModalSubmit}>
            {pdfPasswordModal.confirmText}
          </button>
        </Modal.Footer>
      </Modal>

      <Modal show={editSection === "whatsapp"} onHide={() => setEditSection(null)} centered enforceFocus={false}>
        <Modal.Header closeButton>
          <Modal.Title className="fw-bold text-dark h5">Verify WhatsApp Number</Modal.Title>
        </Modal.Header>
        <Modal.Body className="p-4">
          <p className="text-muted small mb-2">To verify your WhatsApp number, please click the button below to receive a verification code on your registered WhatsApp.</p>
          <PhoneInput
            className="phoneinputfiled form-control"
            value={whatsappVal}
            onChange={setWhatsappVal}
            defaultCountry="IN"
            maxLength={15}
          />
          {!whatsappSubmitted && (
          <Button type="primary" className="mt-4 mb-3" onClick={handleSendWhatsappOtp} disabled={submitting}>
            {submitting ? "Sending..." : "Send Verification Code"}
          </Button>
          )}
          {whatsappSubmitted && (
            <p className="text-success small mb-2">A verification code has been sent to your WhatsApp. Please enter it below.</p>
          )}
          {whatsappSubmitted && (
            <>
            <input type="text" className="form-control mb-3" placeholder="Enter 6-digit code" value={whatsappOtp} onChange={(e) => setWhatsappOtp(e.target.value)} />
          <Button type="primary"  onClick={handleVerifyWhatsappOtp} disabled={submitting}>
            {submitting ? "Verifying..." : "Verify Code"}
          </Button>
          {}
          <Button type="secondary" className="ms-2" onClick={handleSendWhatsappOtp} disabled={submitting}>
            {submitting ? "Resending..." : "Resend Code"}
          </Button>
          </>
            )}
        </Modal.Body>
        <Modal.Footer>
          <button className="oxy-btn-secondary" onClick={() => setEditSection(null)}>Close</button>
        </Modal.Footer>
      </Modal>
 
      {/* 6. Production-Grade KYC Document Viewer & Manager Modal */}
      <KYCModal
        isOpen={kycModal.open}
        onClose={closeKYCModal}
        mode={kycModal.mode}
        documentType={kycModal.documentType}
        fileUrl={kycModal.fileUrl}
        fileName={kycModal.fileName}
        title={kycModal.title}
        companyName={profileData.companyName}
        declaredSalary={profileData.salary}
        onUploadFile={handleModalUploadFile}
        isUploading={modalUploading}
      />

      {/* 7. Official Credit Bureau Instant Fetch & Review Modal */}
      <CreditScoreModal
        show={showCreditModal}
        onHide={() => setShowCreditModal(false)}
        onSuccess={(res) => {
          setCreditBureauData(parseCreditReportData(res));
          fetchKycFiles();
        }}
        initialData={profileData}
      />

    </div>
  );
};

export default Profile;
